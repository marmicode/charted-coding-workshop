# Interview Log — Offline Mode design doc

No human was available, so every point where I would have called `AskUserQuestion` is
recorded here as the exact call, followed by the answer the user gave.

---

## Round 1 — before writing "Desired Behavior" and "Design & Implementation Details"

```json
{
  "questions": [
    {
      "question": "Where should the cached recipe data actually live?",
      "header": "Storage",
      "multiSelect": false,
      "options": [
        {
          "label": "Service worker + Cache API",
          "description": "Cache whole HTTP responses. Natural fit for a read-only cache, and the service worker also makes the app shell boot with no network.",
          "preview": "const cache = await caches.open('whiskmate-recipes-v1');\nawait cache.put(req, res);\nconst hit = await cache.match(req);"
        },
        {
          "label": "IndexedDB by hand (idb / Dexie)",
          "description": "Store deserialized Recipe objects in an object store. More control, queryable, but we write and maintain the storage layer ourselves.",
          "preview": "const db = await openDB('whiskmate', 1, {\n  upgrade: (db) => db.createObjectStore('recipes', { keyPath: 'id' }),\n});\nawait db.put('recipes', recipe);"
        },
        {
          "label": "localStorage of serialized recipes",
          "description": "Simplest possible thing. Synchronous, ~5MB quota, strings only — fine for a handful of recipes, bad for images.",
          "preview": "localStorage.setItem(`recipe:${id}`, JSON.stringify(recipe));"
        },
        {
          "label": "HTTP cache headers only",
          "description": "Let the browser HTTP cache do it via Cache-Control. Zero app code, but no control over what is kept and no way to know a response came from cache.",
          "preview": "Cache-Control: max-age=0, stale-while-revalidate=604800"
        }
      ]
    },
    {
      "question": "A recipe was edited on the server while a cached copy sits on the device. What does the user see when they open it offline?",
      "header": "Stale data",
      "multiSelect": false,
      "options": [
        {
          "label": "Show the cached copy with a visible \"offline copy from <date>\" marker",
          "description": "Never blocks the cook. The date makes the staleness legible so they can judge it themselves.",
          "preview": "┌────────────────────────────────────┐\n│ 🥕 Carrot Cake                     │\n│ ⓘ Offline copy from 21 Sept        │\n│                                    │\n│ 250g flour …                       │\n└────────────────────────────────────┘"
        },
        {
          "label": "Show the cached copy silently",
          "description": "No marker. Cleanest UI, but a cook can follow an outdated recipe without ever knowing.",
          "preview": "┌────────────────────────────────────┐\n│ 🥕 Carrot Cake                     │\n│                                    │\n│ 250g flour …                       │\n└────────────────────────────────────┘"
        },
        {
          "label": "Block copies older than a threshold",
          "description": "Refuse to render anything cached more than N days ago and show an error instead.",
          "preview": "┌────────────────────────────────────┐\n│ ⚠ This offline copy is 9 days old  │\n│   and may be out of date.          │\n│   [ Retry ]                        │\n└────────────────────────────────────┘"
        },
        {
          "label": "Show cached copy + a \"check for updates\" action",
          "description": "Marker plus an explicit refresh button that only works once connectivity is back.",
          "preview": "┌────────────────────────────────────┐\n│ 🥕 Carrot Cake                     │\n│ ⓘ Offline copy · [Check for update]│\n└────────────────────────────────────┘"
        }
      ]
    },
    {
      "question": "How does the app know it is offline?",
      "header": "Offline state",
      "multiSelect": false,
      "options": [
        {
          "label": "One app-wide signal, injected wherever needed",
          "description": "A single root-provided service exposing `isOffline: Signal<boolean>`. One place to test, one place to fake.",
          "preview": "@Injectable({ providedIn: 'root' })\nexport class Connectivity {\n  readonly isOffline: Signal<boolean>;\n}"
        },
        {
          "label": "Per-component navigator.onLine checks",
          "description": "Each component reads `navigator.onLine` and subscribes to online/offline events itself.",
          "preview": "ngOnInit() {\n  this.offline = !navigator.onLine;\n  window.addEventListener('offline', …);\n}"
        },
        {
          "label": "Infer it from failed requests only",
          "description": "No explicit online/offline state. Each request that fails falls back to cache; the UI never says \"you are offline\".",
          "preview": "catch (e) {\n  return this.cache.read(id);\n}"
        }
      ]
    },
    {
      "question": "What gets cached?",
      "header": "Cache scope",
      "multiSelect": false,
      "options": [
        {
          "label": "Read path only — recipes the user actually opened",
          "description": "Cache a recipe as a side effect of viewing it. Matches the stated non-goals (no offline editing, no offline catalog search).",
          "preview": "GET /recipes/:id  → cached on success\nPOST/PUT/DELETE   → never cached, fail offline"
        },
        {
          "label": "Read path + prefetch the catalog list",
          "description": "Also cache the recipe list so the user can browse titles offline, even if the detail is not cached."
        },
        {
          "label": "Read path + queue writes for later",
          "description": "Cache reads and hold edits in an outbox to replay when back online. Bigger scope; brings sync conflicts."
        }
      ]
    }
  ]
}
```

**Answer:**
1. Storage → **Service worker + Cache API** _("I'm convinced it should be a service worker + Cache API rather than IndexedDB-by-hand. We're caching HTTP responses, not building a database.")_
2. Stale data → **Show the cached copy with a visible "offline copy from &lt;date&gt;" marker** _("This is the part that actually worries me — a recipe edited on the server while a stale copy sits on the device. But blocking is worse. Show it, mark it, let them judge.")_
3. Offline state → **One app-wide signal, injected wherever needed** _("Not per-component checks. One signal for the whole app.")_
4. Cache scope → **Read path only — recipes the user actually opened**

---

## Round 2 — before writing "Design & Implementation Details" and "Testing Strategy"

```json
{
  "questions": [
    {
      "question": "Who owns the recipe-data cache path — the service worker, or app code?",
      "header": "Cache owner",
      "multiSelect": false,
      "options": [
        {
          "label": "App code behind a plain injectable; service worker only handles the app shell",
          "description": "The service worker precaches JS/CSS/HTML so the app boots offline, and nothing else. Recipe caching is ordinary Angular code calling the Cache API behind an injectable, so it can be faked in Vitest with no service worker anywhere.",
          "preview": "export abstract class RecipeCache {\n  abstract read(id: string): Promise<CachedRecipe | undefined>;\n  abstract write(id: string, recipe: Recipe): Promise<void>;\n}\n\n// tests inject FakeRecipeCache — no SW, no browser"
        },
        {
          "label": "ngsw dataGroups with the `freshness` strategy",
          "description": "Declarative, near-zero code: Angular's service worker does network-first with cache fallback. But the cached response is served transparently — the app cannot tell a cached copy from a fresh one, nor when it was stored.",
          "preview": "{\n  \"dataGroups\": [{\n    \"name\": \"recipes\",\n    \"urls\": [\"/api/recipes/**\"],\n    \"cacheConfig\": { \"strategy\": \"freshness\", \"maxAge\": \"7d\", \"maxSize\": 50 }\n  }]\n}"
        },
        {
          "label": "Custom service worker fetch handler",
          "description": "Hand-written `fetch` event listener doing the network-first/cache-fallback logic, communicating staleness back to the app via postMessage or a synthetic header.",
          "preview": "self.addEventListener('fetch', (e) => {\n  e.respondWith(networkFirst(e.request));\n});"
        }
      ]
    },
    {
      "question": "How long do offline copies stick around?",
      "header": "Retention",
      "multiSelect": false,
      "options": [
        {
          "label": "Keep the last N opened recipes, evict least-recently-used",
          "description": "Bounded by count, not by age. A copy is never thrown away for being old — the date marker already handles staleness.",
          "preview": "cache size → 30 recipes\nopen #31   → evict least-recently-read"
        },
        {
          "label": "Expire after N days",
          "description": "Copies older than the threshold are deleted, so an old recipe simply becomes unavailable offline."
        },
        {
          "label": "Keep everything until the browser evicts it",
          "description": "No policy at all; rely on the browser's storage pressure eviction."
        }
      ]
    },
    {
      "question": "When a read fails, should we always fall back to the cache?",
      "header": "Fallback rule",
      "multiSelect": false,
      "options": [
        {
          "label": "Only on network-level failures",
          "description": "Fall back when the request never reached the server (status 0 / DNS / timeout). A 404 or a 500 is a real answer from the server and propagates as an error.",
          "preview": "if (err.status === 0) → try cache\nif (err.status === 404) → not-found error\nif (err.status === 500) → server error"
        },
        {
          "label": "On any failure, including 4xx/5xx",
          "description": "Any non-success falls back to the cached copy. More resilient during server incidents, but a deleted recipe would keep rendering from cache."
        }
      ]
    }
  ]
}
```

**Answer:**
1. Cache owner → **App code behind a plain injectable; service worker only handles the app shell** _("Testing service workers directly is miserable. I want the cache decision behind a plain injectable so it can be tested without a service worker at all.")_
2. Retention → **Keep the last N opened recipes, evict least-recently-used** _("Don't expire by age — the date marker is what handles staleness. Just cap how many we keep." Exact N left open.)_
3. Fallback rule → **Only on network-level failures**
