# Offline Mode

> Status: Draft · 2026-09-24

## Goals

- A cook who opened a recipe while online can still read it with no connection, mid-recipe, without losing their place.
- The app never shows a blank screen or a spinner that never resolves when the network is gone.
- Priority when these conflict: reading an already-opened recipe wins over everything else.

## Non-Goals

- Offline *editing* of recipes — not yet; sync conflict resolution is a project of its own and there is no demand signal for it.
- Offline search across the full catalog — out of scope; only recipes the user has actually opened are cached.
- Background sync when the app is closed — deliberately rejected; the battery and complexity cost is not worth it for a recipe app.

## Desired Behavior

### The offline indicator

There is exactly one notion of "the app is offline" in the whole app: a single root-level
signal. The app shell renders a discreet banner from it; nothing else in the app ever asks
the browser directly.

| | |
|---|---|
| **Given** | the device loses connectivity |
| **Then** | an app-wide banner appears: *"You're offline. You can still read recipes you've already opened."* |
| **And** | it disappears on its own when connectivity returns — no reload, no user action |

### Reading a recipe that was already opened

This is the scenario the whole feature exists for.

| | |
|---|---|
| **Given** | the user opened *Carrot Cake* while online at some earlier point |
| **And** | the device is now offline |
| **When** | they open *Carrot Cake* |
| **Then** | the recipe renders in full — title, ingredients, steps |
| **And** | a marker above the content reads *"Offline copy from 21 Sept"* |

The marker is the answer to the staleness problem, and it is deliberately not a blocker.
A recipe whose cached copy is three days stale is still a usable recipe; a cook standing in
their kitchen with no signal wants the text, not a modal telling them they can't have it.
The date is what lets them judge for themselves.

- The marker shows a date, not a vague "cached" label — *"Offline copy from 21 Sept"*, or
  *"Offline copy from 14:32"* when the copy was taken today.
- It is shown **only** when the copy actually came from the cache. A successful network read
  shows nothing, even while the offline banner is up (e.g. flaky connectivity that recovered).

### Going offline mid-recipe

| | |
|---|---|
| **Given** | the user is reading a recipe and has scrolled to step 4 |
| **When** | connectivity drops |
| **Then** | nothing on the page changes except the app-wide banner appearing |
| **And** | scroll position, expanded sections and any in-page state are untouched |

No re-fetch, no re-render, no navigation. The already-rendered page is the source of truth
until the user navigates away. This is Goal 1 restated: *without losing their place.*

### Opening a recipe that was never cached

| | |
|---|---|
| **Given** | the device is offline |
| **When** | the user opens a recipe they have never viewed before |
| **Then** | an explicit state renders: *"This recipe isn't available offline."* with a **Retry** action |
| **And** | no spinner is left running, and the screen is never blank (Goal 2) |

Retry simply re-runs the read. When connectivity is back it succeeds and the page becomes
normal; while still offline it lands on the same state.

### Coming back online

| | |
|---|---|
| **Given** | the user is looking at an offline copy of a recipe |
| **When** | connectivity returns |
| **Then** | the banner disappears |
| **And** | the offline-copy marker disappears the next time that recipe is read (navigation or Retry) |

We deliberately do **not** silently swap the content under the user's eyes while they are
reading it. A recipe that changes mid-read is more alarming than a stale one.

### Writes while offline

Out of scope per Non-Goals, but the behavior still needs to be defined: any mutation
(create / edit / delete) attempted while offline fails with a plain error telling the user
to reconnect. Nothing is queued, nothing is optimistically applied.

## Design & Implementation Details

> Library/file paths below are proposals — adjust to whatever the actual Nx boundaries are.

### Shape of the thing

```
┌──────────────────────────────────────────────────────────┐
│  RecipePage (standalone, signals)                        │
│    reads  → recipeResource()        → fresh | offline-copy | unavailable
│    reads  → connectivity.isOffline  → app-wide banner     │
└───────────────┬──────────────────────────────────────────┘
                │
┌───────────────▼──────────────────────┐   ┌─────────────────────────┐
│  RecipeRepository                    │◄──┤  Connectivity           │
│    network-first, cache on failure   │   │   isOffline: Signal     │
└───────────────┬──────────────────────┘   └─────────────────────────┘
                │
┌───────────────▼──────────────────────┐
│  RecipeCache  (abstract injectable)  │  ← the seam everything is tested against
├──────────────────────────────────────┤
│  CacheApiRecipeCache   (production)  │──► Cache API  `whiskmate-recipes-v1`
│  FakeRecipeCache       (tests)       │──► in-memory Map
└──────────────────────────────────────┘

Service worker (ngsw): app shell only — JS/CSS/HTML/fonts. It knows nothing about recipes.
```

The key decision: **the service worker does not participate in the recipe read path.** Its
only job is making the app boot with no network. Everything about *which copy the user sees
and how old it is* lives in ordinary injectable Angular code, which is what makes the whole
feature testable without a service worker.

### `Connectivity` — the single offline signal

Root-provided, one instance, the only place in the app that touches `navigator.onLine`.

```ts
@Injectable({ providedIn: 'root' })
export class Connectivity {
  readonly #browserOnline = toSignal(
    merge(fromEvent(window, 'online'), fromEvent(window, 'offline')).pipe(
      map(() => navigator.onLine),
    ),
    { initialValue: navigator.onLine },
  );

  /* Set when a request fails at the network level even though the browser claims to be
   * online — captive portals, dead wifi. Cleared on the next successful response. */
  readonly #reachable = signal(true);

  readonly isOffline = computed(() => !this.#browserOnline() || !this.#reachable());

  reportUnreachable(): void { this.#reachable.set(false); }
  reportReachable(): void { this.#reachable.set(true); }
}
```

`navigator.onLine` alone is famously optimistic — it reports "online" for any active
interface, including one that routes nowhere. The two failure reports from the repository
patch that hole while keeping a single `isOffline` signal as the app's only source of truth.
Components never subscribe to window events; they inject this and read the signal.

### `RecipeCache` — the testable seam

```ts
export interface CachedRecipe {
  readonly recipe: Recipe;
  readonly cachedAt: Date;
}

export abstract class RecipeCache {
  abstract read(id: string): Promise<CachedRecipe | undefined>;
  abstract write(id: string, recipe: Recipe): Promise<void>;
}
```

The production implementation stamps its own header at write time rather than trusting the
server's `Date`, so `cachedAt` means exactly "when this device stored this copy":

```ts
@Injectable()
export class CacheApiRecipeCache extends RecipeCache {
  readonly #clock = inject(CLOCK); // injectable now() — keeps tests deterministic
  readonly #cacheName = 'whiskmate-recipes-v1';

  async write(id: string, recipe: Recipe): Promise<void> {
    const cache = await caches.open(this.#cacheName);
    await cache.put(
      this.#key(id),
      new Response(JSON.stringify(recipe), {
        headers: { 'content-type': 'application/json', [CACHED_AT_HEADER]: this.#clock.now().toISOString() },
      }),
    );
    await this.#evictLeastRecentlyUsed(cache);
  }

  async read(id: string): Promise<CachedRecipe | undefined> {
    const cache = await caches.open(this.#cacheName);
    const response = await cache.match(this.#key(id));
    if (!response) return undefined;
    return {
      recipe: await response.json(),
      cachedAt: new Date(response.headers.get(CACHED_AT_HEADER)!),
    };
  }

  #key(id: string) { return `/__recipe-cache__/${id}`; }
}
```

Retention: cap at **N most-recently-read recipes** (N to be picked — 30 is a reasonable
starting guess), evicting least-recently-used on write. Nothing is ever evicted for being
old; age is communicated, not enforced. LRU order is kept as a small ordered key list in the
same cache (or `localStorage`) — a list of ids is the one piece of state that genuinely is
key/value, so it does not justify a database.

### `RecipeRepository` — network-first, cache on network failure

```ts
export type RecipeRead =
  | { status: 'fresh'; recipe: Recipe }
  | { status: 'offline-copy'; recipe: Recipe; cachedAt: Date }
  | { status: 'unavailable-offline' };

async getRecipe(id: string): Promise<RecipeRead> {
  try {
    const recipe = await firstValueFrom(this.#http.get<Recipe>(`/api/recipes/${id}`));
    this.#connectivity.reportReachable();
    await this.#cache.write(id, recipe);            // side effect, never blocks the read
    return { status: 'fresh', recipe };
  } catch (error) {
    if (!isNetworkError(error)) throw error;        // 404 stays a 404, 500 stays a 500
    this.#connectivity.reportUnreachable();
    const cached = await this.#cache.read(id);
    return cached
      ? { status: 'offline-copy', recipe: cached.recipe, cachedAt: cached.cachedAt }
      : { status: 'unavailable-offline' };
  }
}
```

`isNetworkError` = `HttpErrorResponse` with `status === 0`. This is the rule that keeps a
deleted recipe from living forever in the cache: the server answering 404 is an answer, and
it propagates.

A failed `cache.write` must never fail the read — wrap it and swallow (log it). Quota errors
and private-mode restrictions are real and the user still wants their recipe.

### UI pieces

- `OfflineBanner` — standalone, lives in the app shell, `@if (connectivity.isOffline())`.
  One instance for the whole app.
- `OfflineCopyNotice` — small inline component on the recipe page, rendered only for
  `status === 'offline-copy'`, printing `cachedAt` through `DatePipe` (`'d MMM'`, or
  `'HH:mm'` when the copy is from today). Marked up as a `role="status"` so screen readers
  announce it.
- `RecipeUnavailableOffline` — the empty state with the **Retry** action.

The recipe page holds one signal-based resource; the three statuses are a plain discriminated
union rendered by a `@switch`. No component anywhere checks connectivity to decide what data
to show — the status on the read is what drives the view.

### Service worker configuration

`@angular/service-worker` via `ng add @angular/pwa`, with `ngsw-config.json` containing
**assetGroups only**:

- `app` — `prefetch`, the index + JS/CSS bundles, so the shell boots offline.
- `assets` — `lazy`, fonts and icons.
- **No `dataGroups`.** Anything matching `/api/**` is deliberately left alone so the service
  worker can never shadow or compete with `CacheApiRecipeCache`.

Recipe images are an open question (see below) — if we cache them it will be a `lazy`
assetGroup on the image origin, which is the one thing the SW is genuinely good at.

## Testing Strategy

The whole design above exists partly so that **none of the interesting tests need a service
worker.** Service-worker tests are slow, flaky, and painful to write; the cache decision is
behind `RecipeCache`, so the logic is tested as plain Angular code.

Stack: Vitest + Angular Testing Library, MSW for HTTP.

### 1. Repository logic — Vitest, fake cache, MSW

Inject `FakeRecipeCache` (in-memory `Map`) and a fake clock. MSW produces the network
conditions; `HttpResponse.error()` is a network-level failure.

- online read → returns `fresh`, and the recipe is now in the cache
- network failure + cache hit → `offline-copy` with the expected `cachedAt`
- network failure + cache miss → `unavailable-offline`
- 404 → throws, does **not** fall back to the cache (the important negative test)
- 500 → throws, does not fall back
- cache write throws (quota) → read still returns `fresh`
- network failure → `connectivity.isOffline()` becomes `true`; next success flips it back

### 2. Component behavior — Angular Testing Library

Render the recipe page with the fake cache and a stubbed `Connectivity`. Assert on what the
user sees, not on internals.

- offline copy → recipe text is present **and** `Offline copy from 21 Sept` is visible
- fresh read → no marker anywhere, even when `isOffline()` is true
- cache miss offline → the unavailable message and a **Retry** button, and
  `queryByRole('progressbar')` is null (Goal 2 as an assertion)
- Retry after connectivity returns → the recipe renders and the marker is gone
- banner appears/disappears from the signal alone

### 3. `Connectivity` unit tests

`vi.spyOn(navigator, 'onLine', 'get')` + dispatching `online` / `offline` window events;
assert the signal flips. Plus `reportUnreachable()` making `isOffline()` true while
`navigator.onLine` still says `true`.

### 4. `CacheApiRecipeCache` — one contract suite, run twice

Write the `RecipeCache` contract once and run it against both implementations: against
`FakeRecipeCache` in the normal Vitest run, and against `CacheApiRecipeCache` in Vitest
**browser mode**, where a real Cache API exists. This is the only place the real storage is
touched, it is small, and it keeps the fake honest — the usual failure mode of a hand-rolled
fake is that it drifts from the real thing.

### 5. One end-to-end smoke test

A single Playwright test, and deliberately only one, because this is the miserable part:

1. load the app online, open a recipe
2. `context.setOffline(true)`
3. reload → the shell boots (proves the service worker precache works)
4. the recipe renders with the offline-copy marker

Everything else is covered at a cheaper level. If this test is ever flaky, it gets quarantined
rather than retried into submission — it is a smoke test, not the safety net.

## Alternatives Considered

**IndexedDB by hand (idb / Dexie)** — rejected. We are caching HTTP responses, not modelling
a database. Cache API stores `Response` objects natively; IndexedDB would mean writing and
maintaining a serialization layer for nothing. It would become the right answer the day we
want offline *search* over the catalog, which is an explicit non-goal.

**ngsw `dataGroups` with the `freshness` strategy** — the tempting one: near-zero code,
network-first with cache fallback out of the box. Rejected because the cached response is
served *transparently* — the app cannot tell whether a response came from the network or the
cache, nor when it was stored. That makes the "offline copy from &lt;date&gt;" marker
impossible, and the marker is the whole answer to the staleness problem. It would also push
every test through a service worker.

**A custom service-worker `fetch` handler** — same capability as our design, but the logic
would live in a worker context: no Angular DI, no signals, and tests would need a real or
simulated worker. Rejected on testability alone.

**Blocking stale copies past a threshold** — rejected. It contradicts Goal 1. A cook mid-
recipe with no signal is exactly the person we would be punishing, and staleness is not
binary — a 9-day-old cake recipe is almost certainly still correct. Show it, date it, let the
user judge.

**Silently serving stale copies with no marker** — rejected for the opposite reason: a cook
could follow an outdated recipe and never know why it went wrong. The marker costs one line
of UI.

**Per-component `navigator.onLine` checks** — rejected. Duplicated logic in every component,
missed events, nothing to fake in tests, and no single place to fix `navigator.onLine`'s
optimism.

**`localStorage`** — rejected. ~5MB quota, synchronous (blocks the main thread), strings only,
and hopeless for images.

**ETag / `If-None-Match` revalidation** — not an alternative, a complement. Worth adding later
to make refreshes cheap; it does not solve reading with no network at all.

## Open Questions

- **Recipe images.** Text-only offline recipes are usable but sad. A `lazy` assetGroup on the
  image origin would handle it — but the storage budget goes up sharply and images are the
  most likely thing to blow a quota. Decide before implementing.
- **The catalog / list view offline.** Non-goals rule out offline search, but the list screen
  still has to render *something*. Empty state? A "recently viewed" list built from the cache
  index we are already keeping for LRU? The second is nearly free and worth considering.
- **N for the LRU cap.** 30 is a guess. It should be informed by an average cached recipe
  payload size.
- **Is `reportUnreachable()` worth it in v1**, or should we ship with plain `navigator.onLine`
  and add the heuristic when someone actually reports the captive-portal case?
- **Does the offline banner need a dismiss action?** A persistent banner mid-recipe may be
  more annoying than useful on a small screen.
