# Interview Log — Offline Mode

Design doc: `design-docs/offline-mode.md`
Resumed 2026-09-24. Goals and Non-Goals were already written a few days ago; picking up at **Desired Behavior**.

Each entry is the `AskUserQuestion` call that would have been made, followed by the answer.

---

## Round 1 — Desired Behavior

```json
{
  "questions": [
    {
      "question": "A recipe was cached three days ago and has since been edited on the server. The cook opens it with no connection. What do they see?",
      "header": "Stale data",
      "multiSelect": false,
      "options": [
        {
          "label": "Cached copy + \"offline copy from <date>\" marker (Recommended)",
          "description": "Renders immediately with a visible line saying which day this copy is from. The cook is never blocked and never misled — they decide whether a three-day-old quantity matters. Cost: we accept a possibly-wrong ingredient list on screen."
        },
        {
          "label": "Block with \"this recipe may be out of date\" + Retry",
          "description": "We refuse to show what we can't confirm is current. Safest against acting on stale quantities, but contradicts Goal 1 — the cook is mid-recipe and we just took the recipe away."
        },
        {
          "label": "Cached copy, no marker",
          "description": "Cleanest UI, zero offline chrome. But a silently-wrong quantity is the worst failure this feature can produce, and the cook has no way to notice."
        },
        {
          "label": "Cached copy now, swap in fresh content when the network returns",
          "description": "Shows cached immediately, then live-replaces the page on reconnect. Nice when it works, but content changing under someone who is mid-step is its own hazard."
        }
      ]
    },
    {
      "question": "The cook taps a recipe they have never opened before, with no connection. What happens?",
      "header": "Never cached",
      "multiSelect": false,
      "options": [
        {
          "label": "Dedicated \"not available offline\" screen with a Retry (Recommended)",
          "description": "Honest and immediate. Names the reason, offers the one action that can help. Satisfies Goal 2 directly — no blank screen, no spinner that never resolves."
        },
        {
          "label": "Generic error screen, same as any failed request",
          "description": "Less code, one less state to design. But 'Something went wrong' reads as a bug rather than as 'you're offline', and people retry pointlessly."
        },
        {
          "label": "Keep them on the list and disable uncached recipes",
          "description": "Prevents the dead end before it happens. But the list then has to know what's cached, which is a lot of machinery for a rare case."
        }
      ]
    },
    {
      "question": "How does the cook know the app is offline at all?",
      "header": "Offline signal",
      "multiSelect": false,
      "options": [
        {
          "label": "One app-wide banner, always in the same place (Recommended)",
          "description": "A single persistent strip that appears on connection loss and disappears on return, identical on every screen. One thing to build, one thing to test, one thing for the cook to learn."
        },
        {
          "label": "Per-screen inline notices only",
          "description": "Each screen says its own piece in context. More tailored wording, but the state gets re-derived in several places and the screens drift apart over time."
        },
        {
          "label": "A transient toast on the transition only",
          "description": "Least intrusive. But someone who arrives at a screen after the toast has gone has no idea why the page looks the way it does."
        }
      ]
    },
    {
      "question": "Which of these should the Desired Behavior chapter actually spell out?",
      "header": "Edge cases",
      "multiSelect": true,
      "options": [
        {
          "label": "Cold start with no connection (Recommended)",
          "description": "App killed, relaunched on airplane mode. Arguably the real test of offline mode — if the shell itself doesn't load, nothing else matters."
        },
        {
          "label": "Recipe images missing from the cache (Recommended)",
          "description": "Text cached, photo wasn't. Decides whether we show a placeholder or a broken image, and whether a missing photo can break the page."
        },
        {
          "label": "Connection returns while the cook is reading (Recommended)",
          "description": "Defines whether anything changes under them and what happens to the banner and the date marker."
        },
        {
          "label": "Searching / browsing the catalog while offline",
          "description": "Already a stated Non-Goal, but the reader will still ask what they see. Worth one line so nobody re-opens it."
        }
      ]
    }
  ]
}
```

**Answer:**
- Stale data → **Cached copy + "offline copy from <date>" marker**. Sam: this is the thing that's actually been bugging me. Blocking is worse than stale — someone mid-recipe with dough on their hands does not want a modal. Show it, date it, let them judge.
- Never cached → **Dedicated "not available offline" screen with a Retry**
- Offline signal → **One app-wide banner, always in the same place**. Sam: and it has to be *one* signal — I don't want every component doing its own `navigator.onLine` check.
- Edge cases → **Cold start with no connection**, **Recipe images missing from the cache**, **Connection returns while the cook is reading**, and **Searching / browsing the catalog while offline** (one line only, since it's already a Non-Goal).
- *Other (volunteered):* Sam: on reconnect, don't hot-swap the content under them. Drop the banner, drop the date marker, and let the next navigation fetch fresh. Content changing mid-step is exactly the thing I don't want.

*(Parked for the Design chapter: Sam volunteered service worker + Cache API over hand-rolled IndexedDB, a plain injectable in front of the cache decision, and a single app-wide offline signal. Told them it's parked and will come back in Design & Implementation Details.)*
