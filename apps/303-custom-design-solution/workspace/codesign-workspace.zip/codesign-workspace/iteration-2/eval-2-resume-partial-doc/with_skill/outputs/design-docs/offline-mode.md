# Offline Mode

> Status: Draft · 2026-09-21

## Goals

- A cook who opened a recipe while online can still read it with no connection, mid-recipe, without losing their place.
- The app never shows a blank screen or a spinner that never resolves when the network is gone.
- Priority when these conflict: reading an already-opened recipe wins over everything else.

## Non-Goals

- Offline *editing* of recipes — not yet; sync conflict resolution is a project of its own and there is no demand signal for it.
- Offline search across the full catalog — out of scope; only recipes the user has actually opened are cached.
- Background sync when the app is closed — deliberately rejected; the battery and complexity cost is not worth it for a recipe app.

## Desired Behavior

**Happy path — reading a cached recipe offline**

- Given the cook opened "Tarte Tatin" while online
- When they lose connection and reopen it (or reload mid-recipe)
- Then the recipe renders exactly as before, scroll position and step intact, with no spinner and no error.

**Stale copies**

- A recipe edited on the server while a cached copy sits on the device still opens offline. The cook is never blocked.
- The screen carries a visible marker: **"offline copy from <date>"**.
- The marker states when the copy was taken, not that it is wrong — we do not know whether it is.

**Being offline is app-wide**

- One app-wide "you are offline" state drives a single banner in the app shell.
- Individual screens never ask "am I offline?" — they react to the data they get.

**Edge cases**

- *Recipe never opened before:* an explicit "this recipe isn't available offline" screen with a retry action. Never a dead spinner.
- *Recipe list / search offline:* the list shows the recipes that are cached, marked as such; search is disabled with a short "search needs a connection" note (see Non-Goals).
- *Connection returns mid-session:* the offline banner clears by itself; the "offline copy from <date>" marker clears when the recipe is re-fetched, not before.
- *Flaky connection (request hangs, never fails):* a request that has not answered within a short budget is treated as offline and falls back to the cached copy. TODO: pick the budget (starting proposal: 3s).

**Must stay unchanged**

- Online behaviour is untouched: fresh fetch, no marker, no banner.
- No new blocking dialog or permission prompt anywhere in the flow.


## Design & Implementation Details

**Storage: service worker + Cache API**

- Recipe responses are cached by a service worker through the Cache API, not by hand-rolled IndexedDB writes.
- *Why:* HTTP responses are already the right unit; we get the app shell and static assets cached for free, and we don't reimplement cache semantics on top of a key/value store.
- Strategy: network-first with cache fallback for recipe reads. The read path only — nothing writes to the server offline (see Non-Goals).

**The seam: a plain injectable**

- The cache decision lives behind an injectable, not in component code and not only inside the worker.

```ts
interface RecipeCacheGateway {
  getRecipe(id: string): Promise<{ recipe: Recipe; cachedAt?: Date }>;
}
```

- `cachedAt` present ⇒ this came from the cache ⇒ render the "offline copy from &lt;date&gt;" marker. Absent ⇒ fresh.
- *Why:* testing a service worker directly is miserable. With this seam, every behaviour in the chapter above can be tested by faking one injectable, with no worker registered.
- The service worker's only job is to serve and populate the cache; the app reads through the gateway.

**App-wide offline state**

```ts
@Injectable({ providedIn: 'root' })
class ConnectivityStore {
  readonly isOffline: Signal<boolean>;
}
```

- One root-provided store, one `isOffline` signal, read by the shell banner. No component calls `navigator.onLine`.
- Inputs to the signal: `online`/`offline` window events **plus** the hang budget from Desired Behavior — a request that times out flips it to offline even when the browser claims otherwise.

**New vs. changed**

- New: the service worker registration + config, `RecipeCacheGateway` and its SW-backed implementation, `ConnectivityStore`, the shell offline banner, the stale marker on the recipe screen, the "not available offline" screen.
- Changed: the recipe data access goes through the gateway instead of `HttpClient` directly.

**Load-bearing dependencies**

- `@angular/service-worker` (or a hand-written worker if its network-first knobs don't fit). TODO: confirm which — decide when the hang budget is settled, since ngsw timeouts are config, not code.


## Testing Strategy

**What gets a test, and where**

| Behaviour | Level |
| --- | --- |
| Cached recipe renders with an "offline copy from &lt;date&gt;" marker | Component (Angular Testing Library) |
| Uncached recipe offline → "not available offline" + retry, never a spinner | Component (ATL) |
| Shell banner follows the app-wide offline state | Component (ATL) |
| Hang budget elapses → offline state flips even though the browser says online | Unit, fake timers |
| Reconnect clears the banner; marker clears only on re-fetch | Component (ATL) |

**Real vs. faked**

- **No service worker in any Vitest test, ever.** That is the point of the gateway seam.
- MSW stays where it already is — the HTTP seam — and covers the online paths.
- `RecipeCacheGateway` is faked in tests: the fake is what carries `cachedAt`, i.e. "this came from cache, taken at this date".
- `ConnectivityStore` is exercised through its signal; tests set it rather than poking `navigator.onLine`.

**Test-first**

- The hang-budget logic and the marker rendering are written test-first — both are pure decisions with an obvious assertion.

**What would make these brittle**

- Asserting on Cache API keys or worker internals instead of what the cook sees. Tests name the marker text and the date, not the cache entry.
- Asserting the marker's exact date format. Assert that the cached date is shown.
- Since nothing here registers a worker, the real SW wiring is untested by design. TODO: decide whether one smoke check (open a recipe, go offline, reload) is worth an e2e, or whether that stays a manual pre-release check.


## Alternatives Considered

**Hand-rolled IndexedDB instead of the Cache API**

- Tempting: full control over the shape of what's stored, and trivially testable without a worker.
- Lost: it means reimplementing HTTP cache semantics over a key/value store, and it gives us nothing for the app shell or static assets.
- Revisit when: offline *writes* land (a pending-mutation queue is the wrong shape for the Cache API), or when offline search moves out of Non-Goals — querying cached recipes by ingredient needs a real index. Writes are what would force the move; search is what's likelier to get asked for first.

**Blocking on a possibly-stale recipe**

- Tempting: never show a cook an outdated quantity — correct by construction.
- Lost: it breaks the top-ranked goal. A cook mid-recipe on a dead connection needs the page, not a correctness lecture. The visible "offline copy from &lt;date&gt;" marker is the compromise.
- Revisit when: we have a real report of someone cooking from a stale copy and getting it wrong. Then blocking *specific* fields (quantities) beats blocking the page.

**Per-component offline checks**

- Tempting: no new abstraction, each screen decides for itself.
- Lost: connectivity logic spreads, screens drift apart, and the same question gets answered four different ways.
- Revisit when: a screen genuinely needs offline behaviour the shell banner can't express — and even then it injects `ConnectivityStore` rather than reading the browser.

**Registering a real service worker in tests**

- Tempting: highest fidelity; it's the thing that actually runs in production.
- Lost: service worker lifecycle in Vitest is miserable, and brittle tests that nobody trusts are worse than a seam that's honestly faked.
- Revisit when: we decide the untested SW wiring has burned us — the open TODO in Testing Strategy about a single e2e smoke check.

