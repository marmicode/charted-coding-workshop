# Interview log — offline mode

Resumed at **Desired Behavior** (Goals + Non-Goals already settled).

## Round 1 — Desired Behavior (stale data)

```json
{"questions":[{"question":"A recipe was edited on the server while a cached copy sits on the device. The cook opens it offline. What do they see?","header":"Stale data","multiSelect":false,"options":[{"label":"Cached copy + \"offline copy from <date>\" marker (Recommended)","description":"Never blocks the cook mid-recipe. Cost: they may cook from an outdated version without noticing the banner."},{"label":"Block with \"this recipe may be out of date, reconnect to view\"","description":"Guarantees correctness, but breaks Goal 1 — reading an already-opened recipe wins over everything."},{"label":"Cached copy, no marker at all","description":"Cleanest UI, but a silently wrong quantity is the worst failure mode here."}]}]}
```

**Answer:** Cached copy + "offline copy from <date>" marker (Recommended)

_(same call, question 2)_

```json
{"questions":[{"question":"How does the cook learn the app is offline at all?","header":"Offline signal","multiSelect":false,"options":[{"label":"One app-wide offline banner, driven by a single signal (Recommended)","description":"Shell-level bar, one source of truth. Components stay ignorant of connectivity."},{"label":"Per-screen offline indicators","description":"More contextual, but every component grows a connectivity check and they drift."},{"label":"No global indicator — only the per-recipe staleness marker","description":"Quietest, but a cook who hits an uncached recipe gets no explanation."}]}]}
```

**Answer:** One app-wide offline banner, driven by a single signal (Recommended)

_(same call, question 3)_

```json
{"questions":[{"question":"Which offline edge cases must the doc pin down now?","header":"Edge cases","multiSelect":true,"options":[{"label":"Recipe never opened before → offline (Recommended)","description":"Nothing cached. Needs an explicit 'not available offline' screen, not a dead spinner."},{"label":"Recipe list / search while offline (Recommended)","description":"Non-goal says no catalog search offline — but the screen still has to say something."},{"label":"Connection comes back mid-session (Recommended)","description":"Does the stale marker clear on its own, or on next navigation?"},{"label":"Flaky connection (request hangs, never fails)","description":"The nastiest one: navigator.onLine says true, the network says nothing."}]}]}
```

**Answer:** Recipe never opened before → offline; Recipe list / search while offline; Connection comes back mid-session; Flaky connection (request hangs, never fails)

## Hand-back — after Desired Behavior

```json
{"questions":[{"question":"Desired Behavior is written. Where next?","header":"Next step","multiSelect":false,"options":[{"label":"Continue to Design & Implementation Details (Recommended)","description":"Where the cache lives, what the app-wide offline signal is, and what's injectable."},{"label":"Revise Desired Behavior","description":"Tell me what's off and I rewrite the chapter."},{"label":"Pin down the hang budget for a flaky connection","description":"It's the one TODO left in the chapter — 3s is a guess."}]}]}
```

**Answer:** Continue to Design & Implementation Details (Recommended)

## Round 2 — Design & Implementation Details

```json
{"questions":[{"question":"What actually holds the cached recipes?","header":"Storage","multiSelect":false,"options":[{"label":"Service worker + Cache API (Recommended)","description":"Cache whole HTTP responses via @angular/service-worker or a hand-written SW. Free asset caching too. Cost: SWs are awkward to test and to update."},{"label":"IndexedDB written by hand from the data layer","description":"Full control and easy to test, but we re-implement HTTP caching and lose asset/offline-shell caching."},{"label":"In-memory only, survives navigation but not reload","description":"Trivial, but fails Goal 1 the moment the cook reloads mid-recipe."}],"preview":"SW + Cache API:  fetch -> [SW] -> network | cache\nIndexedDB:       fetch -> [repo] -> http | idb"}]}
```

**Answer:** Service worker + Cache API (Recommended)

_(same call, question 2)_

```json
{"questions":[{"question":"Where does the app decide 'use the cached copy, and mark it stale'?","header":"Seam","multiSelect":false,"options":[{"label":"Behind a plain injectable the SW reports into (Recommended)","description":"e.g. RecipeCacheGateway: returns {recipe, cachedAt?}. Testable with zero service worker — fake the injectable."},{"label":"Inside the service worker only","description":"One place, but every test needs a real SW registered. Miserable in Vitest."},{"label":"In each feature component","description":"No new abstraction, but connectivity logic spreads and Non-Goal drift starts."}],"preview":"interface RecipeCacheGateway {\n  getRecipe(id: string):\n    Promise<{ recipe: Recipe; cachedAt?: Date }>;\n}"}]}
```

**Answer:** Behind a plain injectable the SW reports into (Recommended)

_(same call, question 3)_

```json
{"questions":[{"question":"How is the app-wide offline state exposed?","header":"Offline state","multiSelect":false,"options":[{"label":"A root-provided ConnectivityStore with an `isOffline` signal (Recommended)","description":"One injectable, one signal, read by the shell banner. Components that need it inject it; nobody touches navigator.onLine directly."},{"label":"navigator.onLine read wherever needed","description":"No new code, but untestable and lies on captive portals / hanging requests."},{"label":"An RxJS observable from fromEvent('online'/'offline')","description":"Works, but the rest of the app is signals — this would be the odd one out."}],"preview":"@Injectable({providedIn:'root'})\nclass ConnectivityStore {\n  readonly isOffline: Signal<boolean>;\n}"}]}
```

**Answer:** A root-provided ConnectivityStore with an `isOffline` signal (Recommended)

## Hand-back — after Design & Implementation Details

```json
{"questions":[{"question":"Design chapter is written. Where next?","header":"Next step","multiSelect":false,"options":[{"label":"Continue to Testing Strategy (Recommended)","description":"Which behaviours get tests, at which level, and what gets faked at the gateway seam."},{"label":"Revise Design & Implementation Details","description":"Tell me what's off and I rewrite it."},{"label":"Settle @angular/service-worker vs. a hand-written worker","description":"The remaining TODO — it's tied to the hang budget."}]}]}
```

**Answer:** Continue to Testing Strategy (Recommended)

## Round 3 — Testing Strategy

```json
{"questions":[{"question":"Which Desired Behavior cases earn a test, and at which level?","header":"Test cases","multiSelect":true,"options":[{"label":"Stale marker renders with the cached date (component, ATL) (Recommended)","description":"Fake the gateway to return cachedAt. The core promise of the doc."},{"label":"Uncached recipe offline shows 'not available offline' + retry (component, ATL) (Recommended)","description":"The dead-spinner regression guard."},{"label":"Offline banner follows ConnectivityStore.isOffline (component, ATL) (Recommended)","description":"Shell-level, one signal flipped in the test."},{"label":"Hang budget flips isOffline (unit, fake timers) (Recommended)","description":"Pure logic, no DOM, no worker."}]}]}
```

**Answer:** all four

_(same call, question 2)_

```json
{"questions":[{"question":"What is real in the tests and what is faked, and at which seam?","header":"Fake seam","multiSelect":false,"options":[{"label":"Fake RecipeCacheGateway; no service worker in any test (Recommended)","description":"Tests state 'this came from cache, at this date' directly. Zero SW machinery. Risk: the real SW wiring is never exercised by these tests."},{"label":"Keep MSW at the HTTP seam and register a real service worker","description":"Closer to production, but SW lifecycle in Vitest is exactly the misery we designed the gateway to avoid."},{"label":"MSW for the network, fake gateway for cache state","description":"Both seams — MSW stays for online paths, the gateway carries offline/stale."}]}]}
```

**Answer:** Other: MSW for the network, fake gateway for cache state — MSW already fakes HTTP here, keep it for the online path; the gateway fake is what carries cachedAt. No service worker in any Vitest test, ever.

## Hand-back — after Testing Strategy

```json
{"questions":[{"question":"Testing Strategy is written. Where next?","header":"Next step","multiSelect":false,"options":[{"label":"Continue to Alternatives Considered (Recommended)","description":"Harvest the options you turned down: IndexedDB, blocking on stale, per-component checks, SW-in-tests."},{"label":"Revise Testing Strategy","description":"Tell me what's off and I rewrite it."},{"label":"Decide the e2e smoke check question now","description":"The one TODO: nothing currently exercises the real worker."}]}]}
```

**Answer:** Continue to Alternatives Considered (Recommended)

## Round 4 — Alternatives Considered

```json
{"questions":[{"question":"These are the forks you turned down earlier. Which belong in the doc?","header":"Alternatives","multiSelect":true,"options":[{"label":"IndexedDB written by hand (Recommended)","description":"Tempting for control and testability; lost because it reimplements HTTP caching."},{"label":"Block on a possibly-stale recipe (Recommended)","description":"Correct-by-construction; lost because it breaks the top-ranked goal."},{"label":"Per-component offline checks (Recommended)","description":"No new abstraction; lost to drift."},{"label":"Register a real service worker in tests (Recommended)","description":"Highest fidelity; lost to Vitest SW misery."}]}]}
```

**Answer:** all four

_(same call, question 2)_

```json
{"questions":[{"question":"What would make us revisit the service-worker-plus-Cache-API decision?","header":"Revisit","multiSelect":false,"options":[{"label":"When offline *writes* land (Recommended)","description":"A write queue needs a real store; the Cache API is the wrong shape for pending mutations."},{"label":"When the cache needs querying (offline search)","description":"Currently a Non-Goal. Querying cached recipes by ingredient means IndexedDB."},{"label":"When Cache API quota starts evicting recipes mid-cook","description":"Storage pressure is the failure we'd notice in the field."}]}]}
```

**Answer:** Other: both of the first two, really — offline writes is the one that forces it, offline search is the one that's most likely to get asked for first.

## Hand-back — doc complete

```json
{"questions":[{"question":"All six chapters are written. What now?","header":"Wrap up","multiSelect":false,"options":[{"label":"Consistency read-through, top to bottom (Recommended)","description":"Check the Goals still match the design they produced, and close the three TODOs (hang budget, ngsw vs. hand-written, e2e smoke check)."},{"label":"Start implementation against the doc","description":"First slice: ConnectivityStore + the shell banner, test-first."},{"label":"Revise Alternatives Considered","description":"Add the fork I rejected before we started talking."}]}]}
```

**Answer:** Consistency read-through, top to bottom (Recommended)
