# Interview log — Offline Mode design doc

Session 2026-09-24. Resuming `design-docs/offline-mode.md` — Goals and Non-Goals were
written on 2026-09-21, so the interview picks up at **Desired Behavior**.

Each entry is the `AskUserQuestion` call that was made, followed by what was picked.

---

## Round 1 — Desired Behavior

```json
{
  "questions": [
    {
      "question": "A cached recipe may have been edited on the server since. The user opens it while offline. What do they see?",
      "header": "Stale data",
      "multiSelect": false,
      "options": [
        {
          "label": "Cached copy + dated marker (Recommended)",
          "description": "Renders immediately with a visible 'offline copy from <date>' line. Never blocks the cook; accepts they may be reading yesterday's quantities."
        },
        {
          "label": "Cached copy, no marker",
          "description": "Identical to the online UI. Cost: a cook following an outdated step gets no signal that something newer exists."
        },
        {
          "label