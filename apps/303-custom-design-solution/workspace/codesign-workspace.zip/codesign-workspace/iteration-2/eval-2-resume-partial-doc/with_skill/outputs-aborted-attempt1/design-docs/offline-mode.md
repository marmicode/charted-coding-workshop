# Offline Mode

> Status: Draft · 2026-09-21

## Goals

- A cook who opened a recipe while online can still read it with no connection, mid-recipe, without losing their place.
- The app never shows a blank screen or a spinner that never resolves when the network is gone.
- Priority when these conflict: reading an already-opened recipe wins over everything else.

## Non-Goals

- Offline *editing* of recipes — not yet; sync conflict resolution is a project of its own and there is no demand signal for it.
- Offline search across the full catalog — out of scope; only recipes the user has actually opened are cached.
- Background sync when the app is closed — deliberately rejected; the battery and complexity cost is not worth it for a recipe app.

## Desired Behavior

### Happy path

**Given** the cook opened a recipe while online
**When** they lose connection and stay on (or come back to) that recipe
**Then** the recipe renders in full — ingredients, steps, photo — with no spinner and no reload prompt.

### The offline signal

- One **app-wide banner**, always in the same place, on every screen. It appears when the connection drops and disappears when it returns.
- There is exactly one "you are offline" state in the app. Screens read it; they don't each decide for themselves.

### Stale recipes — the case we actually care about

A recipe can be edited on the server while a cached copy sits on the device. We **show the cached copy** rather than block on it.

- Every recipe served from cache carries a visible marker: **"offline copy from &lt;date&gt;"**.
- The cook is never blocked and never silently misled — they can see how old the copy is and judge whether it matters.
- Accepted cost: a stale ingredient list can be on screen. Blocking someone mid-recipe is worse than that.

**Given** a recipe cached three days ago and since edited on the server
**When** the cook opens it with no connection
**Then** they see the three-day-old version, marked "offline copy from 21 Sep".

### Recipe never opened before

**Given** a recipe the cook has never opened
**When** they tap it with no connection
**Then** they get a dedicated "not available offline" screen with a Retry action — not a generic error, not a blank page, not an endless spinner.

### Other edge cases

- **Cold start with no connection** — app killed, relaunched on airplane mode. The app shell loads and previously-opened recipes are still readable.
- **Missing image** — text cached but photo wasn't: show a placeholder. A missing photo never breaks the page.
- **Connection returns while reading** — the banner and the date marker disappear. The content on screen is **not** hot-swapped; the next navigation fetches fresh. Content changing under someone mid-step is its own hazard.
- **Search / catalog browsing while offline** — a Non-Goal, so it degrades honestly: the search box reports that search needs a connection rather than returning zero results.

### Must stay unchanged

- Online behavior is untouched. With a connection, nothing about the app looks or behaves differently — no banner, no date marker.

## Design & Implementation Details

_Pending._

## Testing Strategy

_Pending._

## Alternatives Considered

_Pending._
