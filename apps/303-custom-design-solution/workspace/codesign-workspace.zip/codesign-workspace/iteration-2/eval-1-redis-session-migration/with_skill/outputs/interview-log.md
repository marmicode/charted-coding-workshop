# Interview Log — Redis Session Store

No human was available; each entry records the `AskUserQuestion` call that would
have been made, and the answer the persona (Alex) would have given.

---

## Round 1 — Slug + Goals

```json
{
  "questions": [
    {
      "question": "Doc filename — I'm proposing design-docs/redis-session-store.md. Keep it?",
      "header": "Slug",
      "multiSelect": false,
      "options": [
        {"label": "redis-session-store (Recommended)", "description": "Names the thing you end up with, so it's findable after the migration is old news."},
        {"label": "session-storage-migration", "description": "Names the project rather than the component; goes stale once the migration lands."},
        {"label": "multi-node-sessions", "description": "Names the forcing constraint. Good if you expect follow-up docs about other multi-node work."}
      ]
    },
    {
      "question": "What has to be true for this to be done? (pick all that apply)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {"label": "Any of the 3 nodes serves any session (Recommended)", "description": "The core outcome: a request landing on node B finds a session created on node A. Everything else is a constraint on how."},
        {"label": "Zero sign-outs during rollout", "description": "Existing signed-in users stay signed in through the deploy. Rules out a cutover that drops the in-memory map."},
        {"label": "Session lookup stays fast enough to not be felt", "description": "Puts a latency budget on the hot path; forces a decision about per-request round trips."},
        {"label": "Local dev and CI run without Redis", "description": "Keeps an in-memory implementation alive behind the same interface. Costs you a second implementation to maintain."},
        {"label": "Sessions survive a node restart / deploy", "description": "Falls out of the above for free, but worth stating if it's a reason this is happening now."}
      ]
    },
    {
      "question": "When 'fast' and 'correct across nodes' fight — say, a Redis blip — which wins?",
      "header": "Priority",
      "multiSelect": false,
      "options": [
        {"label": "Correctness: fail the request (Recommended)", "description": "A 503 on a session lookup beats silently treating a signed-in user as anonymous or as someone else."},
        {"label": "Availability: fall back to local memory", "description": "Requests keep succeeding, but sessions diverge per node and you're back to the bug you're fixing, invisibly."},
        {"label": "Availability: treat as signed out", "description": "Predictable, but a Redis hiccup mass-signs-out your users — exactly what goal 2 forbids."}
      ]
    },
    {
      "question": "What's the deadline pressure — what's forcing this now?",
      "header": "Trigger",
      "multiSelect": false,
      "options": [
        {"label": "Scaling to 3 nodes is already scheduled (Recommended)", "description": "This ships before the LB change, so rollout order matters and gets a section in Design."},
        {"label": "Already on 3 nodes and sessions are breaking", "description": "Incident mode; favours the fastest safe fix over the cleanest interface."},
        {"label": "No hard date, doing it properly first", "description": "Buys room for a dual-read/dual-write migration phase."}
      ]
    }
  ]
}
```

**Answer:**
- Slug: `redis-session-store (Recommended)`
- Goals: `Any of the 3 nodes serves any session (Recommended)`, `Zero sign-outs during rollout`, `Session lookup stays fast enough to not be felt`, `Local dev and CI run without Redis`, `Sessions survive a node restart / deploy`
- Priority: `Correctness: fail the request (Recommended)`
- Trigger: `Scaling to 3 nodes is already scheduled (Recommended)`
- Alex adds (Other, on the latency goal): "Put a number on it — session lookup has to stay under 5ms p99. That's the bar, not 'fast enough'."

### Hand-back menu after Goals

```json
{
  "questions": [
    {
      "question": "Goals is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {"label": "Continue to Non-Goals (Recommended)", "description": "What this change explicitly does not do — sticky sessions, session data model changes, auth rework, encryption at rest."},
        {"label": "Revise Goals", "description": "Tell me what's off and I'll rewrite the chapter."},
        {"label": "Pin down what 'under 5ms p99' is measured at", "description": "Client-observed vs. inside the API process, and whether the budget covers a cache hit or a Redis round trip. Changes whether an in-process cache is required."}
      ]
    }
  ]
}
```

**Answer:** `Continue to Non-Goals (Recommended)`

---

## Round 2 — Non-Goals

```json
{
  "questions": [
    {
      "question": "Things a reader would assume are in scope — which are actually out?",
      "header": "Out of scope",
      "multiSelect": true,
      "options": [
        {"label": "Sticky sessions at the load balancer (Recommended)", "description": "The obvious cheap alternative. Out because it only hides the problem until a node drains, and breaks goal 5."},
        {"label": "Changing what a session contains", "description": "Payload stays user id + roles + feature-flag bucket. Redis doesn't make a schema change any cheaper."},
        {"label": "Touching auth / login / token issuance", "description": "Only where sessions are stored changes. Sign-in flow is untouched."},
        {"label": "Moving the rate limiter's Redis usage", "description": "Rate limiter keeps its own keys and its own client config; this doesn't refactor it."},
        {"label": "Redis HA / clustering / failover work", "description": "Single Redis, as today. If we need HA that's a separate, ops-owned piece of work."}
      ]
    },
    {
      "question": "Deferred rather than rejected — which of these are 'not yet'?",
      "header": "Deferred",
      "multiSelect": true,
      "options": [
        {"label": "Encrypting session payloads at rest in Redis (Recommended)", "description": "Genuinely undecided. Defer with a written trigger rather than silently skipping it."},
        {"label": "Session listing / 'sign out everywhere'", "description": "Becomes possible once sessions are centralised, but it's a feature, not part of the migration."},
        {"label": "Absolute session lifetime on top of idle TTL", "description": "Today there's only a 30-min idle TTL. Adding a hard cap is a product decision."},
        {"label": "Sharing the session store with other services", "description": "One API owns these keys for now."}
      ]
    },
    {
      "question": "On encryption at rest — what should the doc say?",
      "header": "Encryption",
      "multiSelect": false,
      "options": [
        {"label": "Record it as an open question with a revisit trigger (Recommended)", "description": "Honest. Payload is low-sensitivity today (ids + roles + a bucket), so the trigger is 'if anything PII-shaped lands in the payload'."},
        {"label": "Do it now, AES-GCM with a key from env", "description": "Closes the question, but adds a key-rotation problem and CPU on the hot path for data that is currently ids."},
        {"label": "Decide it's never needed", "description": "Cheap today, wrong the moment someone adds an email address to the payload."}
      ]
    }
  ]
}
```

**Answer:**
- Out of scope: all five
- Deferred: all four
- Encryption: `Record it as an open question with a revisit trigger (Recommended)`
- Alex adds (Other, on sticky sessions): "Say plainly why I don't want it — it just moves the problem. I don't want this relitigated in review."

### Hand-back menu after Non-Goals

```json
{
  "questions": [
    {
      "question": "Non-Goals is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {"label": "Continue to Desired Behavior (Recommended)", "description": "Observable behavior only: what happens on read/write/expiry, on concurrent requests to different nodes, and when Redis is unreachable."},
        {"label": "Revise Non-Goals", "description": "Tell me what's off and I'll rewrite it."},
        {"label": "Add a non-goal about observability scope", "description": "Whether session metrics/tracing are part of this or come later. Thinnest spot in the chapter."}
      ]
    }
  ]
}
```

**Answer:** `Continue to Desired Behavior (Recommended)`

---

## Round 3 — Desired Behavior

```json
{
  "questions": [
    {
      "question": "The 30-minute idle TTL — what exactly does 'idle' mean once sessions are shared?",
      "header": "TTL",
      "multiSelect": false,
      "options": [
        {"label": "Every successful read slides the expiry to now+30m (Recommended)", "description": "Matches today's behavior from the user's side. Costs a write (or an expiry refresh) on every authenticated request."},
        {"label": "Only writes slide it; reads don't", "description": "Cheaper, but a user who is actively browsing read-only endpoints gets signed out mid-session. Behavior change users would notice."},
        {"label": "Slide only if more than ~1 minute has elapsed", "description": "Cuts the refresh traffic a lot for chatty clients, at the cost of up to 1 minute of TTL imprecision."}
      ]
    },
    {
      "question": "Redis is unreachable and a request arrives with a session cookie. What does the caller see?",
      "header": "Redis down",
      "multiSelect": false,
      "options": [
        {"label": "503 with a retryable error, session state untouched (Recommended)", "description": "Consistent with the goals priority. The user is not signed out; they retry and it works once Redis is back."},
        {"label": "401, treat as signed out", "description": "Would sign out every active user during a blip. Rejected in Goals."},
        {"label": "Serve the request from a stale local copy", "description": "Availability over correctness; reintroduces per-node divergence."}
      ]
    },
    {
      "question": "Two requests for the same session hit two different nodes at the same time and both write. What's acceptable?",
      "header": "Concurrency",
      "multiSelect": false,
      "options": [
        {"label": "Last write wins; no cross-node locking (Recommended)", "description": "Payload is small and rarely mutated (roles, flag bucket). Locking buys almost nothing and costs latency on every write."},
        {"label": "Optimistic concurrency, reject the stale writer", "description": "Correct for a mutable document; overkill for a 3-field session and it surfaces conflicts to callers who can't act on them."},
        {"label": "Per-session lock in Redis", "description": "Serialises writes, adds a round trip and a lock-expiry failure mode to the hot path."}
      ]
    },
    {
      "question": "What must stay identical after this ships — the regression surface?",
      "header": "Unchanged",
      "multiSelect": true,
      "options": [
        {"label": "Session cookie name, format and id shape (Recommended)", "description": "The reason existing users stay signed in. Changing the id shape is a mass sign-out by another name."},
        {"label": "Sign-out clears the session immediately, everywhere", "description": "Must take effect on all 3 nodes, not just the one that handled the request."},
        {"label": "Any route handler reading req.session keeps working unchanged", "description": "Constrains the interface: if lookup becomes async and wasn't, every call site changes."},
        {"label": "An expired session is indistinguishable from a never-existed one", "description": "No information leak about whether an id was ever valid."}
      ]
    }
  ]
}
```

**Answer:**
- TTL: `Every successful read slides the expiry to now+30m (Recommended)`
- Redis down: `503 with a retryable error, session state untouched (Recommended)`
- Concurrency: `Last write wins; no cross-node locking (Recommended)`
- Unchanged: all four
- Alex adds (Other, on TTL): "Redis key expiry does the expiring. I don't want a sweeper task — that's a thing to operate and get wrong."

### Hand-back menu after Desired Behavior

```json
{
  "questions": [
    {
      "question": "Desired Behavior is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {"label": "Continue to Design & Implementation Details (Recommended)", "description": "The interface, the two implementations, key layout, TTL mechanics, and the rollout that keeps people signed in."},
        {"label": "Revise Desired Behavior", "description": "Tell me what's off and I'll rewrite it."},
        {"label": "Work through what happens mid-rollout", "description": "While node A is old-build and node B is new-build, behavior is genuinely mixed. Currently only implied."}
      ]
    }
  ]
}
```

**Answer:** `Continue to Design & Implementation Details (Recommended)`

---

## Round 4 — Design & Implementation Details

```json
{
  "questions": [
    {
      "question": "The seam. What does the interface both implementations satisfy look like?",
      "header": "Interface",
      "multiSelect": false,
      "options": [
        {
          "label": "Async SessionStore, TTL owned by the store (Recommended)",
          "description": "Four methods, all async. touch() is separate from get() so the caller decides when to slide. Callers must already be async-friendly.",
          "preview": "export type SessionId = string;\n\nexport interface Session {\n  userId: string;\n  roles: string[];\n  flagBucket: string;\n}\n\nexport interface SessionStore {\n  get(id: SessionId): Promise<Session | undefined>;\n  set(id: SessionId, s: Session): Promise<void>;\n  touch(id: SessionId): Promise<void>;\n  delete(id: SessionId): Promise<void>;\n}"
        },
        {
          "label": "get() slides the TTL implicitly",
          "description": "Three methods instead of four; the sliding is invisible. Costs you the ability to read a session without extending it (health checks, admin tooling).",
          "preview": "export interface SessionStore {\n  // get() also refreshes expiry as a side effect\n  get(id: SessionId): Promise<Session | undefined>;\n  set(id: SessionId, s: Session): Promise<void>;\n  delete(id: SessionId): Promise<void>;\n}"
        },
        {
          "label": "Wider interface with listing/scan",
          "description": "Room for 'sign out everywhere' later, but it's a non-goal now and SCAN over the keyspace is a footgun you'd have to document."
        }
      ]
    },
    {
      "question": "Redis key layout and payload encoding?",
      "header": "Keys",
      "multiSelect": false,
      "options": [
        {
          "label": "One JSON string per session under session:<id>, EX 1800 (Recommended)",
          "description": "One round trip per read, one per write. Namespaced so it never collides with the rate limiter's keys. GET+EXPIRE for touch, or GETEX in one call.",
          "preview": "SET  session:7f3c… '{\"userId\":\"u_42\",\"roles\":[\"admin\"],\"flagBucket\":\"b3\"}' EX 1800\nGETEX session:7f3c… EX 1800     # read + slide, one round trip\nDEL  session:7f3c…"
        },
        {
          "label": "Redis HASH per session, HGETALL + EXPIRE",
          "description": "Lets you update one field without rewriting the payload. Two round trips for a read-and-slide, and no field is updated independently today.",
          "preview": "HSET   session:7f3c… userId u_42 flagBucket b3\nEXPIRE session:7f3c… 1800\nHGETALL session:7f3c…"
        },
        {
          "label": "MessagePack / other binary encoding",
          "description": "Smaller payloads, but these are ~100 bytes. Buys nothing here and makes redis-cli debugging worse."
        }
      ]
    },
    {
      "question": "How do we get from the in-memory Map to Redis without signing anyone out?",
      "header": "Rollout",
      "multiSelect": false,
      "options": [
        {"label": "Dual-read, Redis-primary, deploy to 3 nodes while still on 1 (Recommended)", "description": "Phase 1: write to Redis, read Redis then fall back to the local Map, on a single node. Existing in-memory sessions drain naturally within 30 min. Phase 2 (next day): drop the fallback, then add nodes 2 and 3."},
        {"label": "Hard cutover to Redis, accept the sign-outs", "description": "Simplest code, violates goal 2. Every currently-signed-in user is dropped at deploy time."},
        {"label": "Migrate the Map contents into Redis at boot", "description": "Preserves existing sessions with no dual-read path, but only works for the sessions that happen to live on the node being restarted, and it's a one-shot script you can't easily re-run."}
      ]
    },
    {
      "question": "Do we need an in-process cache in front of Redis to hold the 5ms p99?",
      "header": "Latency",
      "multiSelect": false,
      "options": [
        {"label": "No cache; measure first (Recommended)", "description": "A same-AZ Redis GET is well under 1ms. Add a cache only if measurement says otherwise — and a cache reintroduces per-node staleness, which is the bug we're fixing."},
        {"label": "Short-lived (1–2s) in-process cache now", "description": "Cuts Redis traffic, but a signed-out user stays signed in for up to 2s on a node that cached them. Directly weakens sign-out semantics."},
        {"label": "Cache only negative lookups", "description": "Narrower blast radius, but unknown-id lookups aren't the hot path."}
      ]
    }
  ]
}
```

**Answer:**
- Interface: `Async SessionStore, TTL owned by the store (Recommended)`
- Keys: `One JSON string per session under session:<id>, EX 1800 (Recommended)` — Alex notes: "GETEX, so read-and-slide is one round trip. And key expiry does the expiring, as agreed."
- Rollout: `Dual-read, Redis-primary, deploy to 3 nodes while still on 1 (Recommended)`
- Latency: `No cache; measure first (Recommended)`

### Hand-back menu after Design & Implementation Details

```json
{
  "questions": [
    {
      "question": "Design is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {"label": "Continue to Testing Strategy (Recommended)", "description": "Which behaviors get tests, at what level, what talks to a real Redis, and what keeps these tests from breaking on refactors."},
        {"label": "Revise Design & Implementation Details", "description": "Tell me what's off and I'll rewrite it."},
        {"label": "Spell out how we verify the 5ms p99 before phase 3", "description": "The design says 'measure first' but doesn't say with what, or what result blocks the rollout."}
      ]
    }
  ]
}
```

**Answer:** `Continue to Testing Strategy (Recommended)`

---

## Round 5 — Testing Strategy

```json
{
  "questions": [
    {
      "question": "Two implementations, one interface. How do we test them?",
      "header": "Shared suite",
      "multiSelect": false,
      "options": [
        {
          "label": "One contract suite run against both implementations (Recommended)",
          "description": "Write the behavior once; run it over InMemory and Redis. The in-memory store stays honest instead of drifting into a different set of semantics.",
          "preview": "// session-store.contract.ts\nexport function describeSessionStore(\n  name: string,\n  createStore: () => Promise<{store: SessionStore; dispose(): Promise<void>}>\n) {\n  describe(name, () => {\n    it('returns a session written under the same id', …);\n    it('returns undefined for an unknown id', …);\n    it('expires a session after the idle TTL', …);\n    it('slides expiry on touch', …);\n    it('deletes immediately on sign-out', …);\n  });\n}\n\ndescribeSessionStore('InMemorySessionStore', …);\ndescribeSessionStore('RedisSessionStore', …);  // testcontainers"
        },
        {"label": "Separate hand-written suites per implementation", "description": "More freedom per implementation, and the two quietly diverge — which is precisely the risk when one of them only ever runs in CI."},
        {"label": "Only test the Redis one; in-memory is trivial", "description": "The in-memory store is what every local test runs against. An untested one makes every other test a liar."}
      ]
    },
    {
      "question": "What does the Redis side of that suite talk to?",
      "header": "Real Redis",
      "multiSelect": false,
      "options": [
        {"label": "A real Redis in testcontainers, node:test (Recommended)", "description": "Matches how this codebase already tests things touching a real backing service. Catches TTL and GETEX semantics a fake would let you fake wrong."},
        {"label": "ioredis-mock or similar in-process fake", "description": "Fast and dependency-free, but the whole risk here is Redis-specific expiry behavior — exactly the part a fake reimplements approximately."},
        {"label": "A shared Redis on a CI-only host", "description": "No container overhead; introduces cross-test-run interference and a shared piece of infrastructure to keep alive."}
      ]
    },
    {
      "question": "Idle expiry is a 30-minute behavior. How do we test it without a 30-minute test?",
      "header": "TTL test",
      "multiSelect": false,
      "options": [
        {"label": "Make TTL a store constructor parameter; test with 1s (Recommended)", "description": "Real Redis expiry, real clock, second-scale test. The value being configurable is useful in its own right."},
        {"label": "Assert on the TTL Redis reports (PTTL) rather than waiting", "description": "Instant and non-flaky, but it tests that we sent the right command, not that the session actually disappears. Good as a complement."},
        {"label": "Fake timers", "description": "Doesn't work — the expiry happens inside Redis, which does not share our clock."}
      ]
    },
    {
      "question": "Which behaviors deserve a test above the store level?",
      "header": "Levels",
      "multiSelect": true,
      "options": [
        {"label": "Cross-node: write via app instance A, read via instance B (Recommended)", "description": "Two Fastify instances against one containerised Redis. This is goal 1, and nothing below this level proves it."},
        {"label": "Redis unreachable → 5xx, not 401", "description": "Goal 2's failure mode. Stop the container mid-test and assert the status code."},
        {"label": "Sign-out on instance A is visible on instance B", "description": "Falls out of the cross-node harness for almost no extra cost."},
        {"label": "Migration decorator: Redis miss falls back to the Map and promotes", "description": "Temporary code deleted in phase 2 — but it runs in production during phase 1 carrying every live session."}
      ]
    }
  ]
}
```

**Answer:**
- Shared suite: `One contract suite run against both implementations (Recommended)`
- Real Redis: `A real Redis in testcontainers, node:test (Recommended)`
- TTL test: `Make TTL a store constructor parameter; test with 1s (Recommended)` — plus the PTTL assertion as a fast complement
- Levels: all four
- Alex adds (Other): "Drive the contract suite test-first. The interface is the thing I most want to get right, and writing the tests first is how I find out whether it's usable."

### Hand-back menu after Testing Strategy

```json
{
  "questions": [
    {
      "question": "Testing Strategy is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {"label": "Continue to Alternatives Considered (Recommended)", "description": "Last chapter. I'll present back the options you turned down and we confirm why, plus what would make us revisit each."},
        {"label": "Revise Testing Strategy", "description": "Tell me what's off and I'll rewrite it."},
        {"label": "Decide the p99 number that blocks phase 3", "description": "Currently a TODO. It's the only gate between the migration and adding nodes."}
      ]
    }
  ]
}
```

**Answer:** `Continue to Alternatives Considered (Recommended)`

---

## Round 6 — Alternatives Considered

```json
{
  "questions": [
    {
      "question": "Here's what you turned down along the way. Confirm these belong in the chapter?",
      "header": "Harvest",
      "multiSelect": true,
      "options": [
        {"label": "Sticky sessions at the LB (Recommended)", "description": "Cheapest possible option — no code at all. Lost because it fails on drain/restart and blocks goal 5."},
        {"label": "In-process cache in front of Redis", "description": "Would guarantee the 5ms budget. Lost because it reintroduces per-node staleness and weakens sign-out."},
        {"label": "Hard cutover / boot-time Map migration", "description": "Much simpler rollout. Lost to goal 2 and to being one-shot and unrepeatable."},
        {"label": "Redis HASH instead of a JSON string", "description": "Per-field updates. Lost on round-trip count with no per-field update to justify it."},
        {"label": "ioredis-mock instead of testcontainers", "description": "Faster CI, no container. Lost because expiry semantics are the risk and a fake reimplements them."},
        {"label": "Sweeper task for expiry", "description": "Would work with any store. Lost because Redis key expiry already does it with nothing to operate."}
      ]
    },
    {
      "question": "Anything you'd already ruled out before we started that should be recorded?",
      "header": "Pre-rejected",
      "multiSelect": true,
      "options": [
        {"label": "Stateless JWT sessions instead of a session store (Recommended)", "description": "No shared store needed at all. But you can't revoke one, which breaks sign-out semantics."},
        {"label": "Sessions in Postgres", "description": "Already in the stack, durable, but adds row churn and a sweeper for expiry on the hot path."},
        {"label": "A dedicated session service", "description": "Another deployable for a Map with a TTL."},
        {"label": "Nothing else — the list above is complete", "description": "Skip this question."}
      ]
    }
  ]
}
```

**Answer:**
- Harvest: all six
- Pre-rejected: `Stateless JWT sessions instead of a session store (Recommended)`, `Sessions in Postgres`, `A dedicated session service`
- Alex adds (Other, on JWT): "That one comes up every single time. Write down why it loses so I can point at it."

### Final menu — doc complete

```json
{
  "questions": [
    {
      "question": "All six chapters are written: design-docs/redis-session-store.md. What now?",
      "header": "Done",
      "multiSelect": false,
      "options": [
        {"label": "Consistency read-through, top to bottom (Recommended)", "description": "Check the Goals still match the design they produced, and close or confirm the two remaining TODOs (encryption, the p99 gate)."},
        {"label": "Start implementing against the doc", "description": "Begin with the contract suite test-first, then InMemorySessionStore, then RedisSessionStore."},
        {"label": "Leave it here for review", "description": "Circulate as-is; the TODOs are marked and visible."}
      ]
    }
  ]
}
```

**Answer:** `Other: Leave it — I want to read it myself first, then take it to the team. Don't start implementing.`
