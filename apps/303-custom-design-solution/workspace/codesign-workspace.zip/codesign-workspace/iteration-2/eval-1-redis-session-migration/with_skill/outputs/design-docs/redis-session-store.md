# Redis Session Store

> Status: Draft · 2026-09-24

## Goals

Ranked. When two conflict, the higher one wins.

1. **A request landing on any of the 3 nodes finds a session created on any other node.** This is the whole point; the API is about to sit behind a load balancer with no affinity.
2. **Nobody gets signed out because of this change.** Signed-in users stay signed in across the rollout — no mass session invalidation, not even a short window of it.
3. **Session lookup stays under 5ms p99.** A number, not a vibe. Sessions are read on effectively every authenticated request, so this is the hot path.
4. **Local dev and CI run without Redis.** An in-memory implementation stays available behind the same interface; nobody needs a container running to `npm test` or boot the API locally.
5. **Sessions survive a node restart or deploy.** Falls out of goals 1–2, but it's a real improvement over today and worth naming.

**Priority when they conflict:** correctness beats availability. If Redis is unreachable, the request fails loudly (5xx) rather than falling back to a local map — a silent per-node fallback recreates exactly the bug this work exists to remove, and hides it. Treating the user as signed out is also out, because it violates goal 2.

**What's forcing this now:** the move from 1 node to 3 behind a load balancer is already scheduled. This has to land *before* the LB change, which makes rollout ordering a real design constraint rather than an afterthought.

## Non-Goals

**Not in scope — don't assume otherwise:**

- **Sticky sessions at the load balancer.** Rejected on principle, not deferred: it just moves the problem. It holds until a node drains, restarts or is removed from the pool, and it quietly makes goal 5 impossible. We don't want this reopened in review.
- **Changing what a session contains.** Payload stays user id, roles, feature-flag bucket. Redis doesn't make a schema change cheaper, and bundling one makes the rollback story worse.
- **Auth, login, token issuance.** Only *where* session state lives changes. The sign-in flow is untouched.
- **Refactoring the rate limiter's Redis usage.** It keeps its own keys and client config. Shared dependency, separate concerns.
- **Redis HA, clustering or failover.** Single Redis instance, same as today. If we need HA, that's separate, ops-owned work.

**Deferred — not yet:**

- **Encrypting session payloads at rest in Redis.** Open question, deliberately. Today's payload is ids, roles and a bucket — low sensitivity. _Revisit trigger: the first time anything PII-shaped (email, name, address) is added to the session payload._
- **Session listing / "sign out everywhere".** Centralised sessions make it possible; it's a feature, not part of this migration.
- **Absolute session lifetime on top of the 30-minute idle TTL.** A product decision, not a storage one.
- **Sharing the session store with other services.** This API owns these keys for now.

## Desired Behavior

Observable from outside the process. No implementation here.

**Happy path — session follows the user across nodes**

- *Given* a user signs in and node A creates a session,
- *When* their next request is load-balanced to node B or C,
- *Then* it is served as the same signed-in user, with the same roles and the same feature-flag bucket.

**Idle expiry**

- Every *successful* session read slides the expiry to now + 30 minutes — same as today from the user's side. A user clicking around read-only endpoints does not get signed out.
- After 30 minutes with no reads, the session is gone on every node at once.
- Expiry is the storage layer's job, on the key itself. There is no sweeper task, no periodic scan, nothing to operate.

**Sign-out**

- *Given* a user signs out on node A,
- *When* their next request reaches node B,
- *Then* they are signed out there too, immediately — not after a TTL.

**Concurrent writes from different nodes**

- Two nodes writing the same session at the same time: **last write wins.** No cross-node locking, no conflict surfaced to the caller. The payload is three rarely-mutated fields; ordering between two near-simultaneous writes is not something a caller could act on anyway.

**When the store is unreachable**

- A request carrying a session cookie gets a **retryable 5xx**, not a 401. Session state is left untouched, and the same cookie works once the store is back.
- The user sees an error and can retry. The user does **not** see a sign-in page — that would be goal 2 violated by a network blip.

**Unknown / expired session id**

- Treated exactly like a session that never existed. No way to tell from the outside whether an id was ever valid.

**Must stay unchanged (regression surface)**

- Session cookie name, format, and session id shape — this is precisely what keeps signed-in users signed in through the rollout.
- Every existing route handler that reads the session keeps working without being rewritten.
- Sign-out semantics as above.
- The ~5k concurrent sessions we carry today keep working at the same request rates.

## Design & Implementation Details

### The seam: one interface, two implementations

Everything hangs off a single `SessionStore` interface. Route handlers depend on the
interface, never on Redis.

```ts
export type SessionId = string;

export interface Session {
  userId: string;
  roles: string[];
  flagBucket: string;
}

export interface SessionStore {
  get(id: SessionId): Promise<Session | undefined>;
  set(id: SessionId, session: Session): Promise<void>;
  touch(id: SessionId): Promise<void>;
  delete(id: SessionId): Promise<void>;
}
```

*Why all-async:* the in-memory implementation doesn't need it, but if the interface is
sync it can never be backed by Redis. The interface is shaped by the hardest
implementation, not the easiest.

*Why `touch()` is separate from `get()`:* implicit sliding means you can never read a
session without extending it. Keeping them apart leaves room for health checks and
admin tooling that look without touching. The request path calls `get()` then `touch()`
— see the round-trip note below.

*Why the store owns TTL:* it's the only layer that can implement it as key expiry.
Push it up and you're back to a sweeper.

Two implementations:

- `InMemorySessionStore` — a `Map` plus per-entry expiry, essentially today's code
  behind the new interface. This is what local dev and CI use. It is **not** a
  deprecated shim; it is a supported implementation, and goal 4 depends on it staying
  that way.
- `RedisSessionStore` — the production one. Reuses the Redis connection config that
  the rate limiter already uses; separate client instance, separate key namespace.

Selection is config, not code: `SESSION_STORE=memory|redis`, defaulting to `memory`
locally and set explicitly to `redis` in deployed environments.

### Redis key layout

One JSON string per session, namespaced so it can never collide with rate-limiter keys:

```
SET   session:<id> '{"userId":"u_42","roles":["admin"],"flagBucket":"b3"}' EX 1800
GETEX session:<id> EX 1800     # read and slide in a single round trip
DEL   session:<id>
```

- **JSON string, not a HASH.** No field is ever updated independently today, and a
  read-and-slide on a HASH costs two round trips. Readable in `redis-cli`, which
  matters more than the ~100 bytes a binary encoding would save.
- **`EX 1800` is the whole TTL mechanism.** 30-minute idle expiry is Redis key expiry.
  No sweeper, no scheduled job, nothing to operate — this was an explicit requirement.
- **`GETEX` collapses `get` + `touch` into one round trip** on the hot path. The
  interface keeps them separate; the Redis implementation is free to fuse them when
  the caller does both, which is the common case.
- **Session ids are unchanged.** Same generator, same shape, same cookie. That is what
  makes existing cookies keep working.

### Failure handling

A Redis error on the session path propagates as a **retryable 5xx**. It is never
swallowed, never downgraded to "no session", and never served from a local fallback.
The fallback is the tempting mistake here: it would make every incident invisible and
recreate per-node divergence exactly when we're least able to notice.

### Rollout — three nodes, zero sign-outs

Ordering matters because the load-balancer change is already scheduled.

**Phase 1 — dual-read, still on one node.** Deploy `RedisSessionStore` wrapped in a
migration decorator: writes go to Redis only; reads try Redis first and fall back to
the existing in-memory `Map`, promoting any hit into Redis on the way through. Still
one node, so the fallback is always the *same* node's map — it is correct, not a
guess. Existing signed-in users keep their sessions; within 30 minutes of idle TTL the
in-memory map has drained to zero.

**Phase 2 — drop the fallback.** Next deploy (a day later is plenty), remove the
decorator. Redis is now the only store. Still one node, so this is independently
verifiable before any topology change.

**Phase 3 — scale to three nodes.** Only now does the load balancer get nodes 2 and 3.
By this point the multi-node behavior has already been proven on one node.

*Why not migrate the Map into Redis at boot:* one-shot, unrepeatable, and it only
covers whatever happened to be on the node being restarted. The dual-read window costs
one extra deploy and is re-runnable.

### What's new vs. what changes

- **New:** `SessionStore` interface, `InMemorySessionStore`, `RedisSessionStore`, the
  migration decorator (deleted in phase 2), the `SESSION_STORE` config switch.
- **Changed:** wherever the `Map` is touched directly today becomes a `SessionStore`
  call. The Fastify request decorator that exposes the session keeps the same shape so
  route handlers are untouched.
- **Load-bearing dependencies:** Redis (already in the stack for the rate limiter — no
  new operational surface) and the Redis client library already in use. Nothing else
  is added.

### Open question

- **Encrypting payloads at rest.** Not decided. See Non-Goals for the revisit trigger.
  `TODO:` decide before any PII-shaped field enters `Session`.

## Testing Strategy

### A shared contract suite, run against both implementations

The behavior is written once and executed against `InMemorySessionStore` and
`RedisSessionStore` both. The in-memory store is what every local test and CI run
sits on, so if the two drift, every other test in the repo is quietly lying.

```ts
// session-store.contract.ts
export function describeSessionStore(
  name: string,
  createStore: () => Promise<{ store: SessionStore; dispose(): Promise<void> }>,
) {
  describe(name, () => {
    it('returns a session written under the same id', …);
    it('returns undefined for an unknown id', …);
    it('returns undefined for an expired id — indistinguishable from unknown', …);
    it('expires a session after the idle TTL', …);
    it('slides expiry on touch', …);
    it('deletes immediately on sign-out', …);
    it('last write wins when two writers race', …);
  });
}

describeSessionStore('InMemorySessionStore', …);
describeSessionStore('RedisSessionStore', …);   // testcontainers
```

**Written test-first.** The interface is the highest-stakes decision in the doc, and
writing the contract before either implementation is how we find out whether it's
actually usable rather than merely plausible.

### What's real and what's faked

- **Real Redis via testcontainers**, driven from `node:test` — the way this codebase
  already tests anything touching a real backing service. The risk we're managing is
  Redis-specific expiry and `GETEX` semantics; a fake reimplements exactly that part,
  approximately, and would let us be confidently wrong.
- **Nothing is faked at the store seam.** The seam exists for production
  configurability, not as a test shortcut.
- Above the store, tests use a real store instance (in-memory or Redis as appropriate),
  not a stub.

### Testing a 30-minute TTL in under a second

- **TTL is a constructor parameter on the store**, so the suite runs it at ~1 second:
  real Redis, real clock, real expiry, second-scale test. Configurable TTL is worth
  having anyway.
- Complemented by a fast, non-flaky assertion on the TTL Redis reports (`PTTL`) after
  a write and after a `touch` — that one catches "we sent the wrong command" instantly,
  while the waiting test catches "the session actually disappears".
- Fake timers are useless here: the expiry happens inside Redis, which doesn't share
  our clock.

### Integration level — the goals that no unit test can prove

Two Fastify instances against one containerised Redis:

1. **Cross-node continuity.** Sign in through instance A, make an authenticated request
   against instance B, get served as the same user. This is goal 1; nothing below this
   level demonstrates it.
2. **Sign-out propagates.** Sign out on A, next request on B is signed out. Nearly free
   once the harness above exists.
3. **Store unreachable → 5xx, not 401.** Stop the Redis container mid-test, assert the
   status code and that the cookie still works after restarting it. This is the one
   that protects goal 2 from a well-meaning "just fall back to local memory" patch.
4. **Migration decorator.** Redis miss falls back to the in-memory map, returns the
   session, and promotes it into Redis. Temporary code — but it carries every live
   session during phase 1, so it gets tests despite being deleted in phase 2.

### What would make these tests brittle

- **Asserting on Redis commands or key strings** instead of observable behavior. The
  contract suite deliberately knows nothing about `GETEX` — that's an implementation
  choice we should be able to change without touching tests.
- **Sharing one Redis container across tests without namespacing keys.** Each test gets
  its own key prefix or its own container.
- **Sleeping on wall-clock time longer than necessary.** Short configured TTLs with a
  polling assertion, not fixed long sleeps.

### The 5ms p99 goal

Not a unit test. Measured on the phase-2 single-node deployment, before any node is
added, against the existing request-latency metrics. `TODO:` decide what measured p99
blocks phase 3.

## Alternatives Considered

**Sticky sessions at the load balancer.** Tempting because it's zero code — the LB
change is happening anyway. Lost because it only moves the problem: it holds right up
until a node drains, restarts or leaves the pool, which is every single deploy. It also
makes goal 5 unreachable. _Revisit if:_ never, for session correctness. Session affinity
for unrelated reasons (cache warmth) is a separate conversation.

**Stateless JWT sessions — no shared store at all.** The most tempting option on paper:
multi-node works by construction, no Redis on the request path. Lost because you cannot
revoke a JWT. Sign-out would become "expires eventually", and a role change wouldn't
take effect until the token rolled. That breaks the sign-out behavior in Desired
Behavior outright. _Revisit if:_ we accept a revocation delay measured in minutes — and
note that a revocation list is a shared store again, which is this design with extra
steps.

**Sessions in Postgres.** Already in the stack, durable across a Redis wipe. Lost on the
hot path: a row read and an expiry sweep per request, plus write churn on a table whose
rows all die within 30 minutes. Redis was already there for the rate limiter, so it's
not a new operational dependency either way. _Revisit if:_ sessions ever need to be
durable across a full Redis loss, or need to be queried/joined.

**A dedicated session service.** Rejected quickly: another deployable, another network
hop, and another thing to page someone about, to hold a Map with a TTL.

**In-process cache in front of Redis.** Would make the 5ms p99 a certainty rather than a
measurement. Lost because a cached session is a stale session: a signed-out user stays
signed in on whichever node cached them, for as long as the cache holds. That's
per-node divergence — the exact bug this work removes. _Revisit if:_ measured p99 on the
phase-2 deployment misses the 5ms budget. Then a sub-second cache with explicit
invalidation on sign-out, and the sign-out tests get correspondingly harder.

**Hard cutover, or migrating the Map into Redis at boot.** Both much simpler than the
dual-read phase. Hard cutover signs everyone out, which goal 2 forbids. The boot-time
migration only captures whatever lives on the node being restarted and is a one-shot
script you can't easily re-run. The dual-read window costs one extra deploy and is
re-runnable. _Revisit if:_ we ever need this again in a context where a sign-out is
acceptable.

**Redis HASH per session instead of a JSON string.** Would allow updating one field
without rewriting the payload. Lost because no field is ever updated independently
today, and read-and-slide on a HASH is two round trips against `GETEX`'s one. _Revisit
if:_ the payload grows enough that rewriting it per mutation costs something, or a
field starts being updated on its own.

**A sweeper task for expiry.** Store-agnostic, works anywhere. Lost because Redis key
expiry already does it with nothing to schedule, nothing to monitor and nothing to get
wrong at 3am. _Revisit if:_ we move off a store with native key expiry.

**`ioredis-mock` instead of testcontainers.** Faster CI, no Docker. Lost because the
specific risk being managed is Redis expiry and `GETEX` semantics — the exact part a
fake reimplements approximately. _Revisit if:_ container startup dominates CI time; even
then, the fake would supplement the contract suite, not replace its Redis run.
