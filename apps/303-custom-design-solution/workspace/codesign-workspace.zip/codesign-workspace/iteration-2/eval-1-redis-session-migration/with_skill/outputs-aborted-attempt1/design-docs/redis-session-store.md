# Redis Session Store

> Status: Draft · 2026-09-24

## Goals

Ranked. 1 beats 2 beats 3 beats 4 when they conflict.

1. **A request that lands on any node sees a session created on any other node** — three nodes behind the load balancer, no sticky routing, no per-node session state.
2. **No signed-in user is signed out by the cutover** — all ~5k live sessions survive the deploy. Mass invalidation is off the table.
3. **Session lookup stays under 5ms p99** — a network hop replaces a `Map` read, and that has to stay invisible to request latency.
4. **Local dev and CI run with no Redis** — the in-memory implementation stays a supported, exercised path behind the same interface.

### Priority notes

- Goals 2 and 3 are not the same kind of promise. **During the cutover, goal 2 is absolute** — we do not invalidate 5k sessions to make the migration simpler. **In steady state it is softer**: if Redis hiccups and some people have to sign in again, that is survivable — but it must not be silent (see Desired Behavior for what "not silent" means).
- Goal 3 is never bought with staleness. No in-process session cache in front of Redis, at any TTL — that is how a revoked session keeps working on node 3. If p99 misses, we fix it in infrastructure.

### What's forcing this now

Scaling from 1 node to 3 behind a load balancer. The current store is a plain `Map` keyed by session id, so today session affinity is accidental (there is only one node) and after the scale-out it would be broken.

### How we'll know it worked

- 3 nodes serving, sticky sessions off at the load balancer, session-related 401 rate flat week over week.
- p99 of session lookup under 5ms in APM (requires the lookup to be its own instrumented span).
- CI green with no Redis container running.

## Non-Goals

- **Sticky sessions at the load balancer** — rejected, not deferred. Pinning a user to a node makes the `Map` "work", but a deploy, a scale-in or a lost node still drops their session. It moves the problem instead of solving it.
- **A background sweeper for expired sessions** — Redis key expiry is the mechanism. A sweeper would be our code, running on three nodes, racing itself, for something the datastore already does.
- **Moving any other in-memory state to Redis** — sessions only. Anything else process-local is its own piece of work.
- **Changing the session payload or the 30-minute idle TTL** — same fields (user id, roles, feature-flag bucket), same lifetime, same idle-refresh semantics. This migration is behavior-neutral by design; that is what makes the rollback boring.
- **Redis HA / failover topology** — we inherit whatever the rate limiter already runs on. Redesigning the Redis deployment is a separate conversation with whoever owns it.
- **Stateless / JWT sessions** — would delete the lookup entirely, but gives up server-side revocation and is a far bigger change than a scale-out justifies. See Alternatives Considered.
- **Encrypting session payloads at rest in Redis** — *not yet*. The payload is a user id, roles and a feature-flag bucket: no credentials, no PII beyond the id. **Revisit if** anything sensitive is added to the payload, or if the set of people and services that can read this Redis instance widens beyond the team that already reads the rate-limiter keys.
- **"Sign out everywhere" / bulk revocation** — no feature in this work. But the key layout is chosen so a per-user session index can be added later without re-keying live sessions (see Design).

## Desired Behavior

_Pending._

## Design & Implementation Details

_Pending._

## Testing Strategy

_Pending._

## Alternatives Considered

_Pending._
