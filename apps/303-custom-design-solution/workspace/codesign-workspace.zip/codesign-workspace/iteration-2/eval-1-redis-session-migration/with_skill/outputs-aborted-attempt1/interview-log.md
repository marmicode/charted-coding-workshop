# Interview Log — Redis Session Store

Every `AskUserQuestion` call that would have been made, in order, with the answer
that came back.

## Round 1 — Goals

```json
{
  "questions": [
    {
      "question": "I've created the skeleton at design-docs/redis-session-store.md. Does that filename work, or would you rather search for something else later?",
      "header": "Filename",
      "multiSelect": false,
      "options": [
        {
          "label": "redis-session-store.md",
          "description": "(Recommended) Names the thing being built, so it still reads right after the migration is ancient history.",
          "preview": "design-docs/\n└── redis-session-store.md"
        },
        {
          "label": "session-store-multi-node.md",
          "description": "Names the problem (running >1 node) rather than the chosen backend. Ages better if you ever swap Redis out.",
          "preview": "design-docs/\n└── session-store-multi-node.md"
        },
        {
          "label": "migrate-sessions-to-redis.md",
          "description": "Reads as a one-off migration ticket; risks looking stale once the migration is done even though the design is still live.",
          "preview": "design-docs/\n└── migrate-sessions-to-redis.md"
        }
      ]
    },
    {
      "question": "Which of these are actually goals of this work? (I'll rank them in the doc.)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {
          "label": "Any node can serve any request",
          "description": "(Recommended) The forcing goal: a request landing on node 2 sees a session created on node 1, with no sticky routing at the load balancer."
        },
        {
          "label": "Nobody gets signed out during the rollout",
          "description": "Existing sessions survive the deploy. Rules out the cheap option of just flushing everything and letting people sign in again."
        },
        {
          "label": "Session lookup stays under 5ms p99",
          "description": "A per-request network hop replaces a Map read. Making this a stated goal means it gets measured, not assumed."
        },
        {
          "label": "Local dev and CI run without Redis",
          "description": "Keeps the in-memory path a supported implementation, not dead code. Costs you an interface and two implementations to keep honest."
        },
        {
          "label": "Sessions survive a node restart",
          "description": "A side effect of moving off the Map, but stating it as a goal invites scope (persistence guarantees, Redis durability config)."
        }
      ]
    },
    {
      "question": "When the 5ms p99 budget and \"nobody gets signed out\" pull against each other — say holding 5ms means caching sessions in-process and occasionally serving a stale/revoked one — which wins?",
      "header": "Priority",
      "multiSelect": false,
      "options": [
        {
          "label": "Correctness wins; eat the latency",
          "description": "(Recommended) Every lookup goes to Redis. If p99 creeps over 5ms you fix it with infrastructure, not with staleness."
        },
        {
          "label": "Latency wins; short in-process cache",
          "description": "Sub-second TTL cache in front of Redis. Fast, but a revoked session stays valid for that window and behavior differs per node."
        },
        {
          "label": "Record the tension, decide under load",
          "description": "Ship the simple version, revisit only if real p99 data misses. Leaves the decision undocumented until it's urgent."
        }
      ]
    },
    {
      "question": "What observable signal tells you this worked?",
      "header": "Success signal",
      "multiSelect": true,
      "options": [
        {
          "label": "3 nodes, no sticky config, 401 rate flat",
          "description": "(Recommended) The end state and the failure mode in one number: session-related 401s unchanged week over week with sticky sessions off at the LB."
        },
        {
          "label": "p99 session lookup under 5ms in APM",
          "description": "Direct measurement of the latency goal. Needs the lookup instrumented as its own span, which is a small piece of work to plan for."
        },
        {
          "label": "CI green with no Redis container",
          "description": "Proves the in-memory implementation is still a real, exercised path rather than something that rotted."
        },
        {
          "label": "No logged-out complaints after deploy",
          "description": "Lagging and noisy — you hear about it days later, and only from people who bother to report it."
        }
      ]
    }
  ]
}
```

**Answer:**
- Filename: `redis-session-store.md`
- Goals: `Any node can serve any request`, `Nobody gets signed out during the rollout`, `Session lookup stays under 5ms p99`, `Local dev and CI run without Redis`
- Priority: `Other: Careful — those are two different things. "Nobody gets signed out" is about the rollout, not about steady state. During the cutover it's absolute: I will not mass-invalidate 5k sessions. In steady state, if Redis hiccups and a few people have to sign in again, that's survivable — I just don't want it silent. And no in-process session cache, ever: that's how you get a revoked session still working on node 3.`
- Success signal: `3 nodes, no sticky config, 401 rate flat`, `p99 session lookup under 5ms in APM`, `CI green with no Redis container`

### Parked (volunteered early, belongs in a later chapter)

- "No in-process session cache, ever" → recorded as a priority note in Goals, expanded in **Design & Implementation Details**.
- "A Redis hiccup signing people out must not be silent" → **Desired Behavior** (failure mode).
- From the brief: TTL via Redis key expiry rather than a sweeper → **Design & Implementation Details**.
- From the brief: node:test + testcontainers → **Testing Strategy**.
- From the brief: sticky sessions rejected, encryption at rest undecided → **Alternatives Considered**.

## Hand-back after Goals

```json
{
  "questions": [
    {
      "question": "Goals is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Non-Goals",
          "description": "(Recommended) What this explicitly is not: the scope a reviewer would otherwise assume, what we're deferring, and what we rejected on principle (sticky sessions, a TTL sweeper)."
        },
        {
          "label": "Revise Goals",
          "description": "Tell me what's off and I'll rewrite it before anything downstream depends on it."
        },
        {
          "label": "Pin down what \"not silent\" means for a Redis hiccup",
          "description": "The softest line in the chapter. It's really a Desired Behavior question, but if you want the failure policy settled before scoping, we can do it now."
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Non-Goals`

## Round 2 — Non-Goals

```json
{
  "questions": [
    {
      "question": "Which of these should the doc explicitly put out of scope?",
      "header": "Non-goals",
      "multiSelect": true,
      "options": [
        {
          "label": "Sticky sessions at the load balancer",
          "description": "(Recommended) Rejected on principle, not deferred: it makes the Map work by pinning users to a node, so a deploy or a node loss still drops sessions. Same problem, moved."
        },
        {
          "label": "A background sweeper for expired sessions",
          "description": "(Recommended) Redis key expiry does this. A sweeper would be code we own, running on three nodes, racing itself."
        },
        {
          "label": "Moving other in-memory state to Redis",
          "description": "Anything else living in a process-local structure is its own piece of work. This doc covers sessions only."
        },
        {
          "label": "Changing the session payload or the 30-minute idle TTL",
          "description": "The shape and lifetime stay exactly as they are. Keeps the diff reviewable and the rollback boring."
        },
        {
          "label": "Redis HA / failover topology",
          "description": "We inherit whatever the rate limiter already runs on. Redesigning the Redis deployment is a separate conversation with whoever owns it."
        },
        {
          "label": "Stateless / JWT sessions",
          "description": "Would remove the lookup entirely, but you lose server-side revocation and it's a much bigger change than the scale-out needs."
        }
      ]
    },
    {
      "question": "Encrypting session payloads at rest in Redis — you flagged this as undecided. How should the doc carry it?",
      "header": "Encryption",
      "multiSelect": false,
      "options": [
        {
          "label": "Non-goal for now, with a written revisit trigger",
          "description": "(Recommended) Payload is user id, roles, a flag bucket — no secrets. Records the reasoning so the next reviewer doesn't reopen it from scratch, and names what would change our mind."
        },
        {
          "label": "In scope now",
          "description": "Encrypt before write, decrypt on read. Adds a key to manage and rotate, and puts crypto on the 5ms path for data that isn't very sensitive."
        },
        {
          "label": "Leave it as an open TODO in the doc",
          "description": "Honest, but an undecided item in a design doc tends to get decided by whoever implements it, silently."
        }
      ]
    },
    {
      "question": "\"Sign out everywhere\" / revoke all of a user's sessions — Redis makes this newly cheap. In scope?",
      "header": "Revoke all",
      "multiSelect": false,
      "options": [
        {
          "label": "Out of scope, but don't foreclose it",
          "description": "(Recommended) No feature now; the key layout is chosen so a per-user index can be added later without a migration. Costs one paragraph of design thought, zero code."
        },
        {
          "label": "In scope",
          "description": "Needs a user-id → session-ids index kept in sync with expiry, which is the fiddly part of session stores. Real scope on a migration that's meant to be behavior-neutral."
        },
        {
          "label": "Explicitly not supported",
          "description": "Simplest key layout, but if the feature shows up later it likely means re-keying live sessions."
        }
      ]
    }
  ]
}
```

**Answer:**
- Non-goals: `Sticky sessions at the load balancer`, `A background sweeper for expired sessions`, `Moving other in-memory state to Redis`, `Changing the session payload or the 30-minute idle TTL`, `Redis HA / failover topology`, `Stateless / JWT sessions`
- Encryption: `Non-goal for now, with a written revisit trigger` — trigger should be phrased in terms of who can read the Redis instance and whether anything sensitive ever lands in the payload.
- Revoke all: `Out of scope, but don't foreclose it`

## Hand-back after Non-Goals

```json
{
  "questions": [
    {
      "question": "Non-Goals is written — seven of them, each with a why-not. Next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Desired Behavior",
          "description": "(Recommended) Observable behavior only: the happy path, idle-TTL semantics, concurrent requests on two nodes, what happens when Redis is unreachable, and what must not change."
        },
        {
          "label": "Revise Non-Goals",
          "description": "Say what's missing or what I scoped out that you actually want in."
        },
        {
          "label": "Sharpen the encryption revisit trigger",
          "description": "It's currently \"if the payload gets sensitive or the reader set widens\" — vague enough that nobody will ever notice it firing. We could tie it to something concrete."
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Desired Behavior`

## Round 3 — Desired Behavior

```json
{
  "questions": [
    {
      "question": "How should this chapter be written?",
      "header": "Framing",
      "multiSelect": false,
      "options": [
        {
          "label": "Given/When/Then scenarios",
          "description": "(Recommended) Each scenario hands the Testing Strategy chapter a case for free, which matters since you'll be driving this test-first.",
          "preview": "**Session is read on a different node**\n\n- Given a session created by node 1\n- When the next request lands on node 3\n- Then the session resolves with the same user id, roles and flag bucket"
        },
        {
          "label": "Prose bullets per behavior",
          "description": "Faster to read end to end, but the edge cases blur together and the test cases have to be re-derived later.",
          "preview": "- A session created on one node resolves identically on any other node.\n- An unknown or expired session id is treated as no session.\n- ..."
        },
        {
          "label": "A table of cases",
          "description": "Compact and good for scanning many small cases, but there's nowhere to put the \"and then what the caller sees\" detail.",
          "preview": "| Case | Outcome |\n| --- | --- |\n| unknown id | no session |\n| expired id | no session |"
        }
      ]
    },
    {
      "question": "Which edge cases does the doc need to pin down? (These become test cases.)",
      "header": "Edge cases",
      "multiSelect": true,
      "options": [
        {
          "label": "Unknown / already-expired session id",
          "description": "(Recommended) The most-hit edge case in any session store. Must be indistinguishable from \"never existed\" to the caller."
        },
        {
          "label": "Idle TTL refresh on read",
          "description": "(Recommended) Whether reading a session extends its 30 minutes is user-visible: it decides whether an active user gets logged out mid-session."
        },
        {
          "label": "Two concurrent requests, two nodes, same session",
          "description": "The case the Map never had. Needs a stated outcome for last-write-wins on the session payload."
        },
        {
          "label": "Redis unreachable mid-request",
          "description": "The new failure mode this migration introduces. Currently impossible, so nothing in the code has an opinion about it yet."
        },
        {
          "label": "Explicit sign-out",
          "description": "Deletion has to be immediate and global, not eventually consistent — it's the one operation where staleness is a security bug."
        },
        {
          "label": "Clock skew between the three nodes",
          "description": "Only matters if expiry is computed node-side. If Redis owns expiry it stops being a case at all — worth stating so nobody re-adds timestamps."
        }
      ]
    },
    {
      "question": "Redis is unreachable and a request arrives with a session cookie. What does the user see?",
      "header": "Redis down",
      "multiSelect": false,
      "options": [
        {
          "label": "Treated as no session — 401, and it's loud",
          "description": "(Recommended) Same response as an expired session, plus an error-rate metric and a log line distinguishing \"store unavailable\" from \"no such session\". Honest, and the \"not silent\" part of your steady-state rule."
        },
        {
          "label": "503 instead of 401",
          "description": "Tells the client it's our fault, not theirs, and keeps 401 rate clean as a signal. But clients that auto-redirect on 401 will instead surface an error page."
        },
        {
          "label": "Fall back to the in-memory store",
          "description": "Keeps requests flowing, but each node builds its own divergent session set and revocation stops working — exactly the split-brain this migration exists to remove."
        },
        {
          "label": "Retry briefly, then 401",
          "description": "Rides out a blip, but every retry is spent inside your 5ms p99 budget on the unhappy path."
        }
      ]
    },
    {
      "question": "What must stay observably unchanged? (The regression surface.)",
      "header": "Unchanged",
      "multiSelect": true,
      "options": [
        {
          "label": "Session cookie name, format and flags",
          "description": "(Recommended) Untouched means existing browsers keep sending a cookie we still recognise — the foundation of \"nobody gets signed out\"."
        },
        {
          "label": "Session id format and generation",
          "description": "(Recommended) Same ids means existing sessions can be migrated as-is rather than re-issued."
        },
        {
          "label": "The 401 response body and headers",
          "description": "Clients parse these. A changed shape turns a storage migration into a client bug."
        },
        {
          "label": "Rate limiter behavior on the shared Redis",
          "description": "It's already there and it must not notice us — no keyspace collisions, no flush that takes out its buckets."
        },
        {
          "label": "Idle-timeout semantics as users experience them",
          "description": "30 minutes of inactivity ends a session, no more and no less, before and after."
        }
      ]
    }
  ]
}
```

**Answer:**
- Framing: `Given/When/Then scenarios`
- Edge cases: all six — `Unknown / already-expired session id`, `Idle TTL refresh on read`, `Two concurrent requests, two nodes, same session`, `Redis unreachable mid-request`, `Explicit sign-out`, `Clock skew between the three nodes`
- Redis down: `Treated as no session — 401, and it's loud`
- Unchanged: all five — `Session cookie name, format and flags`, `Session id format and generation`, `The 401 response body and headers`, `Rate limiter behavior on the shared Redis`, `Idle-timeout semantics as users experience them`

