# Interview log

Record of every point where I would have called `AskUserQuestion`, and the answer
the persona (Alex) gave.

---

## Round 1 — before drafting the design doc

Asked up front because the answers change the shape of the whole document
(cutover plan, interface design, TTL mechanism, test strategy).

```json
{
  "questions": [
    {
      "question": "How should the cutover from the in-memory Map to Redis be handled for sessions that already exist when we deploy?",
      "header": "Cutover",
      "multiSelect": false,
      "options": [
        {
          "label": "Dual-read, Redis-write",
          "description": "New writes go to Redis; reads fall back to the local Map on a miss and backfill into Redis. Existing sessions survive the rollout. Fallback code is removed after one full idle TTL window.",
          "preview": "get(id):\n  s = redis.get(id)\n  if (s) return s\n  s = memory.get(id)        // legacy, same node only\n  if (s) redis.set(id, s)   // backfill\n  return s"
        },
        {
          "label": "Hard cutover",
          "description": "Deploy the Redis implementation and let every existing session die. Simplest possible change, no migration code, but everyone signed in at deploy time is logged out.",
          "preview": "get(id):\n  return redis.get(id)"
        },
        {
          "label": "Sticky sessions first",
          "description": "Pin each client to a node at the load balancer and keep the in-memory Map for now. Buys time, defers the Redis work entirely.",
          "preview": "lb: hash(cookie) -> node\nsession store unchanged"
        }
      ]
    },
    {
      "question": "Should the in-memory implementation stay in the codebase after the migration?",
      "header": "In-memory",
      "multiSelect": false,
      "options": [
        {
          "label": "Keep it behind the interface",
          "description": "One `SessionStore` interface, two implementations (memory + Redis), selected by config. Local dev and unit tests run without Redis."
        },
        {
          "label": "Delete it",
          "description": "Redis becomes the only implementation. Local dev and CI must run a Redis container."
        }
      ]
    },
    {
      "question": "How should the 30-minute idle TTL be enforced once sessions live in Redis?",
      "header": "TTL",
      "multiSelect": false,
      "options": [
        {
          "label": "Redis key expiry",
          "description": "Set `EX 1800` on write and refresh it on each read (sliding window). Redis evicts; no application code involved."
        },
        {
          "label": "Stored expiry + sweeper",
          "description": "Store `expiresAt` in the payload, check it on read, and run a periodic sweep job to delete stale keys."
        }
      ]
    },
    {
      "question": "How do you want the Redis-backed store tested?",
      "header": "Testing",
      "multiSelect": false,
      "options": [
        {
          "label": "node:test + testcontainers",
          "description": "Run the same contract test suite against both implementations; the Redis one gets a real Redis via testcontainers."
        },
        {
          "label": "Mock the Redis client",
          "description": "Unit tests with a stubbed client. Fast, but does not cover expiry semantics or serialization."
        },
        {
          "label": "Shared dev Redis",
          "description": "Point tests at a long-lived Redis instance shared by the team/CI."
        }
      ]
    }
  ]
}
```

**Answer:**
- Cutover: **Dual-read, Redis-write** — "signed-in users have to stay signed in through the rollout, we're not invalidating 5k sessions."
- In-memory: **Keep it behind the interface** — "I don't want Redis to be mandatory for local dev and CI."
- TTL: **Redis key expiry** — "let Redis expire the keys, I don't want to maintain a sweeper."
- Testing: **node:test + testcontainers** — "anything that touches a real backing service gets testcontainers."
- Unprompted on sticky sessions: *"Other: sticky sessions aren't a real answer — it just moves the problem to 'what happens when a node dies'."*

---

## Round 2 — while drafting the operational / security sections

The core design was settled; these three change the "Failure modes", "Security"
and "Open questions" sections.

```json
{
  "questions": [
    {
      "question": "What should the API do when Redis is unreachable?",
      "header": "Redis down",
      "multiSelect": false,
      "options": [
        {
          "label": "Fail closed (503)",
          "description": "Session lookup errors propagate; requests needing a session get 503. Users are not signed out, and the incident is loud and obvious.",
          "preview": "redis error -> throw -> 503 Service Unavailable\ncookie still valid once Redis returns"
        },
        {
          "label": "Fail open as anonymous",
          "description": "Treat a Redis error like a session miss: the request proceeds unauthenticated. Endpoints stay up, but every signed-in user appears signed out.",
          "preview": "redis error -> return undefined -> 401 / anonymous"
        },
        {
          "label": "Fall back to local Map",
          "description": "On Redis error, serve from the node's in-memory store. Keeps some users working, but reintroduces per-node divergence exactly when state is already uncertain."
        }
      ]
    },
    {
      "question": "Should sessions share the rate limiter's Redis, and how do we keep the keyspaces apart?",
      "header": "Redis layout",
      "multiSelect": false,
      "options": [
        {
          "label": "Same instance, key prefix",
          "description": "Reuse the existing instance and client; namespace with `session:` vs the limiter's prefix. No new infrastructure."
        },
        {
          "label": "Same instance, separate DB index",
          "description": "Reuse the instance with `SELECT 1` for sessions. Cleaner `FLUSHDB` blast radius, but DB indexes are unsupported in Redis Cluster."
        },
        {
          "label": "Separate instance",
          "description": "Isolate sessions from rate-limiter load and eviction policy entirely. New infrastructure to provision and monitor."
        }
      ]
    },
    {
      "question": "Should session payloads be encrypted at rest in Redis?",
      "header": "Encryption",
      "multiSelect": false,
      "options": [
        {
          "label": "No, plaintext JSON",
          "description": "Payload is user id, roles and a flag bucket — no secrets. Simplest, fastest, easiest to debug with redis-cli."
        },
        {
          "label": "Encrypt the value",
          "description": "AEAD-encrypt the JSON with a key from the app config. Protects against anyone able to read the Redis keyspace or a snapshot, at the cost of key rotation and opaque values in debugging."
        }
      ]
    }
  ]
}
```

**Answer:**
- Redis down: **Fail closed (503)** — "the whole point is not logging people out. A 503 for a few seconds is recoverable, a mass sign-out isn't."
- Redis layout: **Same instance, key prefix** — "it's already there for the rate limiter; I don't want a second instance to babysit. DB indexes are a dead end if we ever cluster."
- Encryption: *"Other: genuinely undecided — there's no secret material in there, but it is PII-adjacent and I don't know what our compliance story needs to be. Write it up as an open question with the trade-off, don't bake it in. Whichever way it goes, it has to be a decision inside the store implementation so nothing above the interface changes."*

---

No further questions. Everything else in the doc follows from the answers above
or from the existing system's behavior.
