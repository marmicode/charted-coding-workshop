# Redis-backed session store

**Status:** Draft
**Date:** 2026-09-24
**Author:** Alex

## 1. Context

Sessions currently live in a plain `Map` in the Fastify process, keyed by session
id, with a 30-minute idle TTL. The payload is small — user id, roles, a
feature-flag bucket — and we hold roughly 5k concurrent sessions.

We are about to run 3 nodes behind a load balancer instead of 1. A process-local
`Map` breaks immediately in that topology: a request routed to node B cannot see
a session created on node A, so the user appears signed out at random.

Redis is already in the stack (it backs the rate limiter), so this is not a new
operational dependency — no new runbook, no new on-call surface, no new
provisioning.

## 2. Goals

- Any node can serve any session. Session state is not tied to a process.
- **No mass invalidation.** Everyone signed in at deploy time stays signed in.
- Session lookup stays under **5ms p99**.
- **Redis stays optional for local dev and CI.** An in-memory implementation
  remains available behind the same interface.
- The 30-minute idle TTL keeps working as a sliding window.

## 3. Non-goals

- Session payload redesign. Same fields, same shape.
- Replacing cookie-based session ids with stateless JWTs. That is a much larger
  change and removes our ability to revoke.
- Multi-region session replication.
- Any change to the rate limiter's use of Redis.

## 4. Rejected alternative: sticky sessions

Pinning each client to a node at the load balancer would let us keep the `Map`
and ship nothing. We are not doing it:

- It does not solve the problem, it relocates it. When a node restarts (deploys,
  scaling, crashes) every session pinned to it is gone. With 3 nodes that is a
  third of signed-in users logged out on every rolling deploy.
- It makes load uneven and undermines the reason we are adding nodes.
- It quietly constrains every future feature that wants shared state.

Redis gets us a real answer once, instead of a workaround we pay for repeatedly.

## 5. Design

### 5.1 The interface

One interface, two implementations, chosen by configuration. Nothing in the
application layer knows which one it is talking to.

```ts
export type SessionId = string;

export interface Session {
  userId: string;
  roles: string[];
  flagBucket: string;
}

export interface SessionStore {
  /** Returns the session and refreshes its idle TTL, or undefined if absent/expired. */
  get(id: SessionId): Promise<Session | undefined>;
  /** Creates or replaces a session and (re)starts its idle TTL. */
  set(id: SessionId, session: Session): Promise<void>;
  /** Removes a session (sign-out, revocation). Idempotent. */
  delete(id: SessionId): Promise<void>;
}
```

Notes:

- The interface is `async` on both sides, including the in-memory one. If the
  memory implementation were synchronous, swapping it for Redis would be a
  breaking change at every call site — which is exactly the trap we are getting
  out of.
- `get` refreshes the TTL. Idle expiry is a property of the store, not something
  each caller has to remember to do.
- No `keys()` / `size()` / iteration. Those are cheap on a `Map` and a footgun on
  Redis (`KEYS` blocks the server), and nothing needs them today. Leaving them
  out keeps the two implementations honestly interchangeable.

Implementations:

- `InMemorySessionStore` — `Map` plus a per-key `setTimeout`, `unref()`'d so it
  never holds the process open. This is the current behavior, kept.
- `RedisSessionStore` — takes an existing Redis client; does not construct or own
  the connection.

Selection is config-driven:

```
SESSION_STORE=redis|memory   # default: memory in dev/test, redis in staging/prod
```

### 5.2 Redis representation

- **Key:** `session:<id>`. The `session:` prefix keeps sessions distinguishable
  from rate-limiter keys in the same database.
- **Value:** JSON string. The payload is three small fields; a hash buys nothing
  here and costs us atomic whole-object replacement.
- **TTL:** Redis key expiry, 1800s. **No sweeper.** A sweeper is a background job
  that can lag, double-run across 3 nodes, or silently die; Redis expiry is a
  feature we already pay for. The TTL is also the only thing enforcing expiry —
  we do not additionally store `expiresAt` in the payload, because two sources of
  truth for "is this expired" is how you get sessions that are alive by one
  measure and dead by the other.

Operations:

```ts
// get — read + slide the window in one round trip
const raw = await redis.getex(key, 'EX', ttlSeconds);

// set
await redis.set(key, JSON.stringify(session), 'EX', ttlSeconds);

// delete
await redis.del(key);
```

`GETEX` (Redis 6.2+) does the read and the TTL refresh in a single round trip. If
we are pinned to an older Redis, fall back to `GET` + `EXPIRE` pipelined as one
command batch — still one network round trip, still no read-modify-write race,
because `EXPIRE` on a missing key is a no-op.

### 5.3 Latency

Budget: 5ms p99 for a lookup.

- One round trip to Redis on the same network: well under 1ms typically, with p99
  driven by tail effects, not by our payload size.
- `GETEX` keeps it to exactly one round trip. This is the main reason to prefer
  it over `GET` then `EXPIRE` as separate awaits.
- The client must use a single long-lived connection with pipelining enabled (or
  a small pool). Connecting per request would blow the budget on its own.
- Command timeout of 250ms, so a stalled Redis surfaces as an error instead of a
  hung request.

We instrument `session_store_get_duration_ms` as a histogram from day one and
watch p99 through the rollout. If p99 turns out to sit near the limit, the next
lever is a short-lived per-node cache in front of Redis — deliberately **not** in
this design, because a local cache reintroduces staleness on revocation, and we
should only pay that price if measurement says we have to.

### 5.4 Redis layout

Sessions share the existing Redis instance and client with the rate limiter,
namespaced by the `session:` key prefix. No new instance to provision, monitor or
fail over.

We deliberately do **not** use a separate DB index (`SELECT 1`): logical DBs are
unsupported in Redis Cluster, so it is a choice we would have to undo the moment
we cluster. A prefix works everywhere.

One thing to verify before rollout: the instance's `maxmemory-policy`. Sessions
must not be evicted early under memory pressure — `volatile-lru` would silently
sign users out before their TTL. `noeviction` (writes fail loudly) or a memory
headroom alert is what we want. 5k sessions × a few hundred bytes is well under
10MB, so headroom is not the concern; the concern is the policy being wrong and
nobody noticing until it matters.

## 6. Migration

The ordering here is the whole trick. We get to zero invalidation by doing the
backfill **while we are still on one node**, where the in-memory `Map` is still a
complete picture of live sessions.

**Phase 1 — dual-read, Redis-write, still 1 node.**

Deploy `RedisSessionStore` wrapped in a migration decorator:

```ts
async get(id) {
  const fromRedis = await this.redis.get(id);
  if (fromRedis) return fromRedis;

  const fromMemory = await this.memory.get(id);   // legacy sessions, this node
  if (fromMemory) await this.redis.set(id, fromMemory);  // backfill
  return fromMemory;
}

async set(id, session)  { await this.redis.set(id, session); }
async delete(id)        { await Promise.all([this.redis.delete(id), this.memory.delete(id)]); }
```

Writes go only to Redis. Reads fall back to the surviving `Map` and backfill on
the way through. Because there is exactly one node, that `Map` holds every live
session, so every session that is still being used migrates itself on its next
request.

**Phase 2 — wait one full idle TTL (30 minutes), then some.**

After 30 minutes of uptime in Phase 1, any session that has not been read is by
definition idle past its TTL and was going to expire anyway. In practice: leave
Phase 1 running for a few hours, and watch the `session_store_memory_fallback_total`
counter go to zero. That counter reaching and holding zero is the gate for
Phase 3 — not the clock.

**Phase 3 — scale to 3 nodes.**

Only now do we add nodes. Redis is the single source of truth; the fallback path
is still present but dead (a new node's `Map` is empty, so it can only ever
return `undefined`). It is harmless, and it is our rollback: if Redis misbehaves
badly in Phase 3, we scale back to one node and flip `SESSION_STORE=memory` —
users created after the cutover lose their session, which is a far smaller blast
radius than the alternative.

**Phase 4 — delete the migration decorator.**

Once Phase 3 has been stable for a week, remove the decorator and the fallback
counter. `RedisSessionStore` is used directly. `InMemorySessionStore` stays in
the codebase — it is the dev/CI implementation, not migration scaffolding.

## 7. Failure modes

| Failure | Behavior | Rationale |
| --- | --- | --- |
| Redis unreachable | Error propagates; requests requiring a session return **503** | Fail **closed**. Treating an outage as "no session" would sign out every user at once — precisely the outcome this project exists to avoid. A short 503 is recoverable: the cookie is still valid when Redis returns. |
| Redis slow (> 250ms) | Command timeout → same 503 path | A hung request is worse than a fast failure, and it holds a connection. |
| Malformed JSON at a key | Log, treat as a miss, `DEL` the key | Unparseable state is not recoverable; deleting it stops it from being re-read forever. |
| Redis restart / data loss | All sessions gone, everyone signs in again | Accepted. We are not adding persistence or replication for session data — it is regenerable, and AOF/RDB tuning for the rate limiter is a separate conversation. Worth stating explicitly so nobody assumes durability we do not have. |
| Clock skew between nodes | No impact | Expiry is Redis-side; application clocks are not involved. |

The 503 choice deserves a health-check consequence: the readiness probe should
check Redis connectivity, so a node that has lost Redis is pulled out of the load
balancer rather than serving 503s.

## 8. Security

The payload is user id, roles and a feature-flag bucket — no tokens, no
credentials, no personal data beyond the identifier.

In scope regardless of the encryption question:

- Redis is not reachable from outside the VPC, and requires auth. (Already true
  for the rate limiter; this change does not relax it.)
- Session ids stay opaque and random; nothing about the user is derivable from
  the key.
- Sign-out `DEL`s the key immediately. Revocation is instant across all nodes —
  which is a genuine improvement over the `Map`, where a sign-out on node A left
  the session alive on node B.
- Never log the full key or the payload.

**Encryption at rest is an open question** — see §11. Whichever way it goes, it
is confined to `RedisSessionStore`'s serialize/deserialize step: nothing above
the `SessionStore` interface changes.

## 9. Testing

The interface exists partly so that the tests can be written once. We use
`node:test`, with testcontainers for the implementation that touches a real
backing service.

**Contract suite (shared).** A single parameterized suite runs against both
implementations, asserting identical observable behavior:

- `set` then `get` round-trips the payload exactly.
- `get` on an unknown id returns `undefined`.
- `delete` removes it; `delete` on an unknown id does not throw.
- `get` slides the TTL: write, wait past half the TTL, `get`, wait past half
  again, `get` still returns the session.
- A session not read within the TTL is gone.

This is where the design earns its keep: if the contract suite passes against
both, the config flag is genuinely safe to flip.

**Redis-specific tests** (testcontainers, real Redis):

- TTL is actually set on the key, and `GETEX` refreshes it (assert via `PTTL`).
- Keys are written under the `session:` prefix and nothing else in the keyspace
  is touched.
- Malformed value at a key is treated as a miss and the key is removed.
- Client errors surface as thrown errors, not as `undefined` — this is the
  fail-closed guarantee, and it is worth a test because the failure mode of
  getting it wrong is silent mass sign-out.

**Migration decorator tests** (in-memory on both sides, no container needed):

- Redis hit does not touch the memory store.
- Redis miss + memory hit returns the session **and** writes it to Redis.
- Miss on both returns `undefined`.
- `delete` clears both.

TTL tests use a shortened TTL injected via config rather than real 30-minute
waits.

## 10. Observability

- `session_store_get_duration_ms` — histogram, labeled by implementation. The
  5ms p99 goal is only meaningful if we are watching it.
- `session_store_errors_total` — labeled by operation. Alert on any sustained
  non-zero rate; this is the 503 path.
- `session_store_memory_fallback_total` — the Phase 2 → Phase 3 gate. Delete it
  in Phase 4.
- Active session count via a periodic `SCAN`-based gauge, or simply Redis'
  `db0.keys` if the prefix split is clear enough. Low priority, and it must not
  use `KEYS`.

## 11. Open questions

1. **Encrypt session payloads at rest in Redis?** Undecided, and deliberately not
   pre-empted here. Against: no secret material in the payload, and opaque values
   make production debugging materially harder. For: user id and roles are
   PII-adjacent, and anyone with keyspace or snapshot access reads them today. If
   we do it, it needs an AEAD construction, a key in config, and a rotation story
   — the rotation story is the actual cost, not the encryption. This does not
   block Phase 1; it is a change inside the store's serialization step.
2. **`maxmemory-policy` on the shared instance** — needs to be confirmed before
   Phase 1, not discovered during it (§5.4).
3. **Redis version** — confirm ≥ 6.2 for `GETEX`; otherwise use the pipelined
   `GET` + `EXPIRE` fallback (§5.2).

## 12. Work breakdown

1. Extract the `SessionStore` interface; make the existing `Map` implementation
   satisfy it and make all call sites `await`. No behavior change, ships alone.
2. Contract test suite, running against the in-memory implementation.
3. `RedisSessionStore` + testcontainers tests. Contract suite must pass unchanged.
4. Config-driven selection (`SESSION_STORE`), metrics, readiness probe check.
5. Migration decorator + its tests.
6. Deploy Phase 1 (1 node). Watch the fallback counter and the latency histogram.
7. Scale to 3 nodes (Phase 3).
8. After a week: remove the decorator (Phase 4).

Steps 1–2 are worth landing on their own even if everything after them stalls —
they are a strict improvement to the current code.
