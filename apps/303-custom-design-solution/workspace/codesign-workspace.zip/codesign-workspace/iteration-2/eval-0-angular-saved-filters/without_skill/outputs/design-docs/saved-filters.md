# Saved Filters for Recipe Search

**Status:** Draft · **App:** whiskmate · **Date:** 2026-09-24

## 1. Context

Recipe search today is a component with a filter bar that writes into a signal-based store.
Three filters exist: ingredient, max cook time, and diet tags. Every one of them is re-entered
by hand on every visit, and the combos people use are stable — "vegan, under 30 minutes" is
typed again and again.

Saved filters let a user name the current combination and get it back later as a clickable chip.

## 2. Goals and non-goals

**Goals**

- Save the currently active filter combination under a user-chosen name.
- Show saved filters as a row of chips near the filter bar.
- Clicking a chip applies the whole combination at once.
- Delete a saved filter.
- Survive a page reload on the same browser.

**Non-goals for v1** — each of these is a deliberate "not now", not an oversight:

- Server-side, per-user storage. That is where this ends up; see §8.
- Editing a saved filter in place, or renaming one. Delete and re-save.
- Reordering, pinning, usage counts, "recently used".
- Sharing a saved filter with another user or via a link.
- A new state management library.
- Any generic "saved query" abstraction usable by other screens. There is exactly one screen.

## 3. UX

```
┌─────────────────────────────────────────────────────────┐
│  [ ingredient ] [ max cook time ] [ diet tags ▾ ]       │
│                                      [ Save filters ]   │
├─────────────────────────────────────────────────────────┤
│  Saved:  ( Weeknight ×)  ( Vegan · 30 min ×)  (⚠ Keto ×)│
├─────────────────────────────────────────────────────────┤
│  … recipe results …                                      │
└─────────────────────────────────────────────────────────┘
```

**Saving.** A "Save filters" button sits in the filter bar, disabled while no filter is active
(nothing useful to save). Clicking it reveals an inline text input prefilled with a generated
summary of the active filters — `Vegan · under 30 min`. Enter saves, Escape cancels. No modal.

**Applying.** Clicking a chip sets all three filter values at once. The chip renders as active
(`aria-pressed`) while the live filter state equals the saved one, so the user can see which
combination they are looking at.

**Deleting.** A small `×` on each chip. No confirmation dialog — recreating a filter costs five
seconds, and a dialog costs more than it saves.

**Empty state.** With no saved filters, the row is not rendered at all. No placeholder, no
"you have no saved filters yet" copy.

**Accessibility.** The row is a `<ul>` labelled "Saved filters". Each chip is a `<button>`, and
delete is a *sibling* button with its own accessible name ("Delete saved filter Weeknight") —
not nested inside the chip button, which would be invalid and unreachable by keyboard.

## 4. Data model

```ts
export interface SavedFilter {
  id: string;            // crypto.randomUUID()
  name: string;
  filter: RecipeFilter;  // reuse the existing type, do not copy it
  createdAt: string;     // ISO 8601
}
```

`RecipeFilter` is whatever the search store already uses for ingredient / max cook time /
diet tags. Reusing it means a fourth filter added later is automatically saveable, and an old
record simply lacks the field, which reads as "not set".

Stored under one key, wrapped in a versioned envelope:

```ts
// key: "whiskmate.saved-filters"
interface StoredPayload {
  version: 1;
  savedFilters: SavedFilter[];
}
```

The envelope exists so a future change can tell "old shape" from "corrupt" without guessing.
Names are **not** unique — `id` is identity. Two filters called "dinner" is the user's problem,
not a validation error.

## 5. Architecture

Two new pieces. No library, no abstraction layer.

### `SavedFilterRepository` (`providedIn: 'root'`)

Owns a `signal<SavedFilter[]>`. Reads localStorage once on construction; writes on every
mutation. Surface:

```ts
readonly savedFilters: Signal<SavedFilter[]>;
save(name: string, filter: RecipeFilter): void;
remove(id: string): void;
```

**Why not put this in the existing search store.** The search store is about the *current* query
and its results — it is recreated freely and has no persistence concern. Saved filters have a
different lifetime and would drag a storage dependency into it. They are joined in the component,
which is where the user joins them too.

**localStorage is called directly**, not through an injected `Storage` token. Tests clear it in
`beforeEach`, which is one line and behaves like the real thing. If that ever gets in the way,
adding a token later is a mechanical change to one file.

### `SavedFilterBarComponent`

Standalone, renders the chip row and the save input.

```ts
currentFilter = input.required<RecipeFilter>();
filterApplied = output<RecipeFilter>();
```

It injects `SavedFilterRepository` directly — it is the only consumer, and keeping the list and
the save/delete handlers out of `RecipeSearchComponent` stops that component's template from
doubling in size. The one thing it does *not* do is touch the search store: applying is an
output, and the parent decides what that means.

## 6. Applying a saved filter — the one real risk

`(filterApplied)` is wired to the *same* path the filter bar already uses to set filters. Applying
a chip should be indistinguishable from typing the values by hand.

That only holds if the filter bar's inputs are driven by the store's filter signal. **If the
filter bar currently keeps its own local state**, clicking a chip will update the results while
the inputs still show the old values — which looks broken.

This is the one piece of existing code that may need a change, and it is the main unknown in the
estimate. See §12.

## 7. Diet tags that no longer exist

A saved filter can outlive the tag it references.

- On apply, the saved `dietTags` are intersected with the currently known tag list. The
  intersection plus the other fields is what gets applied.
- **The stored record is never rewritten.** If the tag comes back, the filter works again. Nothing
  the user saved is silently edited away.
- A chip whose tags are not all known renders a warning marker, with the reason available to
  screen readers: *"keto is no longer available"*.
- If the warning would depend on a tag list that has not loaded yet, no warning is shown. Better
  silent than wrong.
- A filter that prunes down to nothing still applies — it just means "no filters" — and warns.

## 8. Getting to the server later

v1 is localStorage, per browser. Three-person team, workshop in three weeks, no per-user story
needed yet.

When it does move server-side: `SavedFilterRepository` is the only thing that touches storage, so
the read and write change and the signal API stays. The `version` field gives a future migration
somewhere to record "these were uploaded".

**Nothing is being built for that now** — no interface, no strategy, no feature flag, no
`SavedFilterStorage` token. One class, replaced when there is a second implementation to justify
the seam.

## 9. Testing

Vitest + Angular Testing Library, MSW for HTTP. Tests render `RecipeSearchComponent` with the
**real** store and the **real** repository, and assert on what the user sees — rendered recipes
and chips, never store internals. `localStorage.clear()` in `beforeEach`; a `givenSavedFilters()`
helper writes the envelope directly to seed state.

1. Save: set filters → "Save filters" → accept the name → chip appears.
2. The save button is disabled while no filter is active.
3. Apply: seed a saved filter, render, click the chip → the filter bar shows the saved values
   **and** the recipe list shows the matching recipes.
4. Persistence: save, then render a fresh component → the chip is still there.
5. Delete: click delete → chip gone, and still gone after a fresh render.
6. Stale tag: seed a filter with a tag MSW no longer returns → chip warns; applying it filters by
   the remaining valid fields only.
7. The save input is prefilled with a summary of the active filters.
8. Chips are buttons; delete has its own accessible name.

**No isolated tests for `SavedFilterRepository`.** The one case worth an exception is corrupt
storage (§10): if "render with garbage in localStorage and see an empty chip row" turns out to be
awkward, a three-line direct test on the repository is acceptable for that case alone.

## 10. Edge cases

| Case | Behaviour |
| --- | --- |
| localStorage unavailable (private mode, quota) | Repository falls back to in-memory. Saving works for the session; nothing throws. `try/catch` on both read and write. |
| Malformed or foreign JSON under the key | Treated as an empty list. Overwritten on the next save. Never throws. |
| Unknown `version` in the envelope | Treated as an empty list. v1 only understands v1. |
| Duplicate names | Allowed. No dedupe, no warning. |
| Saving with no active filter | Prevented — the button is disabled. |
| Many saved filters | No cap. The row wraps. Revisit if anyone reaches ~20. |
| Two tabs open | Last write wins. No `storage` event listener in v1. |

## 11. Sequencing

Sized against the workshop in three weeks.

1. `SavedFilter` type, repository, localStorage round-trip — tests 4 and the corrupt-storage case.
2. Chip row rendering and delete — tests 5, 8.
3. Save flow with the generated default name — tests 1, 2, 7.
4. Apply flow, plus whatever §6 turns out to require — test 3.
5. Stale tag warning — test 6.

Steps 1–4 are the shippable minimum. Step 5 can slip past the workshop without the feature
looking unfinished.

## 12. Open questions

Three, all answerable by reading the existing code, and all worth answering before step 4.

1. **Is the filter bar controlled by the store, or does it hold local state?** This decides
   whether step 4 is ten minutes or half a day. See §6.
2. **Where does the canonical diet tag list come from** — an endpoint, or a constant in the app?
   §7's warning needs a trustworthy "known tags" set, and the answer changes whether the
   not-loaded-yet case in §7 can even happen.
3. **Are search filters already in the URL as query params?** If they are, applying a saved
   filter should go through the router so back/forward and link-sharing keep working. Five
   minutes to check, and it would change the shape of step 4.
