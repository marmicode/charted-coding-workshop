# Interview log — saved filters design doc

Question sets I would have put to the user via `AskUserQuestion`, in the order I would
have asked them, each followed by the answer I proceeded with.

---

## Round 1 — asked before writing any of the doc

```json
{
  "questions": [
    {
      "question": "Where should saved filters be persisted?",
      "header": "Persistence",
      "multiSelect": false,
      "options": [
        {
          "label": "localStorage only (v1)",
          "description": "Per browser, per device. Zero backend work. Filters don't follow the user to another machine."
        },
        {
          "label": "Server-backed, per user",
          "description": "New API endpoint plus storage. Filters follow the user everywhere, but it's real backend scope."
        },
        {
          "label": "localStorage behind a swappable strategy",
          "description": "Ship localStorage, but introduce a storage interface and injection token now so a server implementation can drop in later."
        },
        {
          "label": "In-memory for the session only",
          "description": "Filters vanish on reload. Smallest possible scope, but probably not worth shipping."
        }
      ]
    },
    {
      "question": "What belongs in v1?",
      "header": "Scope",
      "multiSelect": true,
      "options": [
        {
          "label": "Save, apply, delete",
          "description": "The minimum loop: name the current combo, click a chip to apply it, remove one you no longer want."
        },
        {
          "label": "Rename an existing saved filter",
          "description": "Edit the label without touching the filter values."
        },
        {
          "label": "Update a saved filter in place",
          "description": "Overwrite an existing filter's values with whatever is currently in the filter bar."
        },
        {
          "label": "Reorder / pin favourites",
          "description": "Drag to reorder chips, or pin the ones used most. Adds an ordering field and drag interactions."
        }
      ]
    },
    {
      "question": "How should the saved-filter state be held?",
      "header": "State",
      "multiSelect": false,
      "options": [
        {
          "label": "Small signal-based service, no new library",
          "description": "A plain injectable holding a signal<SavedFilter[]>, same style as the rest of the app."
        },
        {
          "label": "Extend the existing recipe search store",
          "description": "Add savedFilters to the store that already owns the current filter and results. One place to look, but the store picks up a storage dependency."
        },
        {
          "label": "NgRx SignalStore",
          "description": "Adopt @ngrx/signals for this feature and migrate the rest later. Structure and devtools out of the box, at the cost of a new dependency."
        }
      ]
    },
    {
      "question": "How do you want this tested?",
      "header": "Testing",
      "multiSelect": false,
      "options": [
        {
          "label": "Through the component, real store, MSW",
          "description": "Render the search component with the real store and faked HTTP; assert on what the user sees. Matches the existing Vitest + Angular Testing Library setup."
        },
        {
          "label": "Unit-test the store/service in isolation",
          "description": "Direct tests on save/remove/load, plus a thinner component test on top."
        },
        {
          "label": "Both layers",
          "description": "Isolated service tests for the storage logic and component tests for the interactions."
        },
        {
          "label": "End-to-end only",
          "description": "Cover it in the e2e suite and skip component-level coverage."
        }
      ]
    }
  ]
}
```

**Answer:**
- Persistence → **localStorage only (v1)**. Verbatim intent: server-side per-user is where this
  ends up, but not now — localStorage is plenty for v1, and I don't want a strategy interface
  built for a second implementation that doesn't exist yet.
- Scope → **Save, apply, delete**. There's a workshop in 3 weeks; rename and update-in-place are
  delete-and-re-save, and that's fine.
- State → *Other:* "A plain signal-based service next to the existing search store — and to be
  explicit, we are not adding a state management library for this."
- Testing → **Through the component, real store, MSW**. Don't write isolated store tests.

---

## Round 2 — asked after drafting §1–§6, before writing the edge-case and stale-tag sections

```json
{
  "questions": [
    {
      "question": "A saved filter references a diet tag that no longer exists. What should happen when it's clicked?",
      "header": "Stale tags",
      "multiSelect": false,
      "options": [
        {
          "label": "Apply what's valid, drop unknown tags silently",
          "description": "The filter still works, just with fewer tags. No UI, no explanation — the user may wonder why results changed."
        },
        {
          "label": "Apply what's valid, flag the chip",
          "description": "Apply the remaining fields and mark the chip with a warning explaining which tag is gone. The stored record is left untouched."
        },
        {
          "label": "Auto-prune the saved filter on load",
          "description": "Rewrite the stored record to remove tags that no longer exist. Clean state, but it silently edits something the user saved."
        },
        {
          "label": "Refuse to apply until it's fixed",
          "description": "Disable the chip and ask the user to re-save. Safest semantics, most friction, most UI."
        }
      ]
    },
    {
      "question": "How does a saved filter get its name?",
      "header": "Naming",
      "multiSelect": false,
      "options": [
        {
          "label": "Inline input prefilled with a generated summary",
          "description": "\"Vegan · under 30 min\" appears in the input; the user hits Enter to accept or types over it."
        },
        {
          "label": "Inline input, empty, name required",
          "description": "The user always types a name. Simplest logic, one more step every time."
        },
        {
          "label": "No name at all",
          "description": "The chip just shows a generated summary of the filter values. Nothing to type, but no way to call it \"weeknight dinners\"."
        }
      ]
    },
    {
      "question": "How should the chip row behave as filters accumulate?",
      "header": "Chip row",
      "multiSelect": false,
      "options": [
        {
          "label": "Insertion order, no limit",
          "description": "Newest last, row wraps. No extra state, no surprises."
        },
        {
          "label": "Most recently used first",
          "description": "Clicking a chip moves it to the front. Needs a lastUsedAt field and makes the row shuffle under the cursor."
        },
        {
          "label": "Cap at ~10, oldest evicted",
          "description": "Keeps the row short by throwing away filters the user explicitly saved."
        }
      ]
    }
  ]
}
```

**Answer:**
- Stale tags → *Other:* "Apply what's still valid and put a small warning on the chip, but do
  not touch the stored record. I don't want to be the one who silently deletes part of
  somebody's saved filter — if the tag comes back the filter should just work again."
- Naming → **Inline input prefilled with a generated summary.** Enter accepts it.
- Chip row → **Insertion order, no limit.** We'll add a cap the day someone actually saves 50.

---

## Round 3 — would have asked, but answered from the doc instead

Three things I wanted to confirm about the existing code (is the filter bar controlled by the
store or does it hold local state; where the canonical diet-tag list comes from; whether search
filters are already in the URL as query params). No codebase access here, so rather than ask,
they are written up as blocking open questions in §12 of the design doc, with a note on what
each answer changes.
