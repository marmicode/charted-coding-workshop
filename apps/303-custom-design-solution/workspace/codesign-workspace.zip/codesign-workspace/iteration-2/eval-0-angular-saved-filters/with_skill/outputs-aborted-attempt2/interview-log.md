# Interview Log — Saved Filters

Every question that would have gone to `AskUserQuestion`, logged in real time with the
answer the designer (Sam) gave. Recorded before the chapter each round informs.

---

## Chapter 1 — Goals · Round 1

```json
{
  "questions": [
    {
      "question": "I've drafted four candidate goals for saved filters. Which of these are actually goals for you? (Pick everything that belongs; I'll rank them in round 2.)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {
          "label": "One-click return to a filter combo (Recommended)",
          "description": "Someone who searches 'chickpeas + under 30 min + vegan' every week gets back to those exact results in one click instead of re-setting three controls. This is the core outcome; everything else is support for it."
        },
        {
          "label": "Saved combos survive a reload and a new session",
          "description": "The chips are still there tomorrow morning on the same browser. Buys real value over an in-memory list; costs you a persistence decision (localStorage vs server) in the Design chapter."
        },
        {
          "label": "Saved combos follow the user across devices",
          "description": "Requires a per-user server endpoint and auth on day one. Real value, but it turns a UI feature into a backend feature and puts the 3-week workshop date at risk."
        },
        {
          "label": "Shareable filter combos via URL",
          "description": "A saved filter becomes a link you can paste to a teammate. Tempting and cheap-looking, but it means the filter state has to be URL-serialisable, which is a bigger refactor of the existing filter bar than it sounds."
        }
      ]
    },
    {
      "question": "What's forcing this now? This shapes how much we're allowed to build.",
      "header": "Forcing fn",
      "multiSelect": false,
      "options": [
        {
          "label": "Workshop demo in 3 weeks (Recommended)",
          "description": "A hard, near date. It makes 'small and finished' beat 'right and half-done', and it's the thing I'd cite in the doc whenever we cut scope later."
        },
        {
          "label": "User complaints about re-typing filters",
          "description": "Demand-driven. Would justify spending longer to get persistence right, because real users hit it daily."
        },
        {
          "label": "No hard deadline, quality bar is what matters",
          "description": "Opens the door to the per-user server story in v1."
        }
      ]
    },
    {
      "question": "Filename for the doc — it's what you'll search for in six months.",
      "header": "Slug",
      "multiSelect": false,
      "options": [
        {
          "label": "design-docs/saved-filters.md (Recommended)",
          "description": "Matches the words you used in the request. Short, greppable."
        },
        {
          "label": "design-docs/recipe-search-saved-filters.md",
          "description": "Scoped to the feature area, in case saved filters later show up somewhere other than recipe search."
        },
        {
          "label": "design-docs/filter-presets.md",
          "description": "Only if 'preset' is the word your team actually uses in conversation."
        }
      ]
    }
  ]
}
```

**Answer:**
- Goals: `One-click return to a filter combo` + `Saved combos survive a reload and a new session`
- Forcing fn: `Workshop demo in 3 weeks`
- Slug: `design-docs/saved-filters.md`
- Sam, unprompted: *"Cross-device is where I want to end up — saved filters per user on the server eventually — but not for v1. localStorage is plenty. And no URL sharing, that's a different feature."*
- Parked (implementation detail volunteered during Goals): localStorage as the v1 store; no new state management library. → revisit in **Design & Implementation Details**.

## Chapter 1 — Goals · Round 2

```json
{
  "questions": [
    {
      "question": "Goal 1 (one-click recall) and goal 2 (survives a reload) will conflict at some point — most likely when a saved filter references a diet tag that no longer exists, or when localStorage is unavailable. Which one wins?",
      "header": "Priority",
      "multiSelect": false,
      "options": [
        {
          "label": "One-click recall wins; persistence degrades quietly (Recommended)",
          "description": "If storage is unavailable or a stored entry is corrupt, the feature keeps working for this session and just doesn't remember. Search itself never breaks. Costs you: a user can lose chips without an explicit error."
        },
        {
          "label": "Persistence wins; block and surface an error",
          "description": "If we can't guarantee the chips survive, tell the user loudly. Honest, but a storage quirk in a private window turns into a scary error on a search page."
        },
        {
          "label": "Neither — treat it as a bug and decide case by case",
          "description": "Leaves the tension unresolved in the doc, which means it gets decided under pressure during implementation."
        }
      ]
    },
    {
      "question": "What observable signal tells you this shipped and worked? I'd like one line in the doc that isn't 'it feels nicer'.",
      "header": "Signal",
      "multiSelect": false,
      "options": [
        {
          "label": "You and the team use it during the workshop demo without touching the filter bar (Recommended)",
          "description": "Honest for a 3-person team with no analytics pipeline: a concrete, checkable moment rather than a metric nobody will collect."
        },
        {
          "label": "Analytics event: saved-filter applied vs. manual filter changes",
          "description": "A real number, but it means adding tracking you don't have today — new scope in a 3-week window."
        },
        {
          "label": "At least one saved filter exists per active user after a week",
          "description": "Requires server-side storage to even measure, which contradicts the localStorage decision."
        }
      ]
    }
  ]
}
```

**Answer:**
- Priority: `One-click recall wins; persistence degrades quietly`
- Signal: `You and the team use it during the workshop demo without touching the filter bar`
- Sam: *"Search must never break because of this feature. That's the rule. If localStorage is weird in someone's browser, fine, they lose their chips — they don't lose search."*

