# Interview Log — Saved Filters

Simulated `AskUserQuestion` calls (no human available). Each entry records the call
that would have been made, then the persona's answer.

---

## Round 1 — Slug + Goals

```json
{"questions":[
 {"question":"I'm proposing `design-docs/saved-filters.md` as the file. Keep it?","header":"Doc slug","multiSelect":false,"options":[
  {"label":"saved-filters.md (Recommended)","description":"Matches the feature name you used; short and searchable."},
  {"label":"recipe-search-saved-filters.md","description":"Scopes it to recipe search, in case saved filters later apply elsewhere in whiskmate."},
  {"label":"saved-filter-chips.md","description":"Names the UI affordance rather than the concept; ages badly if the chip becomes a dropdown."}]},

 {"question":"Which outcomes count as goals for v1? (pick all that apply)","header":"Goals","multiSelect":true,"options":[
  {"label":"Re-apply a filter combo in one click (Recommended)","description":"The core win: a named chip restores ingredient + max cook time + diet tags in a single interaction, no re-typing."},
  {"label":"Combos survive a page reload (Recommended)","description":"Saved filters persist across sessions on the same browser. Rules in some storage; rules out 'just keep it in the store'."},
  {"label":"Saved filters follow the user across devices","description":"Needs a server endpoint and auth wiring — real work, and it's the part most likely to eat the 3 weeks."},
  {"label":"Shareable filter URLs","description":"A saved combo becomes a link you can paste to a teammate. Adds URL-encoding design and a parsing surface."}]},

 {"question":"When two of these conflict under deadline pressure, what wins?","header":"Priority","multiSelect":false,"options":[
  {"label":"Ship small and local first (Recommended)","description":"v1 is browser-local and one-click. Anything needing a backend is explicitly a later version."},
  {"label":"Get the data model server-ready even if UI slips","description":"Design the shape for sync now; accept a rougher UI at the workshop."},
  {"label":"Polish the UI, defer persistence","description":"Chips look great in the demo but vanish on reload."}]},

 {"question":"What's forcing this now?","header":"Trigger","multiSelect":false,"options":[
  {"label":"Workshop demo in 3 weeks (Recommended)","description":"Hard date; scope must fit it. Sets the bar at 'demoable and honest', not 'complete'."},
  {"label":"User complaints about re-typing filters","description":"Frames it as a UX pain fix; the measure of success is fewer repeated filter interactions."},
  {"label":"No hard driver, it's a nice-to-have","description":"Means we can afford the server version now and take longer."}]}
]}
```

**Answer:**
- Doc slug: **saved-filters.md**
- Goals: **Re-apply a filter combo in one click**, **Combos survive a page reload**
- Priority: **Ship small and local first**
- Trigger: **Workshop demo in 3 weeks** — *Other note:* "and honestly I re-type the same vegan + under-30-min combo ten times a day myself"

---

## Hand-back after Goals

```json
{"questions":[{"question":"Goals is written. Where next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Continue to Non-Goals (Recommended)","description":"Name what's deliberately out: cross-device sync, sharing, editing saved filters, folders/ordering — each with a why-not or not-yet."},
 {"label":"Revise Goals","description":"I'll ask what's off and rewrite the chapter."},
 {"label":"Pin down what 'demoable at the workshop' means","description":"Goal 3 is the vaguest one — worth deciding now whether the workshop is a demo-only bar or must-be-in-main."}]}]}
```

**Answer:** Continue to Non-Goals

---

## Round 2 — Non-Goals

```json
{"questions":[
 {"question":"Which of these are explicitly out of scope for v1?","header":"Out of scope","multiSelect":true,"options":[
  {"label":"Cross-device / server-side sync (Recommended)","description":"Not yet — revisit when there's a real user account behind it. Browser-local for v1."},
  {"label":"Sharing a saved filter with another user (Recommended)","description":"Not now. Needs a sharing surface and probably URLs; nothing depends on it."},
  {"label":"Renaming / editing an existing saved filter (Recommended)","description":"Delete + re-save covers it for v1 at a fraction of the UI cost."},
  {"label":"Reordering, pinning or foldering chips (Recommended)","description":"Only matters past ~10 saved filters; nobody has one yet."}]},

 {"question":"A reader would reasonably assume these ARE in scope. Which do we say aren't?","header":"Assumed-in","multiSelect":true,"options":[
  {"label":"A generic 'saved views' abstraction reusable elsewhere (Recommended)","description":"Saved filters are built for recipe search specifically. Generalizing before a second caller exists is guesswork."},
  {"label":"Saved filters appearing in the URL / deep-linkable (Recommended)","description":"Clicking a chip changes filters, not the address bar. Keeps us out of URL-serialization design."},
  {"label":"Auto-suggesting filters to save based on usage","description":"Cute, unbounded, and needs usage data we don't collect."},
  {"label":"Migrating existing filter state into a saved filter automatically","description":"No silent 'we saved this for you' behavior; saving is always explicit."}]},

 {"question":"Anything tempting we should reject on principle, so it doesn't creep back in?","header":"Rejected","multiSelect":true,"options":[
  {"label":"Adding a state management library (NgRx/signalStore) (Recommended)","description":"The existing signal-based store stays. New library = new team-wide idiom for one feature."},
  {"label":"Extracting a shared 'persistence' abstraction up front (Recommended)","description":"One localStorage read/write behind one small seam; no generic adapter layer until a second use case shows up."},
  {"label":"Versioned migration framework for stored filters","description":"A schema-version field is cheap; a migration framework for one shape is not."},
  {"label":"Server API contract designed now, implemented later","description":"Writing the endpoint spec in advance so the shape is 'sync-ready'."}]}
]}
```

**Answer:**
- Out of scope: **Cross-device / server-side sync**, **Sharing a saved filter**, **Renaming / editing**, **Reordering / pinning / foldering**
- Assumed-in: **Generic 'saved views' abstraction**, **URL / deep-linking**, **Migrating existing filter state automatically**
- Rejected on principle: **Adding a state management library**, **Extracting a shared persistence abstraction up front**
  - *Other:* "Keep the versioned-migration one out of the non-goals — I do want a plain `version` number in the stored blob, just no framework around it. And don't write a server API contract now; we'd design it wrong."

---

## Hand-back after Non-Goals

```json
{"questions":[{"question":"Non-Goals is written. Where next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Continue to Desired Behavior (Recommended)","description":"Happy path as worked examples, plus the edge cases: duplicate names, empty filter set, a saved filter pointing at a diet tag that no longer exists, storage unavailable."},
 {"label":"Revise Non-Goals","description":"I'll ask what's off and rewrite the chapter."},
 {"label":"Decide now whether delete-only (no rename) needs a confirm step","description":"It's the one non-goal that pushes work into Desired Behavior — deleting is now the only way to fix a typo in a name."}]}]}
```

**Answer:** Continue to Desired Behavior

---

## Round 3 — Desired Behavior

```json
{"questions":[
 {"question":"How does saving actually happen, from the outside?","header":"Save flow","multiSelect":false,"options":[
  {"label":"'Save this search' button next to the filter bar, prompts for a name inline (Recommended)","description":"One visible affordance. Inline name input appears in place; Enter saves, Escape cancels. No dialog, no route.","preview":"[ ingredient: tofu ] [ max 30 min ] [ diet: vegan ]      ( Save this search )\n\nclicked ->\n[ ingredient: tofu ] [ max 30 min ] [ diet: vegan ]  [ name it______ ] (Save)(x)"},
  {"label":"Chip row has a '+' that opens a small dialog","description":"Groups saving with the chips it produces, but adds a dialog and its focus-trap concerns.","preview":"Saved:  ( Weeknight vegan )  ( Quick pasta )  ( + )\n\nclicked -> modal: Name this filter [____] (Cancel)(Save)"},
  {"label":"Auto-name it from the filters, rename later","description":"Zero typing — 'tofu · <=30min · vegan'. But renaming is a non-goal, so bad names are permanent.","preview":"Saved:  ( tofu · <=30min · vegan )  ( <=15min )"}]},

 {"question":"What does clicking a saved chip do to the filters that are already set?","header":"Apply","multiSelect":false,"options":[
  {"label":"Replaces the whole filter set (Recommended)","description":"The chip is a snapshot: after clicking it, the filter bar shows exactly what was saved, nothing else. Predictable and easy to explain."},
  {"label":"Merges into current filters","description":"Additive. Harder to reason about — what happens to a max-cook-time already set to something else?"},
  {"label":"Replaces, and clicking the active chip again clears it","description":"Toggle behavior. Nice, but introduces an 'active chip' state to track and display."}]},

 {"question":"Which edge cases must v1 handle explicitly?","header":"Edges","multiSelect":true,"options":[
  {"label":"Saved filter references a diet tag that no longer exists (Recommended)","description":"You flagged this. Needs a decided answer, not a crash — drop the tag, or refuse to apply, or warn."},
  {"label":"Duplicate name (Recommended)","description":"Saving a second 'Weeknight vegan'. Either block it, or allow and let them coexist confusingly."},
  {"label":"Saving with no filters set (Recommended)","description":"An empty saved filter is a 'clear everything' button. Allow or block?"},
  {"label":"localStorage unavailable or full (Recommended)","description":"Private mode, quota exceeded. Feature should degrade, not break search."}]},

 {"question":"What must NOT change — the regression surface?","header":"Regressions","multiSelect":true,"options":[
  {"label":"Search works identically with zero saved filters (Recommended)","description":"Someone who never saves anything sees the same recipe search they see today."},
  {"label":"Existing filter bar interactions unchanged (Recommended)","description":"Typing an ingredient, setting max cook time, toggling diet tags all behave exactly as before."},
  {"label":"No extra HTTP requests on load","description":"Saved filters don't cost a round trip."},
  {"label":"Search results still update as filters change, same timing","description":"No new debounce or loading state introduced by applying a chip."}]}
]}
```

**Answer:**
- Save flow: **'Save this search' button next to the filter bar, inline name prompt**
- Apply: **Replaces the whole filter set**
- Edges: all four — **stale diet tag**, **duplicate name**, **empty filter set**, **storage unavailable**
  - *Other, on the stale tag:* "Apply the rest and tell them one tag was dropped. Don't silently swallow it and don't refuse to apply — refusing makes the chip useless forever."
  - *Other, on empty:* "Just block it. A chip that does nothing is a support ticket."
- Regressions: **zero saved filters unchanged**, **filter bar interactions unchanged**, **search results update same timing**

---

## Hand-back after Desired Behavior

```json
{"questions":[{"question":"Desired Behavior is written, with two TODOs still open (duplicate names, delete confirm). Where next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Close the two open TODOs first (Recommended)","description":"Duplicate-name handling and whether delete needs a confirm/undo. Both are one question each and both leak into Design if left open."},
 {"label":"Continue to Design & Implementation Details","description":"Where the code lives, the stored shape, how the store changes — and leave the two TODOs in the doc as open items."},
 {"label":"Revise Desired Behavior","description":"I'll ask what's off and rewrite the chapter."}]}]}
```

**Answer:** Close the two open TODOs first

---

## Round 3b — Closing the open TODOs

```json
{"questions":[
 {"question":"Someone saves a second filter named 'Weeknight vegan'. What happens?","header":"Dup names","multiSelect":false,"options":[
  {"label":"Block it — the save button refuses and says the name is taken (Recommended)","description":"Names stay meaningful and the chip row stays readable. Costs one validation check."},
  {"label":"Allow duplicates","description":"Zero code, but two identical chips with different filters is indistinguishable from a bug."},
  {"label":"Overwrite the existing one","description":"Gives you rename-by-resave for free, but it's a silent destructive action with no undo."}]},

 {"question":"Deleting is the only way to undo a bad name. Does it need protection?","header":"Delete","multiSelect":false,"options":[
  {"label":"No confirm — delete is immediate (Recommended)","description":"The cost of a mistake is retyping three filters and a name. Cheapest thing that's honest; a confirm dialog is more UI than the loss warrants."},
  {"label":"Confirm dialog","description":"Safe, but a modal for a 10-second loss, and modals bring focus-management work."},
  {"label":"Delete with a short undo affordance","description":"Best UX, but needs transient state and a timer — real work for a small risk."}]}
]}
```

**Answer:**
- Dup names: **Block it — the save button refuses and says the name is taken**
- Delete: **No confirm — delete is immediate**

---

## Hand-back after TODO closure

```json
{"questions":[{"question":"Both TODOs are closed in the doc. Next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Continue to Design & Implementation Details (Recommended)","description":"Where the code lives in the Nx workspace, the stored shape, how the existing signal store changes, and the storage seam."},
 {"label":"Revise Desired Behavior","description":"I'll ask what's off and rewrite the chapter."}]}]}
```

**Answer:** Continue to Design & Implementation Details

---

## Round 4 — Design & Implementation

```json
{"questions":[
 {"question":"Where does this code live in the Nx workspace?","header":"Location","multiSelect":false,"options":[
  {"label":"Inside the existing recipe-search lib, next to the filter bar (Recommended)","description":"No new Nx project, no new tsconfig path, no new test setup. Matches 'saved filters are for recipe search specifically'.","preview":"libs/recipe-search/\n  src/lib/\n    recipe-search.component.ts       (touched)\n    recipe-filter/\n      recipe-filter.component.ts     (touched: emits 'save' + accepts applied criteria)\n    recipe-search.store.ts           (touched: applyCriteria)\n    saved-filters/\n      saved-filters.component.ts     (new: chip row + save button + name input)\n      saved-filter-repository.ts     (new: load/save, localStorage behind it)\n      saved-filter.ts                (new: type + version const)"},
  {"label":"New libs/saved-filters Nx library","description":"Cleanly separated and independently testable, but a new project, new lint/test config, and an abstraction boundary for one consumer.","preview":"libs/saved-filters/\n  src/lib/saved-filters.component.ts\n  src/lib/saved-filter-repository.ts\nlibs/recipe-search/  (imports @whiskmate/saved-filters)"},
  {"label":"Inline in the recipe-search component file","description":"Smallest possible diff; the component file grows a persistence concern and gets hard to read."}]},

 {"question":"What's the stored shape in localStorage?","header":"Stored shape","multiSelect":false,"options":[
  {"label":"Versioned envelope wrapping a list of named criteria snapshots (Recommended)","description":"One key, one JSON blob. The version field is the cheap insurance you asked for; ids let chips be deleted without name collisions mattering.","preview":"// key: \"whiskmate.saved-filters\"\n{\n  version: 1,\n  filters: [\n    { id: \"a1b2\", name: \"Weeknight vegan\",\n      criteria: { ingredient: \"tofu\", maxCookTime: 30, dietTags: [\"vegan\"] } }\n  ]\n}"},
  {"label":"Bare array, no envelope","description":"Slightly less to write, but nowhere to put a version, so the first shape change is a guessing game.","preview":"// key: \"whiskmate.saved-filters\"\n[ { name: \"Weeknight vegan\", criteria: {...} } ]"},
  {"label":"One localStorage key per saved filter","description":"Avoids read-modify-write on the whole list, but listing means scanning keys by prefix.","preview":"whiskmate.saved-filter.a1b2 -> { name, criteria }\nwhiskmate.saved-filter.c3d4 -> { name, criteria }"}]},

 {"question":"How does applying a saved filter reach the existing signal store?","header":"Store wiring","multiSelect":false,"options":[
  {"label":"One new method on the existing store: setCriteria(criteria) (Recommended)","description":"Replaces the whole criteria signal in one write, which is exactly the 'chip is a snapshot' behavior. No new store, no new library.","preview":"// recipe-search.store.ts (existing, signal-based)\nreadonly criteria = signal<RecipeCriteria>(EMPTY_CRITERIA);\n\n// new:\nsetCriteria(criteria: RecipeCriteria) {\n  this.criteria.set(criteria);\n}"},
  {"label":"Call the existing per-field setters in sequence","description":"No store change at all, but N signal writes means N intermediate states, and the search may fire against a half-applied combo."},
  {"label":"A second store that owns saved filters and pushes into the first","description":"Separates concerns, but two stores syncing is exactly the complexity you don't want here."}]},

 {"question":"Where does the localStorage seam sit — this determines what tests fake?","header":"Storage seam","multiSelect":false,"options":[
  {"label":"A repository class calling localStorage directly, injected (Recommended)","description":"Tests use real localStorage (jsdom gives you one) and just clear it between tests. No fake to maintain, and the component test stays honest.","preview":"@Injectable({providedIn:'root'})\nexport class SavedFilterRepository {\n  getAll(): SavedFilter[]      // parse, validate, drop junk\n  add(name, criteria): void    // throws on duplicate name\n  remove(id: string): void\n}"},
  {"label":"An abstract StorageAdapter interface with a localStorage implementation","description":"Swappable for the future server version — but that's the premature abstraction you rejected in Non-Goals."},
  {"label":"No class; the component reads and writes localStorage itself","description":"Fewest files, but persistence and rendering in one place makes both harder to test."}]}
]}
```

**Answer:**
- Location: **Inside the existing recipe-search lib, next to the filter bar**
- Stored shape: **Versioned envelope wrapping a list of named criteria snapshots**
- Store wiring: **One new method on the existing store: `setCriteria(criteria)`**
  - *Other:* "Yes, and the reason matters — the sequential-setters option would fire the search against a half-applied combo, which is exactly the kind of thing that shows up as a flaky test."
- Storage seam: **A repository class calling localStorage directly, injected**

---

## Hand-back after Design & Implementation

```json
{"questions":[{"question":"Design & Implementation is written. Next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Continue to Testing Strategy (Recommended)","description":"Which of the Desired Behavior cases get tests, at what level, what's real vs faked, and what would make these tests brittle."},
 {"label":"Revise Design & Implementation","description":"I'll ask what's off and rewrite the chapter."},
 {"label":"Nail down where the 'one tag was dropped' message actually renders","description":"The thinnest part of the chapter — it's decided that a message appears and where the logic lives, but not what the UI is."}]}]}
```

**Answer:** Continue to Testing Strategy

---

## Round 5 — Testing Strategy

```json
{"questions":[
 {"question":"What level do the saved-filter tests sit at?","header":"Test level","multiSelect":false,"options":[
  {"label":"Through the recipe search component, real store, MSW-faked HTTP (Recommended)","description":"Matches how the rest of whiskmate is tested. Tests survive refactoring the store or the repository because they never name them.","preview":"render(RecipeSearchComponent)\nuser.type(ingredientInput, 'tofu')\nuser.click(saveButton); user.type(nameInput, 'Weeknight vegan{Enter}')\nexpect(screen.getByRole('button', {name:'Weeknight vegan'})).toBeVisible()"},
  {"label":"Unit-test SavedFilterRepository in isolation, thin component tests on top","description":"Faster and more granular, but the tests then know the repository's method names and break on refactor.","preview":"const repo = new SavedFilterRepository();\nrepo.add('Weeknight vegan', criteria);\nexpect(repo.getAll()).toHaveLength(1);"},
  {"label":"E2E only","description":"Highest confidence per test, slowest feedback, and there's no E2E harness set up for this."}]},

 {"question":"What's real and what's faked in those tests?","header":"Fakes","multiSelect":false,"options":[
  {"label":"Real store, real repository, real localStorage (jsdom), MSW for HTTP (Recommended)","description":"Only the network is faked, at the seam you already fake it at. localStorage gets cleared between tests. Nothing bespoke to maintain."},
  {"label":"Real store, in-memory fake repository, MSW for HTTP","description":"Avoids localStorage cleanup, but then persistence-across-reload is never actually exercised."},
  {"label":"Fake store too, component in isolation","description":"Fast, but tests the component against a mock's behavior rather than the store's."}]},

 {"question":"Which Desired Behavior cases earn a test?","header":"Cases","multiSelect":true,"options":[
  {"label":"Save a combo, it appears as a chip (Recommended)","description":"The happy path's first half."},
  {"label":"Click a chip, filters are replaced and results update (Recommended)","description":"The happy path's second half, and it covers the replace-not-merge decision."},
  {"label":"Saved filters survive a reload (Recommended)","description":"Re-render the component against the same storage. This is Goal 2, and it's the one an in-memory fake would silently not cover."},
  {"label":"Stale diet tag: rest applies, dropped tag is reported (Recommended)","description":"The edge case you flagged. Easy to get wrong and easy to regress."}]},

 {"question":"Anything to drive test-first, and what would make these brittle?","header":"TDD/brittle","multiSelect":true,"options":[
  {"label":"Drive the stale-tag case test-first (Recommended)","description":"The behavior is subtle and easy to talk yourself into a wrong implementation of; writing the test first pins what 'reported' means."},
  {"label":"Query chips by role and accessible name, never by CSS class (Recommended)","description":"Class-based queries break the moment the chip is restyled — the most likely brittleness source here."},
  {"label":"Never assert on localStorage contents directly (Recommended)","description":"Asserting on the JSON blob couples tests to the stored shape; assert through the UI after a re-render instead."},
  {"label":"Drive the duplicate-name rejection test-first","description":"Simple enough that test-after is fine."}]}
]}
```

**Answer:**
- Test level: **Through the recipe search component, real store, MSW-faked HTTP**
- Fakes: **Real store, real repository, real localStorage (jsdom), MSW for HTTP**
- Cases: all four — **save shows a chip**, **click replaces filters**, **survives reload**, **stale diet tag**
  - *Other:* "Add the block-on-empty and block-on-duplicate-name ones too, they're two lines each."
- TDD/brittle: **stale-tag test-first**, **query by role and accessible name**, **never assert on localStorage contents directly**

---

## Hand-back after Testing Strategy

```json
{"questions":[{"question":"Testing Strategy is written. Next?","header":"Next step","multiSelect":false,"options":[
 {"label":"Continue to Alternatives Considered (Recommended)","description":"Last chapter. I'll present back the forks you already rejected and we add revisit triggers to each."},
 {"label":"Revise Testing Strategy","description":"I'll ask what's off and rewrite the chapter."},
 {"label":"Add a test for the storage-unavailable case","description":"It's in Desired Behavior but didn't make the test list — jsdom makes it awkward to simulate."}]}]}
```

**Answer:** Continue to Alternatives Considered

---

## Round 6 — Alternatives Considered

```json
{"questions":[
 {"question":"These are the forks you rejected along the way. Which are worth recording?","header":"Alternatives","multiSelect":true,"options":[
  {"label":"Server-side storage instead of localStorage (Recommended)","description":"The real one — it's where you actually want to end up."},
  {"label":"A separate libs/saved-filters Nx library (Recommended)","description":"Tempting for cleanliness; lost to 'one consumer, no abstraction'."},
  {"label":"Merge semantics instead of replace when applying a chip (Recommended)","description":"Worth recording because someone will ask for it in review."},
  {"label":"Calling existing per-field setters in sequence instead of setCriteria (Recommended)","description":"Zero store change, lost on the half-applied-combo problem."}]},

 {"question":"And these smaller ones?","header":"More","multiSelect":true,"options":[
  {"label":"Unit-testing the repository in isolation (Recommended)","description":"Lost to your testing preference; the reason is worth writing down so it isn't re-argued."},
  {"label":"Abstract StorageAdapter interface (Recommended)","description":"Lost as premature abstraction. Directly tied to the server-side revisit trigger."},
  {"label":"Auto-naming saved filters from their criteria (Recommended)","description":"Lost because renaming is a non-goal, so a bad auto-name would be permanent."},
  {"label":"Overwrite-on-duplicate-name","description":"Would have given rename for free; lost as a silent destructive action."}]},

 {"question":"Any fork you'd already rejected before we started, that I never put on the table?","header":"Pre-rejected","multiSelect":false,"options":[
  {"label":"No, that's the full set (Recommended)","description":"Nothing else was in play."},
  {"label":"Yes — there's one I'd already ruled out","description":"Tell me and I'll record it with the others."}]}
]}
```

**Answer:**
- Alternatives: all four
- More: all four, including **overwrite-on-duplicate-name**
- Pre-rejected: *Other:* "Yes — IndexedDB. I ruled it out before you asked. It's the obvious 'proper' answer and it's completely disproportionate for a list of maybe ten objects."

---

## Final hand-back — doc complete

```json
{"questions":[{"question":"All six chapters are written: design-docs/saved-filters.md. What now?","header":"Doc done","multiSelect":false,"options":[
 {"label":"Consistency read-through, top to bottom (Recommended)","description":"Check the Goals still match the design they produced, and that nothing decided late contradicts something written early."},
 {"label":"Start implementing against the doc","description":"Begin with the stale-diet-tag test, since that's the one marked test-first."},
 {"label":"Leave it here","description":"Doc's done; you'll review it yourself before the team sees it."}]}]}
```

**Answer:** Consistency read-through, top to bottom

---

## Consistency read-through

Findings:
- Goal 2 ("survive a page reload") is directly served by the Testing Strategy decision to use
  real `localStorage` rather than an in-memory fake — consistent, and worth noting the link
  was deliberate.
- Non-Goals rejects a shared persistence abstraction; Design's storage-seam choice and
  Alternatives' `StorageAdapter` entry agree. No contradiction.
- Desired Behavior says the save button is unavailable on an empty filter bar; Testing
  Strategy case 5 covers it. Consistent.
- One genuine gap, reported rather than silently patched: Desired Behavior specifies
  behavior when **storage is unavailable or full**, but no test case covers it — it was
  raised in the Testing menu and not selected. Left as-is deliberately.
