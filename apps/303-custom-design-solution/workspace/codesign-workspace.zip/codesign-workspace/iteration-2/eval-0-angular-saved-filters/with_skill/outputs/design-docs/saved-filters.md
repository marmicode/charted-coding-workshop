# Saved Filters

> Status: Draft · 2026-09-24

## Goals

Ranked. When two conflict, the higher one wins.

1. **A user re-applies a filter combo they use often in one click.** Picking a saved
   chip restores ingredient + max cook time + diet tags together — no re-typing.
2. **Saved combos survive a page reload.** They're still there tomorrow morning in the
   same browser. (Storage mechanism is a Design decision, not a goal.)
3. **The feature is demoable at the workshop in 3 weeks.** Small enough that it's
   finished and honest by then, not half-wired.

**Priority order under pressure:** ship small and browser-local first. Anything that
needs a backend is a later version, explicitly.

**What's forcing this now:** the workshop in 3 weeks is the hard date. The itch behind
it is real though — Sam re-types the same "vegan + under 30 min" combo ten times a day.

**Observable signal it worked:** the same filter combo gets applied by clicking a chip
instead of being re-entered field by field.

_Parked for later chapters: localStorage vs. server (→ Design), stale diet tag
references (→ Desired Behavior), no new state library (→ Design)._

## Non-Goals

**Deferred — not now, roughly until:**

- **Cross-device / server-side sync.** Browser-local for v1. Revisit when there's a
  real user account to hang saved filters off.
- **Sharing a saved filter with another user.** Needs a sharing surface and probably
  URLs. Nothing in v1 depends on it.
- **Renaming or editing a saved filter.** Delete and re-save covers it at a fraction
  of the UI cost. Revisit if people actually complain.
- **Reordering, pinning or foldering chips.** Only starts mattering past roughly ten
  saved filters, and nobody has one yet.

**Would reasonably be assumed in scope — it isn't:**

- **A generic "saved views" abstraction reusable elsewhere in whiskmate.** This is built
  for recipe search specifically. Generalizing before a second caller exists is guesswork.
- **Saved filters in the URL / deep-linkable.** Clicking a chip changes the filters, not
  the address bar. Keeps us out of URL-serialization design entirely.
- **Automatically turning current filter state into a saved filter.** No silent "we saved
  this for you". Saving is always an explicit action.

**Rejected on principle:**

- **Adding a state management library** (NgRx, signalStore, anything). The existing
  signal-based store stays as-is. A new library means a new team-wide idiom for one feature.
- **Extracting a shared persistence abstraction up front.** One small seam for reading and
  writing; no generic adapter layer until there's a second use case to shape it.
- **Designing the server API contract now "so it's sync-ready".** We'd design it wrong
  without a real backend conversation. Not worth the false confidence.

_Explicitly not a non-goal: the stored payload carries a plain `version` number. Cheap
insurance. What we're refusing is a migration framework around it._

## Desired Behavior

### Saving

- A **"Save this search"** button sits next to the filter bar.
- Clicking it reveals an inline name input in place — no dialog, no navigation.
  Enter saves, Escape cancels.
- On save, a new chip with that name appears in the saved-filters row.

> **Given** the filter bar has ingredient "tofu", max cook time 30 min, diet tag "vegan"
> **When** Sam clicks "Save this search", types "Weeknight vegan" and presses Enter
> **Then** a chip labelled "Weeknight vegan" appears in the saved row, and it's still
> there after a reload.

### Applying

- Clicking a saved chip **replaces the entire filter set** with the saved snapshot.
  The chip is a snapshot, not an addition — after clicking, the filter bar shows exactly
  what was saved and nothing else.

> **Given** a saved filter "Weeknight vegan" and a filter bar currently showing
> ingredient "beef" and max cook time 90 min
> **When** Sam clicks the "Weeknight vegan" chip
> **Then** the filter bar shows tofu / 30 min / vegan, and the beef and 90 min are gone.

### Deleting

- A saved chip can be removed, immediately, with no confirm step and no undo. Deleting
  is the only way to fix a name — renaming is a non-goal — and the cost of a mistake is
  retyping three filters and a name, which doesn't warrant a modal.

### Edge cases

- **Saved filter references a diet tag that no longer exists.** Apply everything else
  and tell the user that one tag was dropped. Do not silently swallow it, and do not
  refuse to apply — refusing would make that chip useless forever.
- **Duplicate name.** Blocked. Saving under a name that already exists is refused and the
  user is told the name is taken. Two identical chips holding different filters is
  indistinguishable from a bug.
- **Saving with no filters set.** Blocked. A chip that does nothing is a support ticket.
  The save button is unavailable when the filter bar is empty.
- **Storage unavailable or full** (private mode, quota exceeded). Recipe search keeps
  working normally. Saving fails visibly rather than appearing to succeed; already-shown
  chips don't disappear mid-session.

### Must not change

- Search behaves identically for someone with zero saved filters.
- Every existing filter bar interaction — ingredient input, max cook time, diet tag
  toggles — behaves exactly as today.
- Results still update as filters change, with the same timing. Applying a chip
  introduces no new debounce or loading state.

## Design & Implementation Details

### Where it lives

Inside the existing `recipe-search` lib, next to the filter bar. No new Nx project, no new
tsconfig path, no new test setup — and it matches the non-goal: saved filters are for recipe
search specifically.

```
libs/recipe-search/
  src/lib/
    recipe-search.component.ts       (touched)
    recipe-filter/
      recipe-filter.component.ts     (touched: emits save, accepts applied criteria)
    recipe-search.store.ts           (touched: setCriteria)
    saved-filters/
      saved-filters.component.ts     (new: chip row + save button + inline name input)
      saved-filter-repository.ts     (new: load/save, localStorage behind it)
      saved-filter.ts                (new: type + version const)
```

All standalone components with signals, same as the rest of the lib.

### Stored shape

One localStorage key, one JSON blob, wrapped in a versioned envelope.

```ts
// key: "whiskmate.saved-filters"
{
  version: 1,
  filters: [
    { id: "a1b2", name: "Weeknight vegan",
      criteria: { ingredient: "tofu", maxCookTime: 30, dietTags: ["vegan"] } }
  ]
}
```

- **`version`** is the cheap insurance — a number, not a migration framework. On read, an
  unrecognised version means "ignore the blob", not "crash".
- **`id`** exists so deletion targets a specific entry rather than matching on name.
- **`criteria`** reuses the existing recipe search criteria type verbatim. Saved filters do
  not get a parallel filter model.

### Applying to the store

One new method on the existing signal-based store:

```ts
// recipe-search.store.ts (existing)
readonly criteria = signal<RecipeCriteria>(EMPTY_CRITERIA);

// new
setCriteria(criteria: RecipeCriteria) {
  this.criteria.set(criteria);
}
```

**Why one write rather than calling the existing per-field setters in sequence:** N writes
means N intermediate states, and the search would fire against a half-applied combo. That's
exactly the kind of thing that shows up later as a flaky test. One write is also literally
what "the chip is a snapshot" means.

No new store. No state management library.

### Storage seam

A `SavedFilterRepository` calling `localStorage` directly, injected:

```ts
@Injectable({ providedIn: 'root' })
export class SavedFilterRepository {
  getAll(): SavedFilter[]              // parse, validate, drop junk
  add(name: string, criteria: RecipeCriteria): void   // rejects duplicate name
  remove(id: string): void
}
```

Deliberately **not** an abstract `StorageAdapter` interface with a swappable implementation.
That's the premature abstraction ruled out in Non-Goals — when the server version arrives,
this class is the one place that changes, and we'll know then what the contract should be.

The repository is also where robustness lives: unparseable JSON, unknown `version`, and
missing fields all degrade to "no saved filters" rather than throwing into the component.

### Stale diet tags

Resolution happens at **apply** time, not at read time, and it lives in the component that
applies the chip — the repository doesn't know what a valid diet tag is.

- Intersect the saved `dietTags` against the diet tags currently offered by the filter bar.
- Apply the surviving criteria.
- Surface a message naming the dropped tag.
- The saved filter itself is **not** rewritten. If the tag comes back, the chip works fully
  again.

### What changes in existing code

- `recipe-search.store.ts` — one new `setCriteria` method. Nothing existing changes.
- `recipe-search.component.ts` — renders `<wm-saved-filters>` above/next to the filter bar,
  wires its apply output to `store.setCriteria`.
- `recipe-filter.component.ts` — exposes current criteria so a save can snapshot them.

### Load-bearing dependencies

- **`localStorage`** — the only real one, and the only thing that would change for the
  eventual server version.
- Everything else is Angular signals and the existing store. No new package.

### Rollout

Nothing stateful ships before this, so there's no migration. First run reads an absent key
and gets an empty list.

## Testing Strategy

### Level

Through the **recipe search component**, with the real store and MSW-faked HTTP — the same
way the rest of whiskmate is tested. Vitest + Angular Testing Library.

The store and the repository are never named by a test. That's the point: refactoring either
one shouldn't touch a single test file.

### What's real, what's faked

- **Real** — the signal store, `SavedFilterRepository`, and `localStorage` (jsdom provides
  one; clear it between tests).
- **Faked** — HTTP only, via MSW, at the seam it's already faked at today.

No in-memory fake repository. It would look tidier and would silently stop exercising
persistence-across-reload, which is Goal 2.

### Cases

1. Save a combo → a chip with that name appears.
2. Click a chip → the filter bar shows the saved criteria, the previous ones are gone, and
   results update. (Covers replace-not-merge.)
3. Saved filters survive a reload → re-render the component against the same storage, chips
   are still there.
4. Stale diet tag → the rest of the criteria apply and the dropped tag is reported.
5. Saving with an empty filter bar is blocked.
6. Saving under an existing name is rejected and the user is told.

### Test-first

Drive **case 4 (stale diet tag)** test-first. The behavior is subtle enough to talk yourself
into a wrong implementation of, and writing the test first forces a decision about what
"reported" concretely means in the UI. The rest can be test-after.

### Brittleness guards

- Query chips by **role and accessible name**, never by CSS class. Restyling a chip must not
  break a test.
- **Never assert on localStorage contents directly.** Asserting on the JSON blob couples the
  tests to the stored shape — which the `version` field exists precisely to let us change.
  Assert through the UI after a re-render instead.

## Alternatives Considered

**Server-side storage instead of localStorage**
Tempting because it's where we actually want to end up — saved filters per user, on every
device. Lost because there's no account plumbing to hang it off yet and it's the part most
likely to eat the three weeks before the workshop.
*Revisit when:* whiskmate has real user accounts, or someone asks for their filters on a
second device. `SavedFilterRepository` is the one file that changes.

**A separate `libs/saved-filters` Nx library**
Tempting for cleanliness and independent testability. Lost because there's exactly one
consumer, and a library boundary is an abstraction you have to guess the shape of.
*Revisit when:* a second feature in whiskmate wants saved criteria.

**Merge semantics instead of replace when applying a chip**
Tempting because additive feels more flexible. Lost because it has no good answer for
conflicting scalars — what happens to a max cook time that's already set?
*Revisit when:* someone demonstrates a real workflow that needs two chips at once.

**Calling the existing per-field setters in sequence instead of adding `setCriteria`**
Tempting because it requires no store change at all. Lost because N writes produce N
intermediate states and the search fires against a half-applied combo.
*Revisit when:* never, realistically — but if the store ever gets batched updates, this
stops being a reason.

**Unit-testing `SavedFilterRepository` in isolation**
Tempting for fast, granular feedback. Lost because those tests would know the repository's
method names and break on refactors that change nothing observable.
*Revisit when:* the repository grows logic complex enough that component-level tests can't
reach a branch. Not the case for get/add/remove.

**An abstract `StorageAdapter` interface**
Tempting as "we know the server version is coming, let's be ready". Lost as premature
abstraction — we'd be guessing at the contract without a backend conversation.
*Revisit when:* the server-side trigger above fires. Then we'll know the real contract.

**Auto-naming saved filters from their criteria** (`tofu · <=30min · vegan`)
Tempting because it removes the naming step entirely. Lost because renaming is a non-goal,
so an unhelpful auto-name would be permanent.
*Revisit when:* renaming ships.

**Overwrite on duplicate name**
Tempting because it would give rename-by-resave for free. Lost because it's a silent
destructive action with no undo.
*Revisit when:* there's an undo affordance to catch the mistake.

**IndexedDB** *(ruled out before the interview started)*
The obvious "proper" answer for client-side storage, and completely disproportionate for a
list of maybe ten small objects.
*Revisit when:* saved filters grow to hold something large, or there are hundreds of them.
