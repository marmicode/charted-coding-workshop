# Interview Log — Saved Filters

Every question that would have gone to `AskUserQuestion`, logged in real time, in the order
it was asked, with the answer that came back.

---

## Round 1 — Goals

```json
{"questions":[
{"question":"Skeleton is at design-docs/saved-filters.md. Is that the filename you'll want to search for later?",
 "header":"Doc slug","multiSelect":false,"options":[
  {"label":"saved-filters.md (Recommended)","description":"Matches the words you used. Short to tab-complete, specific enough to grep.","preview":"design-docs/\n  saved-filters.md"},
  {"label":"recipe-search-saved-filters.md","description":"Scopes it to recipe search, in case saved filters show up elsewhere in whiskmate later.","preview":"design-docs/\n  recipe-search-saved-filters.md"},
  {"label":"filter-presets.md","description":"'Preset' reads better if these end up shipped as built-ins too, not only user-created.","preview":"design-docs/\n  filter-presets.md"}]},
{"question":"Which of these are actually goals for v1? Pick all that hold — I'll rank them next.",
 "header":"Goals","multiSelect":true,"options":[
  {"label":"Re-apply a filter combo in one click","description":"The core outcome: a named combo comes back in one click instead of re-picking ingredient + cook time + diet tags."},
  {"label":"Saved filters survive a reload","description":"Still there tomorrow in the same browser. Real value; costs a persistence decision in the Design chapter."},
  {"label":"Saving is a two-second detour, not a workflow","description":"You save from the filter bar where you already are, not a settings page. Keeps the UI small."},
  {"label":"Combos sync across devices / are shareable","description":"Needs a server round-trip, user identity, and an API contract. Big scope jump for v1."},
  {"label":"Existing filter bar keeps working exactly as today","description":"Saved filters are additive. Anyone who ignores the chips notices no difference."}]},
