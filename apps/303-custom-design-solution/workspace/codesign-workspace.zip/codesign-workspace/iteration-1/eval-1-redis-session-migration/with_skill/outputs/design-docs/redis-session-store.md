# Redis Session Store

> Status: Draft · 2026-09-24

## Goals

Ranked. When two of these collide, the higher one wins.

1. **A signed-in user stays signed in whichever node serves the request.** With 3 nodes behind the load balancer, session identity is a property of the user, not of the box that happened to answer.
2. **Nobody is logged out by the rollout itself** — with one named exception. The cutover deploy loses the sessions live at that moment, because a `Map` dies with the process; that costs exactly what every deploy costs today, and **it is the last deploy that ever does**. Every deploy, rollback and scale-out after it preserves sessions. Outside that one deploy: no mass session invalidation, ever.
3. **Session lookup stays fast enough to be invisible on the request path** — under **5ms p99**, measured on the store call itself (`get(sessionId)` in and out), not on the whole authenticated request. Redis is already in the stack for the rate limiter, so the hop itself is a known quantity; the goal is not to double it with serialization overhead. (We have p99 per route but not per store call — see the instrumentation `TODO` in Design.)
4. **A developer can run the API and its test suite with no pre-provisioned Redis.** `git clone && npm test` works with nothing installed; the default CI job depends on no Redis service. (Testcontainers starting Redis on demand is fine — see Testing Strategy.) Structural constraint rather than a preference: a design that makes a standing Redis mandatory for local dev or CI is the wrong design, whatever its rank here.

### How we'll know it worked

- Re-login rate and 401 rate don't move **after the cutover deploy** — including across the 1-to-3 scale-out and every deploy following it. The cutover deploy itself is the one expected spike.
- p99 session lookup stays under 5ms in the API's existing metrics.
- All 3 nodes serve traffic with **no sticky sessions configured on the load balancer** — if stickiness is still needed, we haven't actually shared the state.

### When Redis is unreachable

Requests that need a session **fail** (5xx) rather than being treated as signed-out. A 503 is not a logout: an error the user retries through is survivable, a mass sign-out is a support incident. Sessions must still be there when Redis returns.

### What's forcing this now

The scale-out from 1 node to 3 is already scheduled, and this blocks it. Scope stays tight to unblocking that.

## Non-Goals

- **Changing what a session contains.** The payload stays user id, roles, feature-flag bucket. This is a storage swap; if behaviour changes during rollout, that's a bug in this work and not an intended difference.
- **Going stateless (JWT / signed cookies).** Tempting — it deletes the shared-state problem outright — but it also deletes instant revocation and makes the feature-flag bucket unchangeable mid-session. Not now.
- **Sticky sessions at the load balancer.** Rejected on principle, and explicitly **not** an emergency fallback. Stickiness just moves the problem: it doesn't survive a node dying, it wrecks rolling deploys, and it hides whether the shared store actually works. If we ever need it after this ships, that's a bug to fix, not a lever to pull.
- **Redis HA, failover, and clustering design.** We inherit whatever the rate limiter already runs on. Out of scope until that becomes the thing that's hurting.
- **New session features** — log out all devices, session listing, idle warnings. A shared store makes these cheap, which is exactly why they'll get proposed. Deferred until after the scale-out is boring.
- **A sweeper or background job for expiring sessions.** Not needed; see Design. Named here because it's the obvious thing to reach for when moving off a `Map`.
- **Encrypting the session payload at rest in Redis.** Out of scope for v1 so it doesn't block the rollout — but recorded as an **open question, not a settled no**.
  - _Revisit if:_ the payload starts carrying anything beyond id / roles / flag bucket, **or** Redis stops being a box we own.

## Desired Behavior

Observable from outside the API. "The session store" here means whatever is behind the interface — the behaviour below must hold for every implementation of it.

**Read on a different node**
- Given a session created while node A served the sign-in
- When a request carrying that session id is served by node B
- Then the user is signed in, with the same user id, roles, and feature-flag bucket

**Activity pushes the idle timeout back**
- Given a session that was last used 20 minutes ago
- When any request successfully reads it
- Then its expiry moves to 30 minutes from now, on every node

**Idle expiry**
- Given a session that has not been read for 30 minutes
- When a request carrying that session id arrives
- Then the user is treated as signed out — the session is gone, not stale

**Explicit sign-out**
- Given a user signed out on node A
- When their next request is served by node B
- Then they are signed out there too, on that very next request — no propagation delay

**Unknown or expired session id**
- Given a session id that the store doesn't have
- When a request carries it
- Then the user is treated as signed out (today's 401 / redirect-to-sign-in), **not** as an error

**Session store unreachable**
- Given the store is unreachable
- When a request that needs a session arrives
- Then the request fails loudly (5xx) — and the user's session is **not** invalidated; when the store returns, they are still signed in

**Concurrent update from two nodes**
- Given the same session is updated on node A and node B at nearly the same moment
- When both writes complete
- Then **the last write wins on the whole record** — one update is lost, and that is accepted. Roles change on the order of once a quarter per user; we are not building merge or version-check machinery for a collision we have never observed. Recorded here so nobody assumes merge semantics.

**Node restart mid-traffic**
- Given a user actively using the app
- When the node serving them is restarted or removed from the pool
- Then their next request succeeds on another node, still signed in

**During the rollout — before and after**
- Given a user signed in before the deploy
- When the deploy completes
- Then nothing is visible to them — no sign-in screen, no lost session. (How, in Design.)

**Mixed fleet — the 1-to-3 scale-out and every rolling deploy after it**
- Given more than one node serving, some on an older release and some on a newer one
- When the same user's requests land on nodes from either release, in any order
- Then they stay signed in throughout. No exceptions. This is exactly when traffic is being shuffled most, so it's where Goal 2 is most at risk — and it holds only because **no node keeps session state of its own**.

**Rollback**
- Given the cutover deploy is rolled back to the pre-Redis release
- When that release restarts holding only its in-process `Map`
- Then those users are signed out again. Accepted **once, for the cutover deploy only** — see Design: the `Map` dies with the process no matter what we ship, so no intermediate release can prevent it. Every rollback after the cutover is safe.

### Must stay exactly as it is today

- Session cookie name, format, and flags.
- Session id format and how ids are generated.
- Explicit sign-out kills the session immediately — now meaning "on all nodes", not just the one that handled it.
- An unknown or expired session id is signed-out, never an error. This is deliberately different from the store-unreachable case above, which fails loudly.

## Design & Implementation Details

### Where the code lives

```
src/session/
├── session-store.ts            # SessionStore interface + Session type
├── in-memory-session-store.ts  # dev, CI, unit tests
├── redis-session-store.ts      # production
├── create-session-store.ts     # env → implementation, production guard
└── session-store.test.ts       # one contract suite, run against both
```

Both implementations sit next to each other on purpose: a contract test over the pair becomes the obvious thing to write, and drift between them shows up in review rather than in production.

A thin Fastify plugin at the edge provides `request.session`. **The store itself stays framework-free** so it can be tested without standing up a server.

### The interface

```ts
type Session = {
  userId: string;
  roles: string[];
  flagBucket: string;
};

interface SessionStore {
  get(id: string): Promise<Session | undefined>;
  set(id: string, session: Session): Promise<void>;
  delete(id: string): Promise<void>;
}
```

Three methods, deliberately. **TTL is owned by the store and invisible to callers** — a caller can't get the idle timeout wrong if it never touches it, "a read extends expiry" is enforced in exactly one place, and the smaller the interface, the less painful the in-memory implementation is to keep honest. The idle timeout is store construction config, not a per-call argument.

### Storage shape and TTL

One key per session, JSON string value:

```
key:   session:<sessionId>
value: {"userId":"u_123","roles":["admin"],"flagBucket":"b7"}
ttl:   1800000 ms, sliding
```

| Operation | Redis |
|---|---|
| `get` | `GETEX session:<id> PX 1800000` |
| `set` | `SET session:<id> <json> PX 1800000` |
| `delete` | `DEL session:<id>` |

- **`GETEX`, not `GET` + `PEXPIRE`.** One round trip, value and expiry together, atomic. This is what keeps the 5ms p99 honest — one RTT per request, not two. Requires Redis 6.2+; we're on 7.x.
- **Expiry is Redis's job.** Key expiry, no sweeper, no cron. The in-memory implementation mirrors this by storing an expiry timestamp and treating an expired entry as absent **on read** — same lazy semantics, still no sweeper.
- **JSON string, not a hash.** `GETEX` only works on strings, and the payload is ~100 bytes so parse cost is noise against 5ms. It also stays readable from `redis-cli` on the day that matters. Per-field updates were the only argument for a hash, and last-write-wins already ruled those out.
- **Session ids are used as-is** in the key, under a `session:` prefix — no translation, so sessions minted by the old code would be valid keys.

### No cache in front of the store

Explicitly forbidden. Desired Behavior says sign-out is visible on the *very next* request, literally. Any node-local cache of sessions — even a few seconds — means a signed-out user still holds a valid session somewhere. If the 5ms budget is ever missed, the fix is in Redis or serialization, not a cache.

### Wiring and the production guard

```
SESSION_STORE=memory | redis     (default: memory)

if (NODE_ENV === 'production' && store === 'memory')
  throw new Error('refusing to boot: SESSION_STORE=memory in production');
```

- **Explicit variable, not inferred from `REDIS_URL`.** Inferring fails silently: unset the URL by accident and you get in-memory sessions with no warning — which is the exact bug this document exists to prevent.
- **Defaults to memory**, so `git clone && npm test` works with nothing installed (Goal 4).
- **Fails fast in production.** A misconfigured box refuses to start rather than quietly running three nodes with three private session tables.

### Redis connection

Same server and same client library as the existing rate limiter — no new operational surface, and Non-Goals put Redis topology out of scope.

**Its own client instance, not the rate limiter's.** A slow rate-limiter command must not be able to queue ahead of a session read on a shared connection; that isolation is what protects the p99. Namespaces stay distinct: `session:*` here, `ratelimit:*` already in use.

### When Redis is unreachable

Errors from the store **propagate**. The request fails with a 5xx. There is no fallback to the in-memory implementation in production — that would give each node its own view of who's signed in, and those sessions would vanish on recovery. A read that *succeeds* and finds nothing is a signed-out user; a read that *fails* is an error. Those two must never be collapsed into one code path.

### Cutover

```
1. Deploy the Redis store, in a low-traffic window
   → live sessions are lost, exactly as with any deploy today
2. Verify on the single node: restart it, stay signed in
3. Add nodes 2 and 3 behind the LB — no stickiness
```

The reasoning, because it's the part most likely to be re-litigated: **a `Map` dies with the process.** The first deploy carrying any Redis code necessarily loses whatever is in memory at that moment, because the code that would have dual-written wasn't running before the restart. A dual-write intermediate release doesn't avoid this, and a pre-seeding admin endpoint only moves the same logout one deploy earlier while leaving throwaway code behind.

Since every deploy today already drops every session, step 1 costs exactly what a normal deploy costs. **It is the last deploy that ever does.** That is a fix, not a regression — record it that way.

Step 3 doesn't start until step 2 has actually been observed.

- `TODO:` pick the low-traffic window, and decide whether the cutover logout gets announced.

### Load-bearing dependencies

- **Redis 6.2+** for `GETEX`. On 7.x today; a downgrade below 6.2 would force the pipelined `GET` + `PEXPIRE` fallback.
- **The existing Redis client library** — whichever the rate limiter already uses. Not a new dependency.
- `TODO:` confirm the API already exposes a latency histogram we can hang the 5ms p99 on. If it doesn't, adding one is part of this work — Goals named it as the success signal.

## Testing Strategy

`node:test`, with **testcontainers** for the Redis half — the house rule for anything touching a real backing service. **No mocked Redis client, ever**: a mock tests our idea of Redis, and would pass happily with `GETEX` used wrongly.

### Write the contract suite first

The store contract is written **test-first against the in-memory implementation** and made green. Then the same suite is pointed at Redis and that is made to pass.

If the Redis implementation needs the suite *changed* to go green, the interface was wrong — and that should surface on day one, not after it's wired into routes.

### The seam

```
session-store.test.ts
  └─ describe.each([
       ['in-memory', makeInMemoryStore],
       ['redis',     makeRedisStoreOnTestcontainer],
     ])

route tests → in-memory store, no container
```

One suite, same assertions, run twice. Goal 4 means two implementations exist; running identical assertions over both is what stops them drifting. Route tests use the in-memory store so the everyday suite needs no Docker.

**Where the Redis half runs.** Everywhere, including CI. Goal 4 means no *pre-provisioned* Redis service is required — `npm test` on a fresh laptop and the default CI job must not depend on one — and testcontainers satisfies that by starting Docker on demand.

- **No Docker available → skip loudly**, with a message naming what was skipped and why. A partial green that says so is fine; a silent one is not.
- **CI fails the job if the Redis suite skipped.** Not optional. A skip nobody notices is worse than no test at all, because it looks like coverage.

### What gets tested

**Store contract — both implementations** (each line is a Desired Behavior scenario):

- A session written through one store instance is readable through another. *(Read on a different node.)*
- A successful read pushes expiry out. *(Activity pushes the idle timeout back.)*
- A session not read within its TTL is gone — `undefined`, not stale. *(Idle expiry.)*
- A deleted session is absent from the very next read through any instance. *(Explicit sign-out.)*
- An unknown id reads as `undefined`, not an error. *(Unknown or expired session id.)*
- Two writes to the same id: the later one wins, whole record. *(Concurrent update.)*

**Redis implementation only:**

- Redis unreachable → the error propagates as a 5xx; the session is **not** treated as absent. Stop the container mid-test. The slowest test here, and the one behaviour where a bug looks like success — a 401 would pass a naive test while silently signing everyone out.

**Boot:**

- `SESSION_STORE=memory` with `NODE_ENV=production` refuses to start. Cheap, and it guards the thing that would otherwise give three nodes three private session tables.

**End to end — one test, not a suite:**

- Sign in, read the session on a following request, sign out. Proves the Fastify plugin actually wires the store to `request.session`. The contract suite already covers the store itself.

### Testing a 30-minute sliding TTL

Construct the store with a tiny TTL and let it genuinely expire:

```ts
const store = makeStore({ ttlMs: 150 });

await store.set(id, session);
await sleep(60);
await store.get(id);                      // extends
await sleep(120);
assert.ok(await store.get(id));           // still alive — sliding works
await sleep(200);
assert.equal(await store.get(id), undefined);  // expired
```

- Works identically for both implementations, and actually exercises **Redis key expiry** — the mechanism chosen over a sweeper. A `PTTL` assertion would pass even if expiry never fired.
- A fake clock was rejected: Redis expires on its own clock, so the Redis half couldn't use it, and two different TTL tests defeat the point of a shared contract.
- This is only possible because **TTL is construction config rather than a call argument** — a direct payoff of the interface choice in Design.

### What would make these brittle — avoid

- **Asserting on key names or Redis commands.** That freezes `session:` into a public API. Assert through the interface.
- **Tests sharing one Redis database without isolation.** Leftover keys make failures order-dependent and impossible to reproduce alone.
- **A container per test file.** Turns a 5-second suite into a 90-second one, people stop running it locally, and the coverage is lost. One container, reused.
- **Fixed sleeps as general synchronisation.** Fine in the expiry tests, where waiting *is* the behaviour under test. Anywhere else it's a flake generator.

## Alternatives Considered

### Sticky sessions at the load balancer

- **Tempting because:** zero application code. Turn it on at the LB and scale to 3 nodes tomorrow.
- **Lost because:** it just moves the problem. A session still lives in one node's memory, so it doesn't survive that node dying, it wrecks rolling deploys, and it means we'd never find out whether session state was actually shared. It is also recorded as a Non-Goal, including as an emergency lever — if stickiness is ever needed after this ships, that's a bug to fix, not a lever to pull.
- **Revisit if:** never, for session correctness. Stickiness for an unrelated reason (cache warmth, connection affinity) is a different conversation.

### Stateless sessions — JWT or signed cookies

- **Tempting because:** it deletes the shared-state problem outright. No store, no network hop, no 5ms budget to defend.
- **Lost because:** it deletes instant revocation with it. Sign-out has to be visible on the very next request, and the feature-flag bucket has to be changeable mid-session; neither works when the session is a signed blob in the client's hands.
- **Revisit if:** session reads ever become a genuine Redis bottleneck, **and** the payload no longer needs mid-session mutability or immediate revocation. Both, not either.

### Sessions in the primary Postgres database

- **Tempting because:** no new store at all, transactional with everything else, and it's the default answer at most shops.
- **Lost because:** every authenticated request becomes a query against the primary. Hitting 5ms p99 would be luck rather than design, and Redis was already in the stack for the rate limiter — so this was never a close call.
- **Revisit if:** we ever need sessions to be transactional with user or org data.

### Two-deploy cutover with a dual-write intermediate release

- **Tempting because:** it's the standard safe-migration shape, and it looks strictly safer than one deploy.
- **Lost because:** it isn't safer here. The `Map` dies with the process, and the dual-writing code isn't running until *after* the restart — so deploy 1 loses live sessions either way. It buys an extra release to write, test and later delete, in exchange for nothing.
- **Revisit if:** deploys ever overlap (rolling or blue-green) *before* the cutover ships. Then there's a real mixed-fleet window and the intermediate release earns its place.

### Pre-seeding Redis from the `Map` via a temporary admin endpoint

- **Tempting because:** it looks like the trick that saves the live sessions.
- **Lost because:** same trap one step removed — the deploy that adds the endpoint is itself a restart. It moves the same logout earlier and leaves throwaway code behind.
- **Revisit if:** the running process ever gains a way to export session state without restarting. It doesn't have one.

### Falling back to the in-memory store when Redis is down

- **Tempting because:** under incident pressure it looks like the obvious mitigation — keep serving instead of returning 5xx.
- **Lost because:** each node would invent its own view of who's signed in, and those sessions vanish on recovery. It converts a clean, retryable outage into silent inconsistency. The stance from Goals stands: a 503 is not a logout.
- **Revisit if:** never with this session model. It only becomes coherent if sessions stop being security-relevant.

### A node-local cache in front of the store

- **Tempting because:** it's the first thing anyone reaches for if the 5ms p99 is missed.
- **Lost because:** it breaks immediate sign-out — a signed-out user keeps a valid session on whichever node cached it. If the budget is missed, the fix is in Redis or serialization.
- **Revisit if:** the sign-out-is-immediate requirement is ever relaxed. It isn't today.

### A sweeper or background job for expiry

- **Tempting because:** it's the direct translation of what a `Map` forces you to do.
- **Lost because:** Redis already expires keys, `GETEX` refreshes the TTL in the same round trip as the read, and the in-memory implementation gets the same semantics by treating expired entries as absent on read. A sweeper would be a second source of truth for expiry.
- **Revisit if:** we ever need an action *at* expiry (an event, a webhook) rather than just absence afterwards.

### Keeping the in-memory implementation at all

- **Tempting to drop because:** one code path everywhere is simpler, and two implementations can drift.
- **Kept because:** Goal 4 — `git clone && npm test` must work with nothing installed. The contract suite running over both is what manages the drift risk.
- **Revisit if:** the two drift often enough that the contract suite stops catching it — at which point the interface is probably too big.

### Sharing one Redis with the rate limiter

- **Tempting to separate because:** full blast-radius isolation.
- **Kept shared because:** no new operational surface, and Redis topology is a Non-Goal. Sessions get their own client instance and key prefix, so the two don't share a command queue.
- **Revisit if:** rate-limiter load ever shows up in session p99.

### Per-field merge or optimistic concurrency on writes

- **Tempting because:** no lost updates, and "last write wins" reads like a bug in a design doc.
- **Lost because:** roles change on the order of once a quarter per user. A read-modify-write or a version check on every session write is real cost against a 5ms budget, for a collision we have never observed.
- **Revisit if:** a lost role update ever actually reaches a user.
