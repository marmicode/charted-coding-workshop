# Interview Log — Redis Session Store

Simulated `AskUserQuestion` calls and the answers given, in the order they happened.

---

## Round 1 — Goals

```json
{
  "questions": [
    {
      "question": "I'll write this to `design-docs/redis-session-store.md`. Good slug?",
      "header": "Slug",
      "multiSelect": false,
      "options": [
        {
          "label": "redis-session-store (Recommended)",
          "description": "Names the thing being built rather than the migration event, so the doc still reads right a year from now when nobody remembers there was a Map.",
          "preview": "design-docs/redis-session-store.md"
        },
        {
          "label": "distributed-sessions",
          "description": "Backing-store-agnostic — better if you think Redis might not be the final answer, worse for searching when someone greps for 'redis'.",
          "preview": "design-docs/distributed-sessions.md"
        },
        {
          "label": "session-storage-migration",
          "description": "Frames the doc as a one-time migration; risks the doc getting archived as 'done' once the cutover ships, even though the design outlives it.",
          "preview": "design-docs/session-storage-migration.md"
        }
      ]
    },
    {
      "question": "What has to be true once this ships? (pick all that apply)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {
          "label": "A session works on any node",
          "description": "Any of the 3 nodes can serve any request for a session regardless of which node created it. This is the reason the work exists; without it the load balancer needs sticky routing.",
          "preview": null
        },
        {
          "label": "Zero forced logouts at cutover",
          "description": "Nobody signed in today gets bounced to the login screen when we deploy. Costs us a dual-read window and some migration complexity, but a logout storm is the most visible way this can go wrong.",
          "preview": null
        },
        {
          "label": "Session lookup stays fast",
          "description": "Reads stay in the same ballpark as a Map lookup so no endpoint gets visibly slower. Constrains us to a single round trip per request and rules out chatty multi-key reads.",
          "preview": null
        },
        {
          "label": "Redis stays optional for local dev and CI",
          "description": "`npm test` and a local `npm start` work with no Redis running. Costs us an extra implementation to maintain, buys a contributor onboarding that doesn't start with docker-compose.",
          "preview": null
        }
      ]
    },
    {
      "question": "When two of those collide under deadline pressure, which wins?",
      "header": "Priority",
      "multiSelect": false,
      "options": [
        {
          "label": "Correctness of sessions beats latency (Recommended)",
          "description": "If we have to choose, we take a slower session lookup over a session that's wrong or missing. Means we won't paper over a Redis failure by falling back to local memory and silently splitting state.",
          "preview": null
        },
        {
          "label": "Latency beats correctness",
          "description": "Under Redis trouble we'd serve from a local cache and accept stale or divergent sessions. Faster, but reintroduces exactly the per-node state we're removing.",
          "preview": null
        },
        {
          "label": "Availability beats both",
          "description": "If Redis is down we mint fresh sessions rather than erroring. Keeps the API up, but that IS the logout storm, just triggered by an incident instead of a deploy.",
          "preview": null
        }
      ]
    },
    {
      "question": "What's the observable signal, a week after cutover, that this worked?",
      "header": "Success signal",
      "multiSelect": true,
      "options": [
        {
          "label": "Login rate stays flat across the deploy",
          "description": "A spike in logins is the cheapest proxy for 'we dropped sessions'. Requires no new instrumentation if you already count logins.",
          "preview": null
        },
        {
          "label": "Session lookup p99 under a stated budget",
          "description": "Needs a timing metric around the store call specifically, not just endpoint latency. Gives you a number to regress against later.",
          "preview": null
        },
        {
          "label": "3 nodes serving with no sticky routing on the LB",
          "description": "The LB config itself becomes the proof — if session affinity is off and nothing breaks, state is genuinely shared.",
          "preview": null
        },
        {
          "label": "Zero support tickets about being logged out",
          "description": "The real-world signal, but slow and noisy; good as a backstop, bad as the primary gate.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Slug:** `redis-session-store (Recommended)`
- **Goals:** `A session works on any node`, `Zero forced logouts at cutover`, `Session lookup stays fast`, `Redis stays optional for local dev and CI` — all four. Alex adds: *"the latency one has a number — 5ms p99 for the lookup. And the local-dev one isn't a nice-to-have, I don't want Redis to become mandatory to run the test suite."*
- **Priority:** `Correctness of sessions beats latency (Recommended)` — *"yeah. and the no-logout thing is above everything, including latency. if I have to eat 8ms for a week to not log everyone out, I eat 8ms."*
- **Success signal:** `Login rate stays flat across the deploy`, `Session lookup p99 under a stated budget`, `3 nodes serving with no sticky routing on the LB`
- **Forcing function (volunteered):** *"we're going from 1 node to 3 behind the LB, that's already scheduled. this has to land before that."*
