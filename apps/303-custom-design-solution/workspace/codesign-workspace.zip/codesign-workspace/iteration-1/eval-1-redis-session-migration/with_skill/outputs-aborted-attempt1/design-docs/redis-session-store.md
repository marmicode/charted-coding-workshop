# Redis Session Store

> Status: Draft · 2026-09-24

## Goals

Ranked. When two conflict, the higher one wins.

1. **Nobody is logged out because of this change.** Every session that exists before the cutover keeps working after it. No login spike, no "why am I signed out" tickets. This sits above everything else, including latency — Alex: *"if I have to eat 8ms for a week to not log everyone out, I eat 8ms."*
2. **A session works on any node.** Any of the 3 nodes behind the load balancer can serve any request for any session, regardless of which node created it — with no session affinity configured on the LB.
3. **Session lookup stays under 5ms p99.** Measured around the store call itself, not end-to-end endpoint latency.
4. **Redis stays optional for local dev and CI.** `npm test` and a local run work with no Redis process running. Not a nice-to-have — a contributor's first day shouldn't start with `docker-compose up`.

**Conflict rule:** correctness of sessions beats latency. If Redis is unhealthy we do not fall back to serving sessions out of local memory, because that silently reintroduces the per-node state this work exists to remove.

**What's forcing this now:** the 1 → 3 node scale-out behind the LB is already scheduled. This has to land before it.

**How we'll know it worked (one week after cutover):**
- Login rate stays flat across the deploy — the cheapest proxy for "we dropped sessions".
- Session lookup p99 stays under the 5ms budget.
- All 3 nodes serve traffic with session affinity switched off on the LB and nothing breaks.

## Non-Goals

_Pending._

## Desired Behavior

_Pending._

## Design & Implementation Details

_Pending._

## Testing Strategy

_Pending._

## Alternatives Considered

_Pending._
