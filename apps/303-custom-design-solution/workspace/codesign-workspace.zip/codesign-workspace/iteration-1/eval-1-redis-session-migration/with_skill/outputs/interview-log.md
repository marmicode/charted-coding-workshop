# Interview Log — Redis Session Store

Every `AskUserQuestion` call that would have been made, in the order it would have
been made, with the answer that came back.

---

## Round 1 — Goals (first pass)

```json
{
  "questions": [
    {
      "question": "I've created the skeleton at `design-docs/redis-session-store.md`. Happy with that filename?",
      "header": "Filename",
      "multiSelect": false,
      "options": [
        {
          "label": "redis-session-store.md (Recommended)",
          "description": "Names the thing being built, so it still makes sense once the migration is ancient history.",
          "preview": "design-docs/\n└── redis-session-store.md"
        },
        {
          "label": "session-store-multi-node.md",
          "description": "Names the problem rather than the solution — ages better if Redis is later swapped for something else, but harder to grep for.",
          "preview": "design-docs/\n└── session-store-multi-node.md"
        },
        {
          "label": "redis-session-migration.md",
          "description": "Emphasises the one-time migration. Risks reading as stale the day after rollout finishes.",
          "preview": "design-docs/\n└── redis-session-migration.md"
        }
      ]
    },
    {
      "question": "Which of these are actual goals for this work? (I'll rank them next.)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {
          "label": "A signed-in user stays signed in whichever node serves the request",
          "description": "The core outcome. Rules out any design where session state is node-local, including sticky sessions as a permanent answer.",
          "preview": null
        },
        {
          "label": "Nobody is logged out by the rollout itself",
          "description": "Makes the cutover a design constraint, not an ops detail — forces a dual-read or drain period instead of a flag flip.",
          "preview": null
        },
        {
          "label": "Session lookup stays fast enough to be invisible on the request path",
          "description": "Turns 'we added a network hop' into a number we have to hold. Costs us a latency budget and a metric to watch.",
          "preview": null
        },
        {
          "label": "Local dev and CI still run with no Redis process",
          "description": "Forces the store behind an interface with two implementations, rather than just importing a Redis client at the call site.",
          "preview": null
        }
      ]
    },
    {
      "question": "What's the observable signal that this actually worked?",
      "header": "Success signal",
      "multiSelect": true,
      "options": [
        {
          "label": "Re-login / 401 rate doesn't move during or after rollout",
          "description": "Directly measures 'nobody got logged out'. Needs the metric to exist before cutover, so it's work up front.",
          "preview": null
        },
        {
          "label": "p99 session lookup stays under 5ms",
          "description": "A hard number we can alert on. Pins the design to a local/low-latency Redis and cheap serialization.",
          "preview": null
        },
        {
          "label": "3 nodes serve traffic with no sticky sessions on the LB",
          "description": "Proves the state is genuinely shared. Also means we can't quietly fall back to stickiness if something goes wrong.",
          "preview": null
        },
        {
          "label": "A node can be restarted mid-traffic with no user-visible effect",
          "description": "Stronger than the above — makes deploys and autoscaling safe too, but adds a test we have to actually run.",
          "preview": null
        }
      ]
    },
    {
      "question": "What's forcing the timing here?",
      "header": "Why now",
      "multiSelect": false,
      "options": [
        {
          "label": "The scale-out to 3 nodes is already scheduled — this blocks it",
          "description": "Makes this a hard dependency of another piece of work, so scope should stay tight to unblocking it.",
          "preview": null
        },
        {
          "label": "We're already multi-node and users are getting logged out",
          "description": "Turns this into incident remediation — different urgency, and the rollout constraint gets weaker because sessions are already breaking.",
          "preview": null
        },
        {
          "label": "No hard deadline, we want it ready before we need it",
          "description": "Buys room for the nicer version (encryption, metrics, a proper migration window).",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Filename:** `redis-session-store.md (Recommended)`
- **Goals:** all four — `A signed-in user stays signed in whichever node serves the request`, `Nobody is logged out by the rollout itself`, `Session lookup stays fast enough to be invisible on the request path`, `Local dev and CI still run with no Redis process`
- **Success signal:** `Re-login / 401 rate doesn't move during or after rollout`, `p99 session lookup stays under 5ms`, `3 nodes serve traffic with no sticky sessions on the LB`
  - _Other (added):_ "5ms p99 is the number, not a vibe. Redis is already in the stack for the rate limiter so the hop is a known quantity — I just don't want to find out we've doubled it with JSON overhead."
- **Why now:** `The scale-out to 3 nodes is already scheduled — this blocks it`

---

## Round 2 — Goals (priority order)

```json
{
  "questions": [
    {
      "question": "These four will conflict under pressure. Which ranking do you want recorded?",
      "header": "Priority",
      "multiSelect": false,
      "options": [
        {
          "label": "Correctness → rollout safety → latency → dev ergonomics (Recommended)",
          "description": "Says: we'd accept a slower session lookup before we'd accept a user seeing the wrong session. Dev/CI ergonomics is a structural constraint we hold, but it never outranks a user-facing outcome.",
          "preview": "1. A signed-in user stays signed in on any node\n2. Nobody is logged out by the rollout\n3. Lookup stays under 5ms p99\n4. Dev + CI run without Redis"
        },
        {
          "label": "Latency first, then correctness",
          "description": "Says: if hitting Redis can't be made fast, we'd rather keep node-local sessions and solve stickiness at the LB. Effectively keeps sticky sessions alive as a fallback.",
          "preview": "1. Lookup stays under 5ms p99\n2. A signed-in user stays signed in on any node\n3. Nobody is logged out by the rollout\n4. Dev + CI run without Redis"
        },
        {
          "label": "Rollout safety first, above everything",
          "description": "Says: we'd extend the migration window indefinitely rather than drop a single session. Can leave a dual-read path in the code long after it's useful.",
          "preview": "1. Nobody is logged out by the rollout\n2. A signed-in user stays signed in on any node\n3. Lookup stays under 5ms p99\n4. Dev + CI run without Redis"
        }
      ]
    },
    {
      "question": "Redis is unreachable for 30 seconds in production. What's the goal-level stance?",
      "header": "Redis down",
      "multiSelect": false,
      "options": [
        {
          "label": "Fail the request, keep the session (Recommended)",
          "description": "Requests error out while Redis is down, but nobody's cookie is invalidated — when Redis comes back, everyone is still signed in. Costs availability during the outage.",
          "preview": null
        },
        {
          "label": "Fall back to a node-local in-memory store",
          "description": "Requests keep succeeding, but each node invents its own view of who's signed in, and those sessions vanish on recovery. Trades correctness for uptime.",
          "preview": null
        },
        {
          "label": "Treat the session as absent and send the user to sign in again",
          "description": "Simplest code path — a read miss is a read miss. But a blip logs out everyone who was active during it, which is the thing we're trying to avoid.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Priority:** `Correctness → rollout safety → latency → dev ergonomics (Recommended)`
  - _Other (added):_ "Ranking's right, but note that #4 isn't really tradeable — it's a constraint on how we build it, not a nice-to-have. If the design makes Redis mandatory to run the test suite, the design is wrong, regardless of where it sits in the list."
- **Redis down:** `Fail the request, keep the session (Recommended)`
  - _Other (added):_ "A 503 is not a logout. That distinction is the whole point — an error the user retries through is survivable, a mass sign-out is a support incident."

---

## Hand-back — after Goals

```json
{
  "questions": [
    {
      "question": "Goals is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Non-Goals (Recommended)",
          "description": "The things a reader would assume are in scope and aren't — session data model changes, auth/login flow, Redis HA, cross-region. Cheapest chapter to write, saves the most review time.",
          "preview": null
        },
        {
          "label": "Revise Goals",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Pin down where the 5ms is measured",
          "description": "Right now '5ms p99' could mean the store call alone or the whole authenticated request. Those are different budgets and they bind different parts of the design.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Non-Goals (Recommended)`
- _Other (added):_ "Quick one so you don't have to ask later: the 5ms is the store call itself — `get(sessionId)` in and out. The request budget is a different conversation and I don't want it tangled up in this doc."

---

## Round 3 — Non-Goals

```json
{
  "questions": [
    {
      "question": "Which of these should the doc say explicitly are NOT in scope?",
      "header": "Out of scope",
      "multiSelect": true,
      "options": [
        {
          "label": "Changing what a session contains",
          "description": "Payload stays user id + roles + feature-flag bucket. Keeps the migration a pure storage swap, so any behaviour change during rollout is unambiguously a bug in this work.",
          "preview": null
        },
        {
          "label": "Going stateless (JWT / signed cookies, no server-side session)",
          "description": "It would delete the problem entirely, but it also deletes instant revocation and makes the feature-flag bucket unchangeable mid-session. Worth naming so it isn't re-proposed in review.",
          "preview": null
        },
        {
          "label": "Redis HA, failover, or clustering design",
          "description": "We inherit whatever the rate limiter already runs on. Saying so stops this doc from growing an infrastructure chapter it can't finish.",
          "preview": null
        },
        {
          "label": "New session features (log out all devices, session listing, idle warnings)",
          "description": "A shared store makes these suddenly cheap, which is exactly why they'll get suggested. Deferring them keeps the rollout boring.",
          "preview": null
        }
      ]
    },
    {
      "question": "Sticky sessions at the load balancer — how should the doc treat them?",
      "header": "Stickiness",
      "multiSelect": false,
      "options": [
        {
          "label": "Rejected on principle, and not an emergency fallback either (Recommended)",
          "description": "Strongest statement: if we ever need stickiness after this ships, that's a bug in the store, not a lever to pull. Costs us an escape hatch on a bad day.",
          "preview": null
        },
        {
          "label": "Rejected as the solution, but kept as a documented emergency lever",
          "description": "Gives ops something to do at 3am. Risk: the lever gets pulled, the incident goes quiet, and the real bug is never found.",
          "preview": null
        },
        {
          "label": "Keep stickiness on as belt-and-braces alongside Redis",
          "description": "Lowest risk on cutover day. But it hides whether the shared store actually works, so we'd never learn the truth.",
          "preview": null
        }
      ]
    },
    {
      "question": "Encrypting the session payload at rest in Redis?",
      "header": "Encryption",
      "multiSelect": false,
      "options": [
        {
          "label": "Out of scope for v1, with a written revisit trigger (Recommended)",
          "description": "Keeps the payload plain so the 5ms budget and debuggability stay easy, and names the condition that would change our mind rather than leaving it to memory.",
          "preview": null
        },
        {
          "label": "In scope now — encrypt from day one",
          "description": "Never have to migrate ciphertext in later. Costs CPU on every lookup against a 5ms budget, plus key management we don't have yet.",
          "preview": null
        },
        {
          "label": "Leave it genuinely undecided in the doc",
          "description": "Honest, but an undecided item in a design doc tends to get resolved by whoever implements it first, silently.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Out of scope:** all four — `Changing what a session contains`, `Going stateless (JWT / signed cookies, no server-side session)`, `Redis HA, failover, or clustering design`, `New session features (log out all devices, session listing, idle warnings)`
- **Stickiness:** `Rejected on principle, and not an emergency fallback either (Recommended)`
  - _Other (added):_ "Stickiness just moves the problem. It doesn't survive a node dying, it wrecks rolling deploys, and it means we never find out whether the store actually works. I'd rather take the outage and know."
- **Encryption:** `Out of scope for v1, with a written revisit trigger (Recommended)`
  - _Other (added):_ "I'm honestly undecided rather than opposed — put it out of scope so it doesn't block the rollout, but flag it as an open question, not a settled no. Trigger's something like: session payload starts carrying anything beyond id/roles/flag bucket, or Redis stops being a box we own."

---

## Hand-back — after Non-Goals

```json
{
  "questions": [
    {
      "question": "Non-Goals is written. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Desired Behavior (Recommended)",
          "description": "Observable behaviour only — what a request sees on hit, miss, expiry, concurrent writes across two nodes, and during the rollout window. No implementation yet.",
          "preview": null
        },
        {
          "label": "Revise Non-Goals",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Sharpen the encryption revisit trigger",
          "description": "'Redis stops being a box we own' is the vaguest line in the chapter. Worth ten seconds now — it's the sentence that has to survive without you in the room.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Desired Behavior (Recommended)`

---

## Round 4 — Desired Behavior

_(Not asking what the rollout looks like to a user — Goal 2 already settled that: they notice nothing. The mechanism belongs in Design.)_

```json
{
  "questions": [
    {
      "question": "The 30-minute idle TTL. What counts as activity that pushes it back?",
      "header": "Idle TTL",
      "multiSelect": false,
      "options": [
        {
          "label": "Every successful session read pushes the expiry to now + 30min (Recommended)",
          "description": "Matches what an idle timeout means to a user: browsing keeps you signed in. Means a read is no longer a pure read — every request touches the store's expiry.",
          "preview": null
        },
        {
          "label": "Only writes push it back; reads don't",
          "description": "Reads stay pure and cheap. But a user reading pages for 31 minutes gets logged out mid-session, which is a behaviour change from today.",
          "preview": null
        },
        {
          "label": "Absolute 30-minute lifetime, no sliding at all",
          "description": "Simplest to reason about and to test. Significant behaviour change — everyone is logged out every 30 minutes regardless of activity.",
          "preview": null
        }
      ]
    },
    {
      "question": "Two nodes update the same session at the same time — say a role change lands while a feature-flag bucket is being written. What should the observable outcome be?",
      "header": "Concurrency",
      "multiSelect": false,
      "options": [
        {
          "label": "Last write wins on the whole record (Recommended)",
          "description": "One of the two updates is lost. Acceptable because the payload is small and changes rarely — but the doc has to say so out loud, or someone will assume merge semantics.",
          "preview": null
        },
        {
          "label": "Per-field merge, so both updates survive",
          "description": "No lost update. Costs a richer storage shape and read-modify-write coordination on every session mutation, against a 5ms budget.",
          "preview": null
        },
        {
          "label": "Optimistic concurrency — second writer detects the conflict and retries",
          "description": "Correct and explicit, but adds a version check and a retry path to every write for a collision we may never actually see.",
          "preview": null
        }
      ]
    },
    {
      "question": "What must behave exactly as it does today? (The regression surface.)",
      "header": "Unchanged",
      "multiSelect": true,
      "options": [
        {
          "label": "Session cookie name, format, and flags",
          "description": "Anything here changes and every already-signed-in user is logged out on deploy — the exact thing Goal 2 forbids.",
          "preview": null
        },
        {
          "label": "Session id format and how ids are generated",
          "description": "Keeps existing ids valid as Redis keys, so in-flight sessions carry over without translation.",
          "preview": null
        },
        {
          "label": "Explicit sign-out kills the session immediately, everywhere",
          "description": "Today it's one `Map.delete` on one node. With 3 nodes it has to be visible to all of them on the very next request.",
          "preview": null
        },
        {
          "label": "An unknown or expired session id is treated as signed-out, not as an error",
          "description": "Preserves today's 401-and-redirect. Note this is distinct from the Redis-unreachable case, which fails loudly instead.",
          "preview": null
        }
      ]
    },
    {
      "question": "How do you want this chapter written?",
      "header": "Format",
      "multiSelect": false,
      "options": [
        {
          "label": "Given / When / Then scenarios (Recommended)",
          "description": "Hands the Testing Strategy chapter its cases for free — each scenario becomes a test name. Slightly more verbose to read.",
          "preview": "**Read on a different node**\n- Given a session created on node A\n- When a request carrying it is served by node B\n- Then the user is signed in, with the same roles and flag bucket"
        },
        {
          "label": "Plain behaviour bullets",
          "description": "Faster to scan in review. Testing Strategy then has to re-derive the cases from prose.",
          "preview": "- A session created on any node is readable from every node\n- Reading a session pushes its expiry to now + 30 minutes\n- Explicit sign-out removes it from all nodes immediately"
        }
      ]
    }
  ]
}
```

**Answer:**
- **Idle TTL:** `Every successful session read pushes the expiry to now + 30min (Recommended)`
  - _Other (added):_ "Same as today, and I want that expiry handled by key expiry in the store rather than us running a sweeper. How we avoid paying two round trips for read-then-extend is a design problem — park it."
- **Concurrency:** `Last write wins on the whole record (Recommended)`
  - _Other (added):_ "Roles change maybe once a quarter per user. Not building merge machinery for a collision I've never seen. But write it down so nobody assumes otherwise."
- **Unchanged:** all four — `Session cookie name, format, and flags`, `Session id format and how ids are generated`, `Explicit sign-out kills the session immediately, everywhere`, `An unknown or expired session id is treated as signed-out, not as an error`
- **Format:** `Given / When / Then scenarios (Recommended)`

---

## Hand-back — after Desired Behavior

```json
{
  "questions": [
    {
      "question": "Desired Behavior is written, with the read-then-extend round-trip parked for Design. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Design & Implementation Details (Recommended)",
          "description": "The interface and its two implementations, key shape and TTL handling, the cutover plan that keeps people signed in, and the parked round-trip question.",
          "preview": null
        },
        {
          "label": "Revise Desired Behavior",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Add a scenario for the mid-rollout mixed fleet",
          "description": "Right now 'during the rollout' covers before and after, but not the window where some nodes are old and some are new and the same user bounces between them. That's where this usually goes wrong.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Add a scenario for the mid-rollout mixed fleet`
- _Other (added):_ "Yes — that's the actual risk. Rolling deploy means for a few minutes there'll be old nodes reading their own Map and new nodes reading Redis, and the LB won't care which one you land on. I don't want to discover that on the day."

---

## Round 5 — Desired Behavior (mixed-fleet follow-up)

```json
{
  "questions": [
    {
      "question": "During the rolling deploy, an old node (its own Map) and a new node (shared store) are both serving, and the LB doesn't care which one you get. What's the required behaviour in that window?",
      "header": "Mixed fleet",
      "multiSelect": false,
      "options": [
        {
          "label": "Every user stays signed in throughout, no exceptions (Recommended)",
          "description": "Holds Goal 2 even at the worst moment. Costs an extra intermediate release that understands both stores — two deploys instead of one.",
          "preview": "Deploy 1: writes both, reads Map → then shared store\nDeploy 2: shared store only\n\nUser hits either node, either deploy → signed in"
        },
        {
          "label": "Stay signed in on new nodes; old-node sessions are best-effort",
          "description": "One deploy, much less code. But a user who bounces old → new gets logged out, and the window is exactly when traffic is being shuffled most.",
          "preview": "Deploy 1: shared store only\n\nOld node → own Map (works)\nNew node → shared store (miss → signed out)"
        },
        {
          "label": "Accept re-login for sessions created shortly before the deploy",
          "description": "Bounded blast radius and simple to explain. Still a visible sign-out for real users, which Goal 2 ranked above everything except correctness.",
          "preview": null
        }
      ]
    },
    {
      "question": "And if we roll back mid-deploy — sessions created on a new node only exist in the shared store. What happens to those users?",
      "header": "Rollback",
      "multiSelect": false,
      "options": [
        {
          "label": "They stay signed in, because the release we roll back to can already read the shared store (Recommended)",
          "description": "Falls out of the two-deploy plan for free: the intermediate release reads both, so it's a safe place to land. Means deploy 2 can only ship once deploy 1 is everywhere.",
          "preview": null
        },
        {
          "label": "They get logged out on rollback; accepted as rare",
          "description": "No ordering constraint between deploys. But rollback is exactly when we can least afford a second incident on top of the first.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Mixed fleet:** `Every user stays signed in throughout, no exceptions (Recommended)`
- **Rollback:** `They stay signed in, because the release we roll back to can already read the shared store (Recommended)`
  - _Other (added):_ "Right — and that means deploy 2 doesn't go out until deploy 1 is on every node. That ordering is a rule, not a suggestion; put it in the doc where someone will actually read it."

---

## Hand-back — after Desired Behavior (revised)

```json
{
  "questions": [
    {
      "question": "Mixed-fleet and rollback scenarios are in, with the deploy-ordering rule. Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Design & Implementation Details (Recommended)",
          "description": "The store interface and its two implementations, key shape and how TTL is handled, the two-deploy cutover, and the parked read-then-extend round-trip question.",
          "preview": null
        },
        {
          "label": "Revise Desired Behavior",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Nail down what 'immediately' means for sign-out",
          "description": "The doc says sign-out is visible on the very next request. Worth confirming that's literal — it rules out any read-through caching of sessions on the node.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Design & Implementation Details (Recommended)`
- _Other (added):_ "It's literal, and yes, that rules out a local cache in front of the store. Don't let anyone add one — that's how you get a signed-out user still holding a valid session for 10 seconds. Note it in Design."

---

## Round 6 — Design & Implementation Details (interface & mechanics)

```json
{
  "questions": [
    {
      "question": "The interface both implementations sit behind. Which shape? (Signatures in TypeScript — say if the repo is plain JS and I'll drop the types.)",
      "header": "Interface",
      "multiSelect": false,
      "options": [
        {
          "label": "TTL owned by the store, invisible to callers (Recommended)",
          "description": "Callers can't get the idle timeout wrong because they never touch it, and 'read extends expiry' is enforced in one place. Cost: the TTL becomes store construction config, not a per-call decision.",
          "preview": "interface SessionStore {\n  get(id: string): Promise<Session | undefined>;\n  set(id: string, session: Session): Promise<void>;\n  delete(id: string): Promise<void>;\n}\n\n// sliding TTL is the store's job:\n// every successful get() extends expiry"
        },
        {
          "label": "TTL passed explicitly on every write",
          "description": "Flexible — different session kinds could have different lifetimes later. But every call site now has to know the policy, and one that forgets creates a session that never expires.",
          "preview": "interface SessionStore {\n  get(id: string): Promise<Session | undefined>;\n  set(id: string, s: Session, ttlMs: number): Promise<void>;\n  touch(id: string, ttlMs: number): Promise<void>;\n  delete(id: string): Promise<void>;\n}"
        },
        {
          "label": "Map-shaped, to match what's there today",
          "description": "Smallest diff at the call sites — it looks like the Map it replaces. But a synchronous-looking API over a network hop is a trap, and there's nowhere to express expiry.",
          "preview": "interface SessionStore {\n  get(id: string): Promise<Session | undefined>;\n  has(id: string): Promise<boolean>;\n  set(id: string, s: Session): Promise<void>;\n  delete(id: string): Promise<void>;\n}"
        }
      ]
    },
    {
      "question": "Read-and-extend was parked in the last chapter. How does a session read extend the TTL?",
      "header": "TTL mechanics",
      "multiSelect": false,
      "options": [
        {
          "label": "GETEX — one round trip, value and expiry together (Recommended)",
          "description": "Keeps the 5ms budget honest: one RTT per request, no sweeper, expiry is Redis's job. Requires Redis 6.2+, and it only works on string values — which constrains the serialization choice below.",
          "preview": "GETEX session:<id> PX 1800000\n\n→ returns the value AND pushes expiry\n   to now + 30min, atomically, in 1 RTT"
        },
        {
          "label": "GET then PEXPIRE, pipelined",
          "description": "Works on any Redis and on hashes too. Still one network round trip when pipelined, but two commands, and they aren't atomic with respect to a concurrent delete.",
          "preview": "PIPELINE\n  GET     session:<id>\n  PEXPIRE session:<id> 1800000\nEXEC"
        },
        {
          "label": "GET only; refresh expiry on writes",
          "description": "Cheapest read path. But it changes the idle-timeout behaviour the last chapter just pinned down, so it's off the table unless we revisit that.",
          "preview": null
        }
      ]
    },
    {
      "question": "How is a session stored?",
      "header": "Storage shape",
      "multiSelect": false,
      "options": [
        {
          "label": "One key per session, JSON string value (Recommended)",
          "description": "Works with GETEX, which hashes don't. Payload is ~100 bytes, so JSON parse cost is noise against a 5ms budget, and you can read a session with redis-cli when debugging.",
          "preview": "key:   session:<sessionId>\nvalue: {\"userId\":\"u_123\",\"roles\":[\"admin\"],\"flagBucket\":\"b7\"}\nttl:   1800000ms, sliding"
        },
        {
          "label": "Redis hash, one field per attribute",
          "description": "Lets a single field be updated without a read-modify-write. Rules out GETEX, and we already decided last-write-wins makes per-field updates unnecessary.",
          "preview": "HSET session:<id> userId u_123 roles admin flagBucket b7"
        },
        {
          "label": "JSON string, but MessagePack-encoded",
          "description": "Smaller and marginally faster to decode. Buys almost nothing at ~100 bytes and makes the data opaque to redis-cli, which hurts on the day it matters.",
          "preview": null
        }
      ]
    },
    {
      "question": "How does the app decide which implementation it's running?",
      "header": "Wiring",
      "multiSelect": false,
      "options": [
        {
          "label": "Explicit env var, memory default, but fail fast if production asks for memory (Recommended)",
          "description": "Dev and CI get an in-memory store with zero setup, and a misconfigured production box refuses to boot instead of quietly running 3 nodes with 3 private session tables.",
          "preview": "SESSION_STORE=memory | redis   (default: memory)\n\nif (NODE_ENV === 'production' && store === 'memory')\n  throw new Error('refusing to boot: SESSION_STORE=memory in production')"
        },
        {
          "label": "Infer from whether REDIS_URL is set",
          "description": "One less variable to set. But the failure mode is silent — unset the URL in prod by accident and you get in-memory sessions with no warning at all.",
          "preview": "const store = process.env.REDIS_URL\n  ? new RedisSessionStore(...)\n  : new InMemorySessionStore()"
        },
        {
          "label": "Always Redis; dev and CI run it in a container",
          "description": "One code path everywhere, no implementation to keep honest. Directly contradicts Goal 4.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Interface:** `TTL owned by the store, invisible to callers (Recommended)`
  - _Other (added):_ "TS is right. And keep it to those three methods — the smaller that interface is, the less painful the in-memory one is to keep honest."
- **TTL mechanics:** `GETEX — one round trip, value and expiry together (Recommended)`
  - _Other (added):_ "That's exactly what I wanted — expiry is Redis's problem, not a cron job of ours. We're on 7.x so 6.2 isn't a constraint."
- **Storage shape:** `One key per session, JSON string value (Recommended)`
- **Wiring:** `Explicit env var, memory default, but fail fast if production asks for memory (Recommended)`
  - _Other (added):_ "The fail-fast is the bit I care about. Silent in-memory in prod is the exact bug this whole doc exists to prevent — I'd rather the box refuse to start."

---

## Round 7 — Design & Implementation Details (cutover, client, layout)

_Before writing the cutover plan I want to check an assumption underneath it: sessions in a `Map` die with the process, so the first deploy carrying any Redis code necessarily loses whatever is in memory at that moment. No amount of dual-writing changes that, because the dual-writing code isn't running until after the restart. If that's right, the two-deploy plan from Round 5 is solving a problem that doesn't exist yet._

```json
{
  "questions": [
    {
      "question": "How does a deploy work today, and what happens to live sessions?",
      "header": "Deploys today",
      "multiSelect": false,
      "options": [
        {
          "label": "One node, restarted in place — every deploy already logs everyone out",
          "description": "If so, the migration's first deploy costs exactly what a normal deploy costs today, and the plan gets much simpler. It also means this work quietly fixes deploy-time logouts as a side effect.",
          "preview": null
        },
        {
          "label": "Rolling or blue-green with an overlap window",
          "description": "Then there's already a mixed-fleet window on every deploy, and the intermediate dual-capable release genuinely earns its place.",
          "preview": null
        },
        {
          "label": "Deploys happen in a maintenance window, so it's never come up",
          "description": "Gives us a free window for the cutover, but means there's no existing tolerance for logouts to lean on.",
          "preview": null
        }
      ]
    },
    {
      "question": "Given that, what's the cutover plan?",
      "header": "Cutover",
      "multiSelect": false,
      "options": [
        {
          "label": "One deploy, low-traffic window, and it's the last logout ever (Recommended)",
          "description": "Honest about the one unavoidable cost and buys no machinery to pretend otherwise. Scale-out to 3 nodes happens after, once a restart has been shown to preserve sessions.",
          "preview": "1. Deploy the Redis store (low-traffic window)\n   → live sessions lost, same as any deploy today\n2. Verify: restart the node, stay signed in\n3. Add nodes 2 and 3, no stickiness on the LB\n\nEvery deploy after step 1 preserves sessions."
        },
        {
          "label": "Two deploys with a dual-write intermediate release",
          "description": "Looks safer, but I don't think it is: the Map still dies at deploy 1's restart, so it costs the same logout AND an extra release to write, test and later delete. Pick this only if deploys already overlap.",
          "preview": "Deploy 1: write Map + Redis, read Map → Redis\n           (Map still empty after restart!)\nDeploy 2: Redis only"
        },
        {
          "label": "Pre-seed Redis from the Map via a temporary admin endpoint",
          "description": "Same trap one step removed — the deploy that adds the endpoint is itself a restart, so it just moves the logout earlier and leaves throwaway code behind.",
          "preview": null
        }
      ]
    },
    {
      "question": "Redis is already in the stack for the rate limiter. How do sessions connect?",
      "header": "Connection",
      "multiSelect": false,
      "options": [
        {
          "label": "Same server and client library, its own connection and key prefix (Recommended)",
          "description": "No new operational surface, and a slow rate-limiter command can't queue ahead of a session read on a shared connection — which is what protects the 5ms p99.",
          "preview": "session:<id>      ← this doc\nratelimit:<key>   ← existing\n\nsame Redis, separate client instance"
        },
        {
          "label": "Reuse the rate limiter's existing connection",
          "description": "Fewer sockets and one less thing to configure. But the two now share a command queue, so session latency inherits rate-limiter behaviour under load.",
          "preview": null
        },
        {
          "label": "A separate Redis instance for sessions",
          "description": "Full isolation, including blast radius. But it's a new thing to run, monitor and pay for, and the Non-Goals chapter put Redis topology out of scope.",
          "preview": null
        }
      ]
    },
    {
      "question": "Where does the code live?",
      "header": "Layout",
      "multiSelect": false,
      "options": [
        {
          "label": "A session module with the interface and both implementations side by side (Recommended)",
          "description": "The two implementations sit next to each other, so a contract test over both is the obvious thing to write and drift is visible in review.",
          "preview": "src/session/\n├── session-store.ts          # interface + Session type\n├── in-memory-session-store.ts\n├── redis-session-store.ts\n├── create-session-store.ts   # env → impl, prod guard\n└── session-store.test.ts     # contract, both impls"
        },
        {
          "label": "Redis implementation under an infrastructure folder, interface with the domain",
          "description": "Cleaner layering if the codebase already separates that way. Costs the side-by-side contract test its obvious home.",
          "preview": "src/session/session-store.ts\nsrc/session/in-memory-session-store.ts\nsrc/infra/redis/redis-session-store.ts"
        },
        {
          "label": "A Fastify plugin that owns everything",
          "description": "Matches Fastify idiom and gets you `request.session` for free. But it welds the store to the framework, which makes testing it in isolation harder.",
          "preview": "src/plugins/session.ts   # decorator + store + wiring"
        }
      ]
    }
  ]
}
```

**Answer:**
- **Deploys today:** `One node, restarted in place — every deploy already logs everyone out`
  - _Other (added):_ "Correct, and good catch — I'd have let that two-deploy plan through. Yes, every deploy today drops every session. People grumble about it. So one more time is tolerable, but it has to be the last time, and I want that written down so nobody reads the first deploy as a regression."
- **Cutover:** `One deploy, low-traffic window, and it's the last logout ever (Recommended)`
- **Connection:** `Same server and client library, its own connection and key prefix (Recommended)`
- **Layout:** `A session module with the interface and both implementations side by side (Recommended)`
  - _Other (added):_ "Wrap it in a small Fastify plugin at the edge for `request.session`, but the store itself stays framework-free — I want to be able to test it without standing up a server."

---

## Hand-back — after Design & Implementation Details

_Also went back and corrected the mixed-fleet and rollback scenarios in Desired Behavior — the two-deploy ordering rule from Round 5 was wrong once we established the `Map` dies with the process._

```json
{
  "questions": [
    {
      "question": "Design is written, with two TODOs left in it (the low-traffic window, and whether a latency histogram already exists). Where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Testing Strategy (Recommended)",
          "description": "Which of the Desired Behavior scenarios become tests, at which level, what's real vs faked, and how to test a 30-minute sliding TTL without a 30-minute test.",
          "preview": null
        },
        {
          "label": "Revise Design & Implementation Details",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Resolve the latency-histogram TODO now",
          "description": "It's the one TODO that could quietly expand scope — if no histogram exists, building one is part of this work and Goals already committed to it as the success signal.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Testing Strategy (Recommended)`
- _Other (added):_ "Leave the histogram TODO in. We have p99s per route, but not per store call, so it probably is extra work — I want that visible in the doc rather than quietly resolved by me in a chat message."

---

## Round 8 — Testing Strategy

```json
{
  "questions": [
    {
      "question": "Which Desired Behavior scenarios become tests, and at which level?",
      "header": "Coverage",
      "multiSelect": true,
      "options": [
        {
          "label": "The whole store contract, run against BOTH implementations",
          "description": "Read/write, cross-instance visibility, delete-is-immediate, miss-is-undefined, sliding expiry. Catches in-memory drifting from Redis, which is the failure mode Goal 4 creates.",
          "preview": null
        },
        {
          "label": "Redis unreachable → 5xx, never 401",
          "description": "The one behaviour where a bug looks like success. Needs the container stopped mid-test, so it's the slowest test here and worth it anyway.",
          "preview": null
        },
        {
          "label": "The production guard refuses to boot on SESSION_STORE=memory",
          "description": "Cheap boot-level test of the thing that protects against silently running 3 private session tables.",
          "preview": null
        },
        {
          "label": "One end-to-end route test: sign in, read session, sign out",
          "description": "Proves the Fastify plugin actually wires the store to `request.session`. One test, not a suite — the contract suite already covers the store.",
          "preview": null
        }
      ]
    },
    {
      "question": "What's real in the tests, and where's the seam?",
      "header": "Seam",
      "multiSelect": false,
      "options": [
        {
          "label": "Contract suite runs twice — in-memory, and real Redis via testcontainers (Recommended)",
          "description": "Same assertions both times, so drift is impossible to miss. Nothing mocks the Redis client, so the tests break when Redis behaves differently, which is the point.",
          "preview": "session-store.test.ts\n  └─ describe.each([\n       ['in-memory', makeInMemory],\n       ['redis',     makeRedisWithTestcontainer],\n     ])\n\nroute tests → in-memory store (no container)"
        },
        {
          "label": "Mock the Redis client and assert on commands sent",
          "description": "Fast and needs no Docker. But it tests our idea of Redis rather than Redis, and it would happily pass with GETEX used wrongly.",
          "preview": null
        },
        {
          "label": "Real Redis everywhere, including route tests",
          "description": "Maximum realism. Makes a container mandatory for the whole suite, which is Goal 4 lost.",
          "preview": null
        }
      ]
    },
    {
      "question": "How do we test a 30-minute sliding TTL without a 30-minute test?",
      "header": "TTL tests",
      "multiSelect": false,
      "options": [
        {
          "label": "Construct the store with a tiny TTL and let it really expire (Recommended)",
          "description": "Works identically for both implementations and actually exercises Redis key expiry — the mechanism we chose over a sweeper. Costs a sub-second real wait per expiry test.",
          "preview": "const store = makeStore({ ttlMs: 150 });\n\nawait store.set(id, session);\nawait sleep(60);\nawait store.get(id);        // extends\nawait sleep(120);\nassert.ok(await store.get(id));   // still alive\nawait sleep(200);\nassert.equal(await store.get(id), undefined);"
        },
        {
          "label": "Assert on PTTL instead of waiting",
          "description": "Instant and stable. But it asserts on a Redis command rather than behaviour, can't run against the in-memory implementation, and would pass even if expiry never fired.",
          "preview": null
        },
        {
          "label": "Inject a fake clock",
          "description": "Standard move, and it works fine for in-memory — but Redis expires keys on its own clock, so the Redis half of the contract suite can't use it. Two different TTL tests, which defeats a shared contract.",
          "preview": null
        }
      ]
    },
    {
      "question": "What would make these tests brittle? (I'll write these in as things to avoid.)",
      "header": "Brittleness",
      "multiSelect": true,
      "options": [
        {
          "label": "Asserting on key names or Redis commands",
          "description": "Turns the key prefix into a frozen public API. Assert through the interface instead.",
          "preview": null
        },
        {
          "label": "Tests sharing one Redis database without isolation",
          "description": "Leftover keys make failures order-dependent and unreproducible alone.",
          "preview": null
        },
        {
          "label": "A container per test file",
          "description": "Turns a 5-second suite into a 90-second one and makes people skip it locally — the surest way to lose the coverage entirely.",
          "preview": null
        },
        {
          "label": "Fixed sleeps used as general synchronisation",
          "description": "Fine for expiry, where waiting IS the behaviour. Anywhere else it's a flake generator.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Coverage:** all four — `The whole store contract, run against BOTH implementations`, `Redis unreachable → 5xx, never 401`, `The production guard refuses to boot on SESSION_STORE=memory`, `One end-to-end route test: sign in, read session, sign out`
- **Seam:** `Contract suite runs twice — in-memory, and real Redis via testcontainers (Recommended)`
  - _Other (added):_ "node:test, and testcontainers for the Redis half — that's what we do for anything touching a real backing service. No mocked clients, ever; I've been burned by a mock that passed while the real thing didn't."
- **TTL tests:** `Construct the store with a tiny TTL and let it really expire (Recommended)`
  - _Other (added):_ "Good — the TTL being construction config rather than a call argument is what makes this possible. Nice side effect of the interface choice."
- **Brittleness:** all four
- _Unprompted:_ "Write the contract suite first, against the in-memory implementation, and get it green. Then point it at Redis and make that pass. If the Redis implementation needs the suite changed to go green, the interface was wrong and I want to find that out on day one, not after it's wired into routes."

---

## Hand-back — after Testing Strategy

```json
{
  "questions": [
    {
      "question": "Testing Strategy is written, including your test-first rule for the contract suite. Last chapter — where next?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Alternatives Considered (Recommended)",
          "description": "Mostly harvesting — every option you didn't pick in the last five chapters is already an alternative, so this is you confirming, correcting, and adding the ones you'd rejected before we started.",
          "preview": null
        },
        {
          "label": "Revise Testing Strategy",
          "description": "I'll ask what's off and rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Decide whether the contract suite runs Redis in CI or only locally",
          "description": "Goal 4 says CI must run without Redis. But the Redis half of the contract suite is exactly the part worth running in CI — those two pull against each other and the doc doesn't say which wins.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Decide whether the contract suite runs Redis in CI or only locally`
- _Other (added):_ "You're right, that's a real contradiction and I'd rather not leave it. Quick version: Goal 4 is about `npm test` on a laptop and the default CI job not needing a Redis service — not about never running a container anywhere. Testcontainers spins up Docker on demand; CI has Docker. So it runs everywhere, and what I actually need is that nothing requires a *pre-provisioned* Redis, and that the suite degrades gracefully with a clear skip if Docker is absent. Fix the wording."

---

## Round 9 — Testing Strategy (CI clarification)

```json
{
  "questions": [
    {
      "question": "What happens when the Redis half of the contract suite runs somewhere without Docker?",
      "header": "No Docker",
      "multiSelect": false,
      "options": [
        {
          "label": "Skip it loudly, with a message naming what was skipped and why (Recommended)",
          "description": "Laptop without Docker still gets a green in-memory run and knows it's partial. Risk: a CI job silently loses Redis coverage — so CI asserts it did NOT skip.",
          "preview": "ok 12 - redis contract # SKIP Docker unavailable\n\nCI: fail the job if the redis suite skipped"
        },
        {
          "label": "Fail the suite",
          "description": "Impossible to lose coverage by accident. But `npm test` on a fresh laptop now needs Docker, which is Goal 4 by another name.",
          "preview": null
        },
        {
          "label": "Skip it silently",
          "description": "Frictionless, and that's the problem — a broken Redis implementation ships green and nobody sees a thing.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Skip it loudly, with a message naming what was skipped and why (Recommended)`
- _Other (added):_ "And the CI assertion is not optional. A skip that nobody notices is worse than no test at all, because it looks like coverage."

---

## Hand-back — after Testing Strategy (revised)

```json
{
  "questions": [
    {
      "question": "CI policy is in. Ready for the last chapter?",
      "header": "Next",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Alternatives Considered (Recommended)",
          "description": "Harvesting the options you turned down across the last five chapters, plus revisit triggers.",
          "preview": null
        },
        {
          "label": "Revise Testing Strategy again",
          "description": "I'll ask what's still off.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Continue to Alternatives Considered (Recommended)`

---

## Round 10 — Alternatives Considered

_Harvest, not interrogation: everything below is an option already turned down somewhere in this conversation._

```json
{
  "questions": [
    {
      "question": "Which of these forks are worth a written entry? (Rule of thumb: would someone re-propose it in review?)",
      "header": "Which forks",
      "multiSelect": true,
      "options": [
        {
          "label": "Sticky sessions at the LB, and stateless JWT sessions",
          "description": "The two that delete the problem instead of solving it. Both will absolutely come up in review — these are the entries that earn the chapter its keep.",
          "preview": null
        },
        {
          "label": "The two-deploy dual-write cutover, and pre-seeding Redis via an admin endpoint",
          "description": "Both look safer than the plan we chose. Writing down WHY they don't work is what stops someone 'improving' the cutover the week before it happens.",
          "preview": null
        },
        {
          "label": "Falling back to in-memory when Redis is down",
          "description": "The most dangerous rejected option, because under incident pressure it looks like the obvious mitigation.",
          "preview": null
        },
        {
          "label": "The storage and TTL micro-forks (Redis hash, GET+PEXPIRE, MessagePack, a sweeper, a node-local cache)",
          "description": "Design already records the reasoning inline. Repeating them here mostly adds length — though the cache and the sweeper are the two people actually reach for.",
          "preview": null
        }
      ]
    },
    {
      "question": "Anything you'd already rejected before this conversation started?",
      "header": "Prior art",
      "multiSelect": false,
      "options": [
        {
          "label": "Sessions in the primary Postgres database",
          "description": "The default answer at most shops, and it means every authenticated request adds a query to the primary. Worth recording if you looked at it.",
          "preview": null
        },
        {
          "label": "Memcached instead of Redis",
          "description": "Fine at this shape of problem, but a second piece of infrastructure when Redis is already there.",
          "preview": null
        },
        {
          "label": "A dedicated session service",
          "description": "Clean boundary, enormous cost for 5k sessions and a 100-byte payload.",
          "preview": null
        },
        {
          "label": "Nothing — this conversation is the whole search",
          "description": "Fine too. Then the chapter is purely the harvest above.",
          "preview": null
        }
      ]
    },
    {
      "question": "Which entries need an explicit 'revisit if…' line? That's the line that keeps this doc useful a year from now.",
      "header": "Revisit",
      "multiSelect": true,
      "options": [
        {
          "label": "Stateless JWT sessions",
          "description": "e.g. if session reads ever become a Redis bottleneck, or the payload stops needing mid-session mutability.",
          "preview": null
        },
        {
          "label": "Keeping the in-memory implementation",
          "description": "e.g. if it drifts from Redis often enough that the contract suite stops catching it.",
          "preview": null
        },
        {
          "label": "Sharing one Redis with the rate limiter",
          "description": "e.g. if rate-limiter load ever shows up in session p99.",
          "preview": null
        },
        {
          "label": "Last-write-wins on concurrent updates",
          "description": "e.g. if a lost role update ever actually reaches a user.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Which forks:** `Sticky sessions at the LB, and stateless JWT sessions`, `The two-deploy dual-write cutover, and pre-seeding Redis via an admin endpoint`, `Falling back to in-memory when Redis is down`
  - _Other (added):_ "Skip the micro-forks except the sweeper and the node-local cache — those two are what people reach for, so they get a line. Nobody is going to re-propose MessagePack."
- **Prior art:** `Sessions in the primary Postgres database`
  - _Other (added):_ "Looked at it for about ten minutes. Every authenticated request becomes a query against the primary, and 5ms p99 would be luck rather than design. Redis was already sitting there for the rate limiter, so it was never a close call."
- **Revisit:** all four

---

## Hand-back — doc complete

All six chapters are written: `design-docs/redis-session-store.md`

```json
{
  "questions": [
    {
      "question": "The doc's done. What now?",
      "header": "Done",
      "multiSelect": false,
      "options": [
        {
          "label": "Consistency read-through, top to bottom (Recommended)",
          "description": "Checks that the Goals still match the design they produced — the usual finding after a chapter gets revised mid-flight, and two did here.",
          "preview": null
        },
        {
          "label": "Start implementing against the doc",
          "description": "Contract suite first against the in-memory store, per your test-first rule.",
          "preview": null
        },
        {
          "label": "Leave it here",
          "description": "The doc stands on its own; the two TODOs are visible.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Consistency read-through, top to bottom (Recommended)`
- _Other (added):_ "Two chapters got rewritten while we were mid-flight, so yes — check the seams before anyone else reads this."

---

## Round 11 — Consistency read-through

_Four seams found, all in Goals, all pointing the same way: Goals was written before we learned that a `Map` dies with the process and that testcontainers starts Redis on demand. Every one of these is a Goals edit, so they're yours to approve, not mine to quietly apply._

```json
{
  "questions": [
    {
      "question": "Goal 2 says 'nobody is logged out by the rollout itself — no mass session invalidation.' The cutover in Design accepts exactly one mass logout, at the first deploy. Straight contradiction. Which way?",
      "header": "Goal 2",
      "multiSelect": false,
      "options": [
        {
          "label": "Amend Goal 2 to carve out the cutover deploy explicitly (Recommended)",
          "description": "Records what we actually decided and why it's acceptable, so a reader can't find the contradiction before we do. Cost: the goal reads slightly weaker.",
          "preview": "2. Nobody is logged out by the rollout itself — with one\n   named exception: the cutover deploy, which costs exactly\n   what every deploy costs today. It is the last one that\n   ever does. Every deploy and scale-out after it preserves\n   sessions."
        },
        {
          "label": "Leave Goal 2 absolute and treat the cutover as a known violation",
          "description": "Keeps the goal aspirational and honest about falling short. But an unexplained contradiction between chapters is what gets a doc sent back in review.",
          "preview": null
        }
      ]
    },
    {
      "question": "Three smaller drifts, same cause. Fix them?",
      "header": "Drifts",
      "multiSelect": true,
      "options": [
        {
          "label": "Success signal: 're-login rate doesn't move during or after the rollout'",
          "description": "It will move, once, at the cutover deploy. Should read 'after the cutover deploy' or it's an alert that fires on the expected outcome.",
          "preview": null
        },
        {
          "label": "Goal 3: 'p99 stays under 5ms in the API's existing metrics'",
          "description": "Design's TODO says no per-store-call histogram exists — you said so yourself. Goals currently assumes the instrument it needs.",
          "preview": null
        },
        {
          "label": "Goal 4: 'with no Redis process running'",
          "description": "Testing now says the Redis contract suite runs everywhere via testcontainers, which does start Redis. Your own correction — 'no pre-provisioned Redis' — is the accurate wording.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- **Goal 2:** `Amend Goal 2 to carve out the cutover deploy explicitly (Recommended)`
  - _Other (added):_ "Amend it. An absolute goal we knowingly break on day one is worse than a precise one — and 'it's the last time' is the part that actually makes it acceptable. That sentence needs to be in Goals, not buried in the cutover section."
- **Drifts:** all three

---

## Hand-back — after consistency pass

```json
{
  "questions": [
    {
      "question": "All four seams fixed in Goals. The doc is internally consistent now. Anything else?",
      "header": "Done",
      "multiSelect": false,
      "options": [
        {
          "label": "Leave it here — it's ready to share (Recommended)",
          "description": "Six chapters, two open TODOs clearly marked (low-traffic window, per-store-call histogram), and one open question flagged as open rather than decided (encryption at rest).",
          "preview": null
        },
        {
          "label": "Start implementing against the doc",
          "description": "Contract suite first, against the in-memory store, per your test-first rule.",
          "preview": null
        },
        {
          "label": "Flip the status line from Draft to Ready for review",
          "description": "Only if you want the two TODOs resolved first — they're the kind reviewers stop on.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** `Leave it here — it's ready to share (Recommended)`
- _Other (added):_ "Status stays Draft until I've picked the window and checked the histogram. Don't start implementing — I want two other people to read this first, and the whole point of doing it this way was to find the disagreements before there's code to argue about."
