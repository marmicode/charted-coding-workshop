# Interview log

## Q1 — before writing the design doc

Asked one clarifying round before drafting, because the cutover strategy and the
local-dev story change the shape of the whole document.

```json
{
  "questions": [
    {
      "question": "How should the cutover from the in-memory Map to Redis happen?",
      "header": "Cutover",
      "multiSelect": false,
      "options": [
        {
          "label": "Dual-read, Redis-write",
          "description": "Write new/refreshed sessions to Redis, read Redis first and fall back to the local Map, so sessions created before the deploy keep working until they expire.",
          "preview": "get(id):\n  redis.get(id) ?? map.get(id)  // then backfill into redis\nset(id, s):\n  redis.set(id, s, EX 1800)"
        },
        {
          "label": "Hard cutover",
          "description": "Switch the store to Redis in one deploy. Simplest code, but every session living in the old Map is dropped at restart — everyone is logged out.",
          "preview": "get(id): redis.get(id)\nset(id, s): redis.set(id, s, EX 1800)\n// old Map contents are gone on deploy"
        },
        {
          "label": "Sticky sessions instead",
          "description": "Keep the Map and pin each client to one node at the load balancer. No storage change at all.",
          "preview": "LB: hash(cookie) -> node-1|node-2|node-3\n// Map stays per-node"
        }
      ]
    },
    {
      "question": "Does the in-memory implementation need to stay usable after the migration?",
      "header": "Local dev",
      "multiSelect": false,
      "options": [
        {
          "label": "Keep both behind one interface",
          "description": "Ship a SessionStore interface with a Redis implementation and an in-memory one, chosen by config. Local dev and CI can run without Redis."
        },
        {
          "label": "Redis everywhere",
          "description": "Delete the Map implementation. Local dev and CI require a Redis instance (docker compose)."
        }
      ]
    },
    {
      "question": "Should session payloads be encrypted at rest in Redis?",
      "header": "Encryption",
      "multiSelect": false,
      "options": [
        {
          "label": "Plain JSON",
          "description": "Store the payload as JSON. Simplest, fastest, relies on network/ACL controls for confidentiality."
        },
        {
          "label": "Encrypt payload",
          "description": "AES-GCM the value with a key from the app config. Protects against Redis snapshot/dump exposure, adds a key-rotation story."
        }
      ]
    }
  ]
}
```

**Answer:**
- Cutover: **Dual-read, Redis-write** — "absolutely no logout storm, existing sessions have to survive the rollout."
- Local dev: **Keep both behind one interface** — "Redis must not become mandatory for local dev and CI."
- Encryption: `Other: not sure yet — leave it as an open question in the doc with the trade-off spelled out, I'll decide before we ship.`

Additional unprompted context Alex gave while answering: session lookup must stay
under 5ms p99; sticky sessions are a non-starter because "it just moves the
problem"; TTL should be Redis key expiry, not a sweeper; anything touching a real
backing service is tested with `node:test` + testcontainers.

## Q2 — none

No second round. Everything else (key naming, serialization format, metrics,
rollback) was decided with defaults and written up as explicit decisions in the
doc so they can be challenged in review.
