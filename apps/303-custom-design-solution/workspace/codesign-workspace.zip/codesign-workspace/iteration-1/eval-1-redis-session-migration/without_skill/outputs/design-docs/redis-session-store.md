# Redis-backed session store

**Status:** draft
**Author:** Alex
**Date:** 2026-09-24

## 1. Context

Sessions currently live in a plain `Map` in the Fastify process, keyed by session
id, with a 30-minute idle TTL. Steady state is roughly 5k concurrent sessions and
the payload is small — user id, roles, a feature-flag bucket.

We are about to go from one node to three behind a load balancer. A per-process
`Map` is not shared, so a request that lands on a node other than the one that
created the session sees no session at all. With three nodes and round-robin
routing, roughly two thirds of requests would fail to resolve their session.

Redis is already in the stack for the rate limiter, so this is not a new
operational dependency — no new infra to provision, monitor, or get approved.

## 2. Goals

- Session reads and writes are shared across all nodes.
- **No logout storm during rollout.** Sessions that exist when we deploy must
  keep working; users must not be kicked out.
- Session lookup stays under **5ms p99** (measured at the store boundary).
- Redis stays **optional for local dev and CI**. `npm test` and `npm run dev`
  must work on a laptop with no Redis running.
- Idle TTL semantics stay exactly as they are today: 30 minutes of inactivity,
  refreshed on each access.

## 3. Non-goals

- Changing the session payload shape, the cookie, or the auth flow.
- Session revocation/admin "log out everywhere" features. (Redis makes these
  easier later; out of scope here.)
- Redis HA topology changes. We use what the rate limiter already uses.
- Moving the rate limiter or anything else onto this abstraction.

## 4. Constraints and decisions

### 4.1 One interface, two implementations

All session access goes through a single interface. Nothing outside the store
module knows whether the backing store is a `Map` or Redis.

```ts
export interface SessionStore {
  get(id: string): Promise<Session | undefined>;
  set(id: string, session: Session): Promise<void>;
  touch(id: string): Promise<boolean>;   // refresh idle TTL, false if gone
  delete(id: string): Promise<void>;
  close(): Promise<void>;
}
```

Two implementations:

- `InMemorySessionStore` — the current `Map`, wrapped to satisfy the async
  interface. Used by local dev and by any test that does not specifically
  exercise Redis behaviour.
- `RedisSessionStore` — the production implementation.

Selected at composition time by config (`SESSION_STORE=memory|redis`), defaulting
to `memory` in development/test and `redis` in production. Keeping the in-memory
implementation is a hard requirement, not a temporary migration artifact: it
stays in the codebase permanently so contributors and CI never need Redis to run
the app.

The interface is async on both implementations. Making only the Redis one async
would leak the backing store into every call site.

### 4.2 TTL is Redis key expiry, not a sweeper

Every write sets the key with `EX 1800`. Every successful read re-arms it with
`EXPIRE`/`GETEX`. No background sweep job, no scheduled scan, no per-node timer
wheel. Redis expiring the key *is* the idle timeout, and it is the same
semantics on every node without coordination.

The in-memory implementation mirrors this with a stored `expiresAt` checked
lazily on read (and evicted on read), so both implementations behave identically
from the caller's point of view without a sweeper either.

### 4.3 Key schema and serialization

```
session:v1:<session id>   -> JSON string of the session payload
```

- `session:` prefix keeps sessions distinct from the rate limiter's keys in the
  same Redis instance.
- `v1` lets us change the payload shape later by writing `v2` keys and reading
  both during the transition — the same dual-read trick used in §5.
- Plain JSON string values rather than a hash. The payload is a few hundred
  bytes and always read and written whole; a hash buys nothing and costs an extra
  round of field handling. A single `GETEX` returns the value and re-arms the TTL
  in one round trip.

### 4.4 Latency budget

5ms p99 at the store boundary. A `GETEX` against a same-AZ Redis is well under
1ms of server time; the budget is dominated by network and by connection
contention, so:

- One shared connection (or a small pool) per process, created at boot, not per
  request. Reuse the client setup the rate limiter already has, or a second
  client on the same connection settings — TBD in review.
- `enableOfflineQueue: false` and a low `commandTimeout` (e.g. 200ms) so a Redis
  hiccup surfaces as a fast error rather than a pile of requests parked behind a
  reconnect.
- One command per session lookup. No pipelining across requests, no Lua, nothing
  clever.
- Instrument the store with a histogram (`session_store_duration_seconds`,
  labelled by operation and implementation) and alert on p99 > 5ms.

### 4.5 Failure behaviour

If Redis is unreachable, `get` rejects. The route layer treats a store error as
"no session" — i.e. a 401 and a re-login — rather than a 500, but we do **not**
silently fall back to a local `Map`, because that would recreate the exact
split-brain we are removing. Redis being down is already a site-wide outage for
the rate limiter, so this does not introduce a new single point of failure.

## 5. Rollout: no logout storm

The hard requirement is that sessions created before the deploy survive it. A
hard cutover drops the `Map` on restart and logs everyone out, so instead we
ship in three stages.

**Stage 1 — dual-read, Redis-write (one deploy).**

`MigratingSessionStore` wraps both implementations:

```
get(id):
  s = redis.get(id)
  if s: return s
  s = memory.get(id)            // session from before this deploy, same node
  if s: redis.set(id, s, EX remaining)   // backfill
  return s

set/touch/delete: Redis is authoritative; also applied to memory while it exists
```

Because the old `Map` is per-process, a pre-existing session is only backfillable
on the node that owns it. That is fine: the load balancer keeps sending some
requests to that node, and the first one that lands there promotes the session
into Redis, after which every node can see it. Users whose requests land
elsewhere first are the one gap — see §7.

**Stage 2 — drain (≥ 30 minutes, in practice one business day).**

Run stage 1 until the in-memory fallback stops being hit. Emit a counter
(`session_store_memory_fallback_total`) and wait for it to reach zero. Since the
idle TTL is 30 minutes, every surviving session has either been promoted to Redis
or legitimately expired well before a day is out.

**Stage 3 — remove the wrapper (one deploy).**

Delete `MigratingSessionStore`; production constructs `RedisSessionStore`
directly. `InMemorySessionStore` stays in the tree for dev/CI.

Only stage 3 adds the third node. Scaling out before the drain completes would
route pre-existing sessions to nodes that cannot backfill them.

**Rollback.** Stages 1 and 2 roll back by redeploying the previous build; Redis
keys are simply ignored and expire on their own. After stage 3, rollback means
redeploying the stage-1 build — sessions live in Redis and are still readable, so
rollback is also logout-free.

## 6. Testing

- `SessionStore` gets one **shared contract test suite** (`node:test`) run
  against both implementations: get/set round trip, missing key, TTL refresh on
  read, expiry after idle, delete. Both implementations must pass the same
  assertions — that is what makes the in-memory one a trustworthy stand-in.
- The Redis implementation's contract run uses **testcontainers** to start a real
  Redis. No `ioredis-mock`, no hand-written fake: TTL and expiry semantics are
  exactly the thing we would be faking, and faking them would defeat the test.
- `MigratingSessionStore` gets its own tests around the backfill path: session
  only in memory → promoted to Redis; session in both → Redis wins; session in
  neither → undefined; backfill preserves remaining TTL rather than resetting to
  a full 30 minutes.
- Expiry timing is tested against the container by writing with a short TTL
  rather than by sleeping 30 minutes.
- CI runs the full suite; the testcontainers-backed runs are tagged so they can
  be skipped locally when Docker is not available, and the in-memory contract run
  still covers behaviour.

## 7. Open questions

1. **Encrypt session payloads at rest in Redis?** Undecided. Payloads are user
   id, roles, and a flag bucket — not credentials, but not nothing either.
   Against: adds a key-rotation story and CPU on the hot path. For: a Redis
   snapshot or an errant `KEYS`/`SCAN` would otherwise expose roles for every
   active user, and Redis is shared with the rate limiter. Needs a decision
   before stage 1 ships, since it changes the value format (and therefore the key
   version).
2. **Dedicated Redis client or reuse the rate limiter's?** Sharing is simpler;
   separating means a session command cannot be queued behind a rate-limiter
   command and lets the two have different timeouts.
3. **The stage-1 gap:** a user whose first post-deploy request lands on a node
   that does not own their session sees a 401 once. Options: accept it (small
   window, small blast radius), or enable sticky sessions *for the duration of
   stage 1 only* to guarantee the backfill happens. Sticky sessions are rejected
   as the permanent answer — they just move the problem — but as a temporary
   rollout aid they are worth considering.

## 8. Alternatives considered

- **Sticky sessions at the load balancer.** No storage change, but it moves the
  problem rather than solving it: a node restart or rebalance still drops every
  session pinned to it, deploys become disruptive, and load distribution gets
  lumpy. Rejected as the permanent design.
- **Stateless JWT sessions.** Removes shared state entirely, but we lose
  server-side invalidation and idle-TTL refresh, and it is a much larger change
  to the auth flow than the problem warrants.
- **Postgres-backed sessions.** We would need a sweeper for expiry and it puts
  read traffic on the primary for something Redis does natively in one command.
- **Hard cutover to Redis.** Simplest code by far, and rejected only because of
  the logout storm.
