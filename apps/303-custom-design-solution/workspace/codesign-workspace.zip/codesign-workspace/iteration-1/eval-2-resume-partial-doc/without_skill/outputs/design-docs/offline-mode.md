# Offline Mode

> Status: Draft · 2026-09-24

## Goals

- A cook who opened a recipe while online can still read it with no connection, mid-recipe, without losing their place.
- The app never shows a blank screen or a spinner that never resolves when the network is gone.
- Priority when these conflict: reading an already-opened recipe wins over everything else.

## Non-Goals

- Offline *editing* of recipes — not yet; sync conflict resolution is a project of its own and there is no demand signal for it.
- Offline search across the full catalog — out of scope; only recipes the user has actually opened are cached.
- Background sync when the app is closed — deliberately rejected; the battery and complexity cost is not worth it for a recipe app.

## Desired Behavior

### Offline is one app-wide fact

Connectivity is a single application-level signal, not a question each component asks itself.
One root-provided service owns it; everything else reads it. No component calls `navigator.onLine`
directly, and nothing listens to `window`'s `online`/`offline` events except that one service.

The signal is derived from `navigator.onLine` plus the `online`/`offline` window events, and it is
*corrected by reality*: a recipe read that fails with a network-level error flips it to offline even
if the browser still claims to be online (captive portals, "connected to Wi-Fi with no internet").
A subsequent successful read flips it back.

### Reading a recipe

| State | Cached copy? | What the cook sees |
|---|---|---|
| Online | — | Fresh recipe from the network. The response is written to the cache as a side effect. |
| Online, request fails | Yes | Cached recipe **with the offline-copy marker**, and the app-wide signal flips to offline. |
| Online, request fails | No | Error state with a retry affordance. Not a spinner. |
| Offline | Yes | Cached recipe **with the offline-copy marker**. No network attempt, no spinner, no delay. |
| Offline | No | A dedicated "not available offline" state naming the recipe, with a retry affordance. Not a spinner, not a blank page. |

There is no state in this table where the cook waits on a request that will never resolve. Every
read resolves to content, cached content, or an explicit terminal state.

### The staleness marker

This is the part that actually worries us: a recipe is edited on the server while a copy sits in the
cache on the device. The resolution is to **show the cached copy and be honest about its age**, not
to block.

- When a recipe is served from cache, the detail page renders a persistent marker above the recipe:
  **"Offline copy from 21 Sep 2026"**.
- The date shown is *when we cached it*, not when the server last modified it — the server's
  modification time is exactly what we cannot know while offline. Wording is therefore about our
  copy, not about the recipe's freshness.
- The marker is not dismissible. It is a property of the content being shown, so it stays for as
  long as the cached copy is on screen, and disappears the moment a network read succeeds.
- The marker is rendered by the recipe detail page itself, from the read result, so it cannot drift
  out of sync with the content it describes. It is not driven by the global offline signal — a
  cached copy shown during a failed online read still carries it.
- Accessibility: the marker is a `role="status"` region so a screen reader announces the provenance
  when it appears, without stealing focus mid-recipe.

### Coming back online

- Reconnecting does not silently swap the recipe under the cook's hands. Losing their place
  mid-recipe is the failure mode the Goals exist to prevent.
- On reconnect, the currently-open recipe is re-fetched in the background. If the fetch succeeds and
  the payload is unchanged, the marker just disappears. If it succeeds and the payload *differs*,
  the marker is replaced by a non-blocking "This recipe was updated — [show the new version]"
  affordance. The cook chooses when to take it.
- Navigating to any other recipe after reconnecting goes through the normal online path, so the
  update is applied without ceremony everywhere except the page being actively read.

### What is available offline

- **The app shell always.** HTML, JS, CSS and fonts are cached so the app boots with no connection.
  This is what keeps "no blank screen" true.
- **Every recipe detail page opened at least once while online**, with its images.
- **The recipe list is best-effort.** If the last-seen list happens to be in cache it is served, with
  the same marker treatment. It is not a promise, and a cold cache showing an offline empty state on
  the list page is acceptable. Search remains a Non-Goal.

## Design & Implementation Details

### The shape of it

The service worker is deliberately kept dumb. It caches the app shell and nothing else. **The
decision "network or cache?" lives in ordinary Angular DI, on the main thread**, because the Cache
API is available in `window`, not only inside a worker. That single choice is what makes this
feature testable: every interesting rule in this document can be exercised in Vitest with no service
worker registered, no worker lifecycle, and no browser-mode test run.

```
RecipeDetailComponent                     reads a signal, renders marker from `status`
        │
        ▼
OfflineRecipeRepository       (injectable) ── the whole decision lives here
        │
        ├── RecipeRepository   (existing HTTP repository, untouched)
        ├── RecipeCacheStore   (abstract) ── CacheApiRecipeCacheStore   (prod)
        │                                 └─ InMemoryRecipeCacheStore   (tests)
        └── Connectivity       (injectable) ── the one app-wide offline signal

ngsw (assetGroups only) ─────────────────── app shell, JS/CSS/fonts. Not in the data path.
```

### `Connectivity` — the one app-wide signal

Root-provided. Owns the only `navigator.onLine` read and the only `online`/`offline` listeners in
the app.

```ts
@Injectable({ providedIn: 'root' })
export class Connectivity {
  readonly #navigatorOnline = signal(navigator.onLine);
  readonly #lastReadFailed = signal(false);

  /** The single source of truth. Everything else reads this. */
  readonly isOffline = computed(() => !this.#navigatorOnline() || this.#lastReadFailed());

  constructor() {
    fromEvent(window, 'online').pipe(takeUntilDestroyed())
      .subscribe(() => { this.#navigatorOnline.set(true); this.#lastReadFailed.set(false); });
    fromEvent(window, 'offline').pipe(takeUntilDestroyed())
      .subscribe(() => this.#navigatorOnline.set(false));
  }

  /** Called by the repository so a captive portal is treated as offline. */
  reportReadFailure() { this.#lastReadFailed.set(true); }
  reportReadSuccess() { this.#lastReadFailed.set(false); }
}
```

`navigator.onLine` is injected rather than read statically in the real implementation (a small
`WINDOW` token, as we already do elsewhere) so the initial value is controllable in tests.

### `RecipeCacheStore` — the seam

An abstract class used as the DI token. It is deliberately *not* HTTP-shaped and not
`Response`-shaped: it speaks recipes and timestamps, so the fake is trivial and the assertions in
tests read like the design doc.

```ts
export interface CachedRecipe {
  recipe: Recipe;
  cachedAt: Date;
}

export abstract class RecipeCacheStore {
  abstract read(id: RecipeId): Promise<CachedRecipe | undefined>;
  abstract write(recipe: Recipe): Promise<void>;
  abstract prune(): Promise<void>;
}
```

- `CacheApiRecipeCacheStore` — production. Opens `caches.open('whiskmate-recipes-v1')`, keys entries
  on a synthetic request URL (`/api/recipes/:id`), and on write re-constructs the `Response` with an
  added `x-whiskmate-cached-at` header carrying `new Date().toISOString()`. Reading parses that
  header back into `cachedAt`. The timestamp is our clock and travels with the entry — there is no
  second store to keep in sync.
- `InMemoryRecipeCacheStore` — a `Map<RecipeId, CachedRecipe>` with an injectable clock. Used by
  every unit and component test.

**Eviction:** cap at 50 recipes, evicting the oldest `cachedAt` first, run opportunistically after
each write. **No TTL** — an old entry is still worth showing because the marker tells the cook how
old it is; silently expiring it would reintroduce the empty screen the Goals forbid. Images live in
a separate cache (`whiskmate-recipe-images-v1`) with its own budget so one photo-heavy recipe cannot
evict forty text payloads.

**Versioning:** the cache name carries a version suffix. A schema change to `Recipe` means bumping
the suffix and deleting the old caches on startup — cheap, because everything in here is
reconstructible from the server.

### `OfflineRecipeRepository` — the decision

The only place that knows the rule. Returns a value that carries its own provenance, so the UI never
has to guess and the marker cannot drift out of sync with the content.

```ts
export type RecipeReadResult =
  | { status: 'fresh';    recipe: Recipe }
  | { status: 'cached';   recipe: Recipe; cachedAt: Date }
  | { status: 'unavailable-offline'; id: RecipeId }
  | { status: 'error';    id: RecipeId; cause: unknown };

@Injectable({ providedIn: 'root' })
export class OfflineRecipeRepository {
  readonly #recipes = inject(RecipeRepository);
  readonly #cache = inject(RecipeCacheStore);
  readonly #connectivity = inject(Connectivity);

  async read(id: RecipeId): Promise<RecipeReadResult> {
    if (this.#connectivity.isOffline()) {
      return this.#fromCache(id);
    }

    try {
      const recipe = await this.#recipes.getRecipe(id);
      this.#connectivity.reportReadSuccess();
      await this.#cache.write(recipe);           // cache-on-read, fire-and-forget failures
      return { status: 'fresh', recipe };
    } catch (cause) {
      if (!isNetworkError(cause)) {
        return { status: 'error', id, cause };   // a 404 is not an offline problem
      }
      this.#connectivity.reportReadFailure();
      return this.#fromCache(id);
    }
  }

  async #fromCache(id: RecipeId): Promise<RecipeReadResult> {
    const cached = await this.#cache.read(id);
    return cached
      ? { status: 'cached', recipe: cached.recipe, cachedAt: cached.cachedAt }
      : { status: 'unavailable-offline', id };
  }
}
```

Notes on the rules encoded above:

- **Offline short-circuits.** When the app-wide signal says offline we do not attempt a request at
  all. That is what makes the offline read instant rather than a timeout, and it is why "no spinner
  that never resolves" holds.
- **A 404 is not an offline problem.** Only network-level failures fall back to the cache and flip
  the connectivity signal. An HTTP error status is a real answer from a reachable server and is
  surfaced as `error`. A 404 additionally evicts the cached entry — the recipe is gone, not stale.
- **Cache write failures never fail a read.** A full or unavailable quota degrades offline support;
  it must not break the online path.

### Rendering

`RecipeDetailComponent` holds the result in a signal (via `resource()` keyed on the route param) and
switches on `status`. The marker is a small presentational component fed straight from the result:

```html
@switch (result().status) {
  @case ('cached') {
    <wm-offline-copy-marker [cachedAt]="result().cachedAt" />
    <wm-recipe [recipe]="result().recipe" />
  }
  @case ('fresh')               { <wm-recipe [recipe]="result().recipe" /> }
  @case ('unavailable-offline') { <wm-recipe-unavailable-offline [id]="result().id" /> }
  @case ('error')               { <wm-recipe-error [id]="result().id" /> }
}
```

`wm-offline-copy-marker` renders `Offline copy from {{ cachedAt | date:'mediumDate' }}` inside a
`role="status"` region. It takes no services — it is a pure function of its input.

### Reconnect

An effect on `Connectivity.isOffline` transitioning `true → false` triggers one background
re-read of the currently open recipe. If the payload deep-equals the cached one, the result simply
becomes `fresh` and the marker disappears. If it differs, the component keeps rendering the cached
recipe and shows the "this recipe was updated" affordance; the fresh payload is held aside until the
cook taps it. Scroll position is never touched by this path.

### Where the code goes (Nx)

| Library | Contents |
|---|---|
| `recipe/offline` (feature-agnostic, `type:data-access`) | `OfflineRecipeRepository`, `RecipeCacheStore` + both implementations, `RecipeReadResult` |
| `shared/connectivity` (`type:util`) | `Connectivity` |
| `recipe/detail` (`type:feature`) | the `@switch`, `wm-offline-copy-marker`, the offline empty state |
| app shell | `provideServiceWorker()` + `ngsw-config.json` with `assetGroups` only |

The `ngsw-config.json` deliberately contains **no `dataGroups`**. If someone later adds one for
`/api/recipes/**`, it will silently intercept the data path and the `status` on our read result will
start lying. That is worth a comment in the file and a note in the PR template.

## Testing Strategy

The premise: **testing a service worker directly is miserable**, so the design above is arranged so
that we almost never have to. Everything that encodes a decision lives on the main thread behind
`RecipeCacheStore`, and is therefore ordinary Vitest work.

### 1. `OfflineRecipeRepository` — unit tests (the bulk of the coverage)

Vitest, `InMemoryRecipeCacheStore`, and the MSW setup we already use. Offline is simulated with an
MSW handler override returning `HttpResponse.error()`, which is the closest thing to the real
failure and keeps the HTTP layer in the test rather than stubbing it away.

One test per row of the behavior table:

| Case | Setup | Expected |
|---|---|---|
| Online, server responds | default handlers | `status: 'fresh'` **and** the recipe is now in the cache store |
| Online, network error, cache warm | `HttpResponse.error()`, store pre-seeded | `status: 'cached'`, `cachedAt` matches the seed |
| Online, network error, cache cold | `HttpResponse.error()`, empty store | `status: 'unavailable-offline'` |
| Offline, cache warm | `Connectivity` forced offline | `status: 'cached'` **and** MSW recorded zero requests |
| Offline, cache cold | forced offline, empty store | `status: 'unavailable-offline'` |
| Server returns 404 | 404 handler | `status: 'error'`, connectivity still online, cached entry evicted |
| Server returns 500 | 500 handler | `status: 'error'`, **not** `'cached'` — a reachable server is not an offline situation |
| Cache write throws (quota) | store stubbed to reject on write | `status: 'fresh'` — the read still succeeds |

The "MSW recorded zero requests" assertion matters: it is the test that actually pins "no spinner
that never resolves", because it proves the offline path never waits on the network.

### 2. `Connectivity` — unit tests

With an injected `WINDOW` fake: assert the initial value from `navigator.onLine`, then
`window.dispatchEvent(new Event('offline'))` / `'online'` and assert the signal. Plus
`reportReadFailure()` flipping it to offline while `navigator.onLine` is still `true` — the captive
portal case — and a subsequent success clearing it.

### 3. Component tests — Angular Testing Library

Rendered against a pre-seeded `InMemoryRecipeCacheStore` and a controllable `Connectivity`. These
assert what the cook sees, in the cook's words:

- Offline with a warm cache → `screen.getByText(/offline copy from 21 sep 2026/i)` is present and
  the recipe steps are rendered.
- Online → the marker is **absent** (`queryByText` returns null). A marker that never disappears is
  the regression to fear here.
- Offline with a cold cache → the "not available offline" state names the recipe; no spinner in the
  document.
- Reconnect with a changed payload → the "this recipe was updated" affordance appears while the
  *old* text is still on screen; clicking it swaps the content.
- The marker's `role="status"` is asserted once, in the marker's own test.

Dates are frozen with `vi.setSystemTime()` so the rendered date string is deterministic.

### 4. Cache store contract test

One suite, exported, run twice:

```ts
describe.each([
  ['in-memory', () => new InMemoryRecipeCacheStore()],
  ['cache-api', () => new CacheApiRecipeCacheStore()],
])('RecipeCacheStore contract (%s)', (_, createStore) => { /* … */ });
```

Cases: write-then-read round-trips the recipe; `cachedAt` is the write time, not the read time; a
missing id reads as `undefined`; `prune()` keeps the 50 most recent and drops the rest; a cache-name
version bump makes old entries invisible.

The `cache-api` arm needs a real `caches` object, so this one suite — and only this one — runs in
browser-mode Vitest. It is what stops the in-memory fake from quietly drifting away from reality,
which is the usual way a "testable seam" design rots.

### 5. One end-to-end smoke — Playwright

Exactly one test, not a suite: load a recipe online, `context.setOffline(true)`, reload, assert the
recipe and the marker are both on screen. Its only job is to prove the service worker is registered
and the app shell is genuinely cached — the two things unit tests structurally cannot see.

### Explicitly not tested

- The service worker's internals, lifecycle, or fetch handler. We own no fetch handler for data; the
  shell caching is ngsw's `assetGroups`, which is Angular's code and Angular's tests. The one
  Playwright smoke is our entire assertion about it.
- Browser storage eviction under real quota pressure. Not reproducible in CI; `prune()` is tested
  directly instead.

## Alternatives Considered

### IndexedDB, hand-rolled (or via Dexie/idb)

Rejected. What we are storing is "this HTTP response, and when we got it" — the Cache API is exactly
that data structure, already. Hand-rolling an object store means owning a schema, migrations and
transaction ceremony to reimplement something the platform hands us. A library hides the ceremony
but adds a dependency and still leaves us maintaining a schema. Revisit only if offline *editing*
lands, where a queue of pending mutations genuinely is a database problem.

### localStorage

Rejected. Synchronous, ~5MB, string-only, and it would put recipe payloads on the main thread's
critical path. Not viable once images are in scope.

### Caching in the service worker's `fetch` handler

Rejected on testability. It is the conventional answer and it works, but the app then cannot tell a
cached response from a fresh one — which kills the staleness marker, the single thing this design
most cares about. Recovering that would mean a `postMessage` bridge (below), and every test would
need a registered, activated worker. Keeping the decision in DI costs nothing and buys us a feature
that is fully unit-testable.

### ngsw `dataGroups` with a `freshness` strategy

Rejected as the data-path mechanism. It is three lines of config and it does implement network-first
with a cache fallback — but it offers no hook for the cached-at timestamp and no way for the app to
learn that a response came from cache. It would give us offline reads with no marker, which is the
wrong half of the problem. ngsw is still used, for `assetGroups` only.

### Service worker decides, app asks over `postMessage`

Rejected. It recovers the provenance information but makes every relevant test require a live
worker, and turns a synchronous local decision into an async cross-context handshake. All of the
cost of the SW approach, plus a message protocol to maintain.

### Blocking on stale data (interstitial, or "show anyway" confirmation)

Rejected. The Goals say a cook mid-recipe with their hands in dough must not lose their place;
interrupting them with a modal about data freshness is precisely that failure. The marker gives them
the same information without taking the recipe away.

### Showing the cached copy silently, with no marker

Rejected. Cheapest UI, but it leaves the cook with no way to know whether the quantities they are
reading are the ones someone corrected yesterday. The whole risk this document is about is invisible
in that design.

### TTL-based expiry of cached recipes

Rejected. Deleting a cached recipe because it is old reintroduces the blank screen for a cook who is
offline — the exact outcome the Goals forbid — in exchange for a freshness guarantee we cannot
actually make anyway. Age is communicated, not enforced. Eviction is by count, oldest first.

### Per-component `navigator.onLine` checks

Rejected. That is how four components end up disagreeing about whether the app is online, and it
makes offline state untestable without global monkey-patching in every spec. One root-provided
signal, injected everywhere.

### Auto-refreshing the open recipe on reconnect

Rejected as the default. Swapping content under someone who is reading step 4 is the same "losing
their place" failure, arriving from the other direction. The update is offered, not applied.

## Open Questions

- Does the recipe API expose an ETag or `Last-Modified`? If so, the reconnect re-read can be a cheap
  conditional request instead of a full payload comparison. Does not change the design, only its
  cost.
- Image cache budget: what is a realistic per-recipe image weight in production? Needed to pick a
  number for the separate image cache cap.
- Should the offline-copy marker appear on the best-effort cached *list* page too, or only on recipe
  detail? Leaning yes for consistency, but the list is not a Goal so it can ship later.

