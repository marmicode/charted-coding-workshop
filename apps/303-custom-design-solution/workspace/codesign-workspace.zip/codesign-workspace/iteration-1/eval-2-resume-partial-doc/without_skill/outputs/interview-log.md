# Interview Log — Offline Mode design doc

Questions that would have been asked via `AskUserQuestion`, in the order they came up,
each immediately followed by the answer used to continue.

---

## Round 1 — before writing "Desired Behavior"

```json
{
  "questions": [
    {
      "question": "What should the app show when it's offline and the cached copy of a recipe may be out of date on the server?",
      "header": "Stale data",
      "multiSelect": false,
      "options": [
        {
          "label": "Show cached + dated marker",
          "description": "Render the cached recipe immediately with a persistent 'Offline copy from <date>' marker. Never blocks the cook.",
          "preview": "┌────────────────────────────────┐\n│ ⚠ Offline copy from 21 Sep 2026│\n├────────────────────────────────┤\n│ Tarte Tatin                    │\n│ 6 apples, 200g sugar, ...      │\n└────────────────────────────────┘"
        },
        {
          "label": "Block until confirmed",
          "description": "Show an interstitial explaining the data may be stale; the user must tap 'show anyway' before the recipe renders.",
          "preview": "┌────────────────────────────────┐\n│ This recipe may be out of date.│\n│   [ Show anyway ]  [ Cancel ]  │\n└────────────────────────────────┘"
        },
        {
          "label": "Show cached silently",
          "description": "Render the cached copy with no visual difference from a fresh one. Simplest UI, but the cook can't tell.",
          "preview": "┌────────────────────────────────┐\n│ Tarte Tatin                    │\n│ 6 apples, 200g sugar, ...      │\n└────────────────────────────────┘"
        },
        {
          "label": "Hard TTL, expire cache",
          "description": "Cached recipes older than N hours are treated as absent; the offline empty state is shown instead.",
          "preview": "┌────────────────────────────────┐\n│ This recipe is no longer       │\n│ available offline.             │\n└────────────────────────────────┘"
        }
      ]
    },
    {
      "question": "How should 'the app is offline' be represented in the codebase?",
      "header": "Offline state",
      "multiSelect": false,
      "options": [
        {
          "label": "One app-wide signal",
          "description": "A single root-provided service exposes an `isOffline` signal; every component reads that one source.",
          "preview": "inject(Connectivity).isOffline()  // signal<boolean>"
        },
        {
          "label": "Per-component checks",
          "description": "Each component that cares queries `navigator.onLine` / listens to events itself.",
          "preview": "if (navigator.onLine) { ... }  // repeated per component"
        },
        {
          "label": "Derive from request failures only",
          "description": "No explicit online/offline state; components infer it from a failed HTTP call.",
          "preview": "catchError(() => of(OFFLINE_STATE))"
        },
        {
          "label": "Router/global banner only",
          "description": "A single banner component owns the state; nothing else in the app knows.",
          "preview": "<app-offline-banner />  // state private to this component"
        }
      ]
    },
    {
      "question": "What storage mechanism should back the offline recipe cache?",
      "header": "Storage",
      "multiSelect": false,
      "options": [
        {
          "label": "Service worker + Cache API",
          "description": "Cache HTTP responses as Response objects. Natural fit for a read-only cache of fetched payloads.",
          "preview": "caches.open('whiskmate-recipes-v1')\n  .then(c => c.put(req, res))"
        },
        {
          "label": "IndexedDB, hand-rolled",
          "description": "Store deserialized recipe objects in an object store with our own schema and migrations.",
          "preview": "db.transaction('recipes','readwrite')\n  .objectStore('recipes').put(recipe)"
        },
        {
          "label": "IndexedDB via a library (Dexie/idb)",
          "description": "Same as above but with a wrapper to hide the transaction ceremony. Adds a dependency.",
          "preview": "await db.recipes.put(recipe)"
        },
        {
          "label": "localStorage",
          "description": "Serialize recipes to JSON strings. Simplest, but synchronous and ~5MB cap.",
          "preview": "localStorage.setItem(`recipe:${id}`, JSON.stringify(recipe))"
        }
      ]
    },
    {
      "question": "Which reads must keep working offline?",
      "header": "Offline scope",
      "multiSelect": true,
      "options": [
        {
          "label": "App shell (never a blank page)",
          "description": "HTML, JS, CSS, fonts served from cache so the app always boots offline."
        },
        {
          "label": "Recipe detail pages already opened",
          "description": "Any recipe the user has actually viewed while online."
        },
        {
          "label": "The recipe list / home page",
          "description": "The last-seen page of the catalog listing, served from cache."
        },
        {
          "label": "Recipe images",
          "description": "Hero and step images for cached recipes, which dominate the cache budget."
        }
      ]
    }
  ]
}
```

**Answer:**

- Stale data → **Show cached + dated marker**. ("The thing that actually worries me is a recipe edited on the server while a stale copy sits on the device. But blocking someone mid-recipe with their hands in dough is worse than showing them a slightly old copy. Tell them how old it is and let them decide.")
- Offline state → **One app-wide signal**. ("Per-component `navigator.onLine` checks are how you end up with four components disagreeing about whether you're online.")
- Storage → **Service worker + Cache API**. ("Hand-rolling IndexedDB for what is literally 'remember this HTTP response' is work we'd regret. We're caching read payloads, not running a local database.")
- Offline scope → **App shell**, **Recipe detail pages already opened**, plus `Other: images yes but strictly for recipes we've already cached — and the list page is a nice-to-have. Serve the last-seen list if it happens to be in the cache, but don't promise it and don't make it a goal.`

---

## Round 2 — before writing "Design & Implementation Details"

```json
{
  "questions": [
    {
      "question": "Where should the 'serve from network or from cache?' decision actually live?",
      "header": "Cache seam",
      "multiSelect": false,
      "options": [
        {
          "label": "Injectable on the main thread",
          "description": "The service worker handles only the app shell. The recipe cache decision is a plain injectable using the Cache API from window, so it can be unit-tested with no service worker at all.",
          "preview": "@Injectable()\nclass OfflineRecipeRepository {\n  async read(id) {\n    try { return await this.#network(id); }\n    catch { return this.#cache.read(id); }\n  }\n}\n// Cache API works in window, not just in a SW."
        },
        {
          "label": "Inside the service worker (fetch handler)",
          "description": "The SW intercepts /api/recipes/* and applies a network-first strategy. The Angular app stays unaware it is happening.",
          "preview": "self.addEventListener('fetch', e => {\n  e.respondWith(\n    fetch(e.request).catch(() => caches.match(e.request))\n  );\n});\n// App can't see 'this came from cache'."
        },
        {
          "label": "ngsw dataGroups config",
          "description": "Declare /api/recipes/** as a freshness dataGroup in ngsw-config.json. Zero code, but no hook for the cached-at date or the 'source' of a response.",
          "preview": "{ \"dataGroups\": [{\n  \"name\": \"recipes\",\n  \"urls\": [\"/api/recipes/**\"],\n  \"cacheConfig\": { \"strategy\": \"freshness\", \"maxAge\": \"30d\", \"maxSize\": 100 }\n}] }"
        },
        {
          "label": "SW decides, app asks via postMessage",
          "description": "Caching lives in the SW; the app queries it over a message channel to learn whether a response was cached and when.",
          "preview": "sw.postMessage({ type: 'RECIPE_META', id });\n// async, needs a live SW in every test"
        }
      ]
    },
    {
      "question": "What should the service worker itself be responsible for, then?",
      "header": "SW scope",
      "multiSelect": false,
      "options": [
        {
          "label": "@angular/service-worker (ngsw), assets only",
          "description": "Use ngsw for the app shell and static assets via assetGroups. No dataGroups. It's configuration, not code we maintain."
        },
        {
          "label": "Hand-written service worker",
          "description": "Full control over both shell and data caching, at the cost of owning a file nobody wants to debug."
        },
        {
          "label": "Workbox",
          "description": "Third-party SW toolkit; more capable than ngsw but a new dependency and a second mental model next to Angular's."
        },
        {
          "label": "No service worker at all",
          "description": "Main-thread Cache API only. Then the app shell itself can't be served offline and 'no blank screen' fails on a cold start."
        }
      ]
    },
    {
      "question": "How do we know when a cached recipe was cached?",
      "header": "Cached-at",
      "multiSelect": false,
      "options": [
        {
          "label": "Stamp a header at write time",
          "description": "Re-construct the Response with an extra `x-whiskmate-cached-at` header before putting it in the cache. Self-contained: the timestamp travels with the entry.",
          "preview": "const stamped = new Response(body, {\n  headers: { ...res.headers, 'x-whiskmate-cached-at': new Date().toISOString() }\n});\ncache.put(req, stamped);"
        },
        {
          "label": "Trust the response Date header",
          "description": "Read the server's `Date` header off the cached response. No write-time work, but it's the server's clock and proxies can rewrite it.",
          "preview": "new Date(cachedResponse.headers.get('Date'))"
        },
        {
          "label": "Sidecar metadata store",
          "description": "Keep an id → timestamp map in localStorage/IndexedDB next to the Cache API entries.",
          "preview": "localStorage.setItem(`cachedAt:${id}`, Date.now())\n// two stores that can drift apart"
        }
      ]
    },
    {
      "question": "What's the cache budget / eviction policy for recipes?",
      "header": "Eviction",
      "multiSelect": false,
      "options": [
        {
          "label": "Cap by count, evict oldest",
          "description": "Keep the N most recently cached recipes; drop the oldest beyond that. Predictable and easy to reason about."
        },
        {
          "label": "TTL — expire after N days",
          "description": "Cached recipes older than a cutoff are deleted and treated as absent."
        },
        {
          "label": "No policy, let the browser evict",
          "description": "Never prune. Rely on the browser's storage pressure eviction."
        },
        {
          "label": "LRU by last read",
          "description": "Track reads and evict the least recently *read* recipe rather than the oldest-cached one."
        }
      ]
    }
  ]
}
```

**Answer:**

- Cache seam → **Injectable on the main thread**. ("Testing a service worker directly is miserable — you need a real browser, a registration, an activation, and then you're debugging a worker lifecycle instead of your caching rule. If the decision is a plain injectable I can test the whole thing in Vitest with a fake in-memory cache and never register a service worker.")
- SW scope → **@angular/service-worker (ngsw), assets only**. ("assetGroups for the shell is config we don't maintain. No dataGroups — the data path is ours.")
- Cached-at → **Stamp a header at write time**. ("Our clock, our cache, our timestamp. Nothing to keep in sync.")
- Eviction → `Other: cap by count (start at 50), evict oldest-cached first — but explicitly no TTL. A year-old cached recipe with a visible "offline copy from" marker is still better than an empty screen; that's the whole point of the marker. Images get their own separate cache and budget so a photo-heavy recipe can't evict 40 text payloads.`

---

## Round 3 — before writing "Testing Strategy"

```json
{
  "questions": [
    {
      "question": "How far should the automated tests go for offline mode?",
      "header": "Test depth",
      "multiSelect": true,
      "options": [
        {
          "label": "Unit-test the repository with a fake cache store",
          "description": "Vitest + InMemoryRecipeCacheStore + MSW toggled to a network error. Covers every row of the behavior table with no browser involved."
        },
        {
          "label": "Component tests with Angular Testing Library",
          "description": "Render the detail page with a pre-seeded fake cache and assert the visible 'Offline copy from …' text, the empty state, and the update affordance."
        },
        {
          "label": "A contract test run against the real Cache API implementation",
          "description": "One shared suite executed against both the fake and CacheApiRecipeCacheStore (the latter in browser-mode Vitest) so the fake can't drift from reality."
        },
        {
          "label": "An end-to-end test with a real service worker",
          "description": "Playwright, registered SW, context.setOffline(true). Highest fidelity, slowest and flakiest."
        }
      ]
    },
    {
      "question": "How should the tests simulate 'the network is gone'?",
      "header": "Faking offline",
      "multiSelect": false,
      "options": [
        {
          "label": "MSW handler that throws a network error",
          "description": "Keep using the MSW setup we already have; add a handler override returning HttpResponse.error() per test.",
          "preview": "server.use(\n  http.get('/api/recipes/:id', () => HttpResponse.error())\n);"
        },
        {
          "label": "Stub the RecipeRepository directly",
          "description": "Provide a test double for the HTTP repository that rejects. Less realistic — bypasses the HTTP layer entirely.",
          "preview": "{ provide: RecipeRepository, useValue: { getRecipe: () => Promise.reject(...) } }"
        },
        {
          "label": "Override navigator.onLine only",
          "description": "Flip the connectivity signal and never exercise the request-failure path at all."
        }
      ]
    }
  ]
}
```

**Answer:**

- Test depth → **Unit-test the repository with a fake cache store**, **Component tests with Angular Testing Library**, **A contract test run against the real Cache API implementation**, plus `Other: one — exactly one — Playwright smoke that loads a recipe, goes offline and reloads. Not a suite. Its job is to prove the shell is actually cached and the SW registered; everything else is covered above. I do not want a single test that asserts on service worker internals — testing a service worker directly is miserable and we designed our way out of needing to.`
- Faking offline → **MSW handler that throws a network error**. ("We already run MSW everywhere; `HttpResponse.error()` is the closest thing to the real failure and it keeps the HTTP layer in the test.")

---

## End of interview

Both remaining sections ("Testing Strategy", "Alternatives Considered") were written from the
answers above. The Alternatives section records the options that were shown and *not* picked in
rounds 1–3, with the reasons given at the time.
