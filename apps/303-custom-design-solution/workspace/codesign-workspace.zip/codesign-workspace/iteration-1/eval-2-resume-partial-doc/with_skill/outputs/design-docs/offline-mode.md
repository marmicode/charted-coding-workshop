# Offline Mode

> Status: Draft · 2026-09-24

## Goals

- A cook who opened a recipe while online can still read it with no connection, mid-recipe, without losing their place.
- The app never shows a blank screen or a spinner that never resolves when the network is gone.
- Priority when these conflict: reading an already-opened recipe wins over everything else.

## Non-Goals

- Offline *editing* of recipes — not yet; sync conflict resolution is a project of its own and there is no demand signal for it.
- Offline search across the full catalog — out of scope; only recipes the user has actually opened are cached.
- Background sync when the app is closed — deliberately rejected; the battery and complexity cost is not worth it for a recipe app.

## Desired Behavior

### Happy path — reading a recipe you already opened

- Given the cook opened "Tarte Tatin" yesterday while online,
- When they open it today with no connection,
- Then the recipe renders immediately, complete, with no spinner and no error,
- And a small marker sits under the title: **"Offline copy from 21 Sep"**.

The marker is informational, not a warning. It names *when* the copy was saved and lets the cook judge whether that matters. We never block reading to protect them from a possibly-edited recipe — a stale recipe is far better than no recipe when you're standing over a pan.

### Being offline is one app-wide state

- There is exactly one answer to "are we offline right now", shared by the whole app.
- The app shell shows a single offline indicator while that state is on. Individual screens read the same state; they never decide for themselves.
- The state is readable at any moment, not just at the moment it changes — a cook who opens the app already offline sees the indicator too.

### Edge cases

**The recipe was never opened, so there is no cached copy.**
The cook gets a dedicated "not available offline" screen — not the generic error screen, because this isn't a fault. It says the recipe needs a connection, and links to the recipes that *are* readable offline.

**The app cold-starts with no connection.**
The app still boots, the shell renders, and previously-opened recipes are readable. Offline mode survives a full restart; it is not limited to a live session.

**The connection comes back while a stale copy is on screen.**
Nothing on screen moves. The "Offline copy from 21 Sep" marker becomes **"Newer version available — tap to refresh"**, and the fresh recipe is only fetched and rendered when the cook taps it. We never swap content under someone who is mid-recipe.

**The cook taps something that writes while offline.**
Write actions (favourite, edit, delete) are visibly disabled while offline rather than failing on tap. Tapping the disabled control explains why: "needs a connection". No optimistic write is queued — offline editing is a Non-Goal and a queued write is the first half of building it.

### Must stay unchanged

- Online behaviour is identical to today: no extra latency, no extra request, no marker, no indicator.
- Recipe URLs stay the same and stay shareable — a cached recipe is not a different route.
- Search, filtering and any recipe not previously opened behave exactly as they do now when online.

## Design & Implementation Details

### Storage: service worker + Cache API

- Cached recipes live in the **Cache API**, populated by a **service worker**. This is fundamentally an HTTP response cache; hand-rolling IndexedDB would mean writing persistence, versioning and eviction ourselves for something the browser already does.
- Using `@angular/service-worker` (ngsw) rather than a hand-written worker or Workbox: it's first-party, already understands the Angular build, and the app shell + versioned assets come for free — which is what makes the offline cold-start in Desired Behavior possible at all.
- Recipe API responses are cached via an `ngsw-config.json` **dataGroup**.
- *Known cost, accepted:* caching policy lives in JSON config rather than in testable code. That is exactly why the freshness decision does **not** live there — see the gateway below.

### The seam: `RecipeGateway` returns provenance, not just data

Everything the cook sees about staleness is a plain function of one value:

```ts
type RecipeResult =
  | { recipe: Recipe; source: 'network' }
  | { recipe: Recipe; source: 'cache'; cachedAt: Date }
  | { recipe: null;   source: 'unavailable' };

recipeGateway.getRecipe(id): Observable<RecipeResult>
```

- **Why:** the "offline copy from &lt;date&gt;" marker, the "newer version available" prompt and the "not available offline" screen all read this one object. None of them needs a service worker to exist, so none of their tests do either.
- Components never touch the Cache API, `navigator`, or the service worker registration.
- `cachedAt` is recorded by the gateway when it stores a response, so the marker has a real date rather than an inferred one.

### Freshness policy: network-first, cache fallback

- The gateway always tries the network first and only reads the cache when the request fails.
- **Why:** "online behaviour is identical to today" is in the regression surface. Cache-first would start serving stale recipes to connected cooks in order to serve a disconnected one.
- The cost is accepted: an offline read pays one failed request before the cached copy renders. If that delay proves visible in practice, the fallback is: consult the offline signal and skip the doomed request — recorded in Alternatives.

### The app-wide offline signal

- One injectable, `OnlineStatus`, exposes a **signal**. The app shell's offline indicator and every screen read it. Nothing else computes connectivity.
- Two inputs, because one isn't enough:
  1. `navigator.onLine` and the `online` / `offline` events — fast, and correct on a cold start before any request has been made.
  2. **A gateway request that fell back to cache because the network failed also flips the signal to offline.** `navigator.onLine` lies — a captive portal or a dead API both report "online" — and the gateway is the one place that already knows a fetch failed.
- Going back online requires a real signal, not just the absence of failure: the browser `online` event, or a gateway request that succeeds over the network.
- The signal is **not** load-bearing for which data gets served (the gateway is always network-first). It only drives UI. If the signal is wrong, the cook sees a wrong indicator, never wrong recipe data.

### Where the code lives

```
libs/
  offline/                      # new lib, no recipe knowledge
    src/lib/
      online-status.ts          # the signal
      cache-provenance.ts       # shared provenance types
      offline-indicator.ts      # app-shell indicator
  recipe/                       # existing lib
    src/lib/
      recipe-gateway.ts         # returns RecipeResult
      recipe-page.ts
      offline-copy-marker.ts    # renders the marker / refresh prompt
```

- **Why split:** `OnlineStatus` is app-wide by definition and knows nothing about recipes. Putting it in the recipe lib would make every future consumer depend on recipes to find out whether it's offline. The gateway, conversely, needs the `Recipe` model and the recipe HTTP client, so it stays in the recipe lib. Dependency direction: `recipe → offline`.

### New vs. changed

| | |
|---|---|
| **New** | `libs/offline` (signal, provenance types, indicator); `offline-copy-marker`; the "not available offline" screen; `ngsw-config.json`; service worker registration in the app config. |
| **Changed** | The existing recipe service becomes / is wrapped by `RecipeGateway` returning `RecipeResult`; the recipe page renders the marker and reads `RecipeResult`; write controls (favourite, edit, delete) read `OnlineStatus` to disable themselves. |
| **Unchanged** | Recipe routes and URLs; the recipe HTTP contract; search and filtering. |

### Rollout

- The service worker is a new persistent thing on users' devices, so it ships **behind a flag**: registration is conditional, off by default, enabled for the team first.
- ngsw handles its own update/activation cycle. We take its default (activate on next full page load) rather than prompting — a cook mid-recipe should not get an update prompt.
- `TODO:` decide how to un-register the service worker for a user if we need to pull it — an unregister path must exist before this is enabled for everyone, or a bad worker is sticky.

### Load-bearing dependencies

- `@angular/service-worker` — the only new runtime dependency. Load-bearing: it is the cache and the app-shell story.
- `navigator.onLine` / `online` / `offline` events — browser API, wrapped so it's replaceable and fakeable.

## Testing Strategy

### The principle

Testing service workers directly is miserable, so nothing below the top of this list has one. The cache sits behind a plain injectable precisely so every offline behaviour can be tested without a service worker in the room. What `RecipeGateway` returns *is* the contract.

### What gets tested, and where

| Behavior (from Desired Behavior) | Level | How |
|---|---|---|
| Cached recipe renders **with** the "offline copy from &lt;date&gt;" marker | Component (Angular Testing Library) | Page is handed a `source: 'cache'` result; assert recipe content and marker are both present |
| Online read shows **no** marker and **no** indicator | Component | `source: 'network'` result; assert absence — this is the regression guard |
| Reconnect swaps the marker for "newer version available" and **changes nothing else** | Component | Assert the recipe text on screen is still the old text. What *didn't* happen is the point of this test |
| Never-cached recipe offline → "not available offline" screen, not the generic error | Component | `source: 'unavailable'` result |
| Write controls disabled while offline, with the explanation | Component | Fake `OnlineStatus` set to offline |
| Gateway falls back to cache when the network fails, and flips `OnlineStatus` | Unit (gateway) | MSW errors the request; assert the returned `RecipeResult` and the signal |
| Cold-start with no network, open a cached recipe | E2E (Playwright), **exactly one** | Real service worker, browser offline. The only case the injectable seam genuinely cannot prove |

### What's real, what's faked

- **Real:** `RecipeGateway`'s own logic, the components, the `OnlineStatus` signal implementation.
- **MSW** decides whether the network succeeds or fails — same as everywhere else in whiskmate.
- **Faked at the injectable seam:** the cache, with an in-memory implementation. No service worker, no Cache API, no `navigator` stubbing in unit and component tests.
- **Faked clock:** `cachedAt` assertions use an injected, fixed clock.

### Test-first

The gateway's three `RecipeResult` branches are written **before any service worker exists**. This is deliberate ordering, not discipline for its own sake: if ngsw gets wired in first, the cache seam tends never to appear at all, and then everything above has to be tested through a service worker after all.

### What we're banning to keep these from getting brittle

- **No asserting the literal marker sentence.** Assert the marker is present and names the cached date; the wording will change.
- **No real clocks or real dates.** Inject the clock, fix the date, or the suite fails in another timezone.
- **No component test reaching into gateway internals.** Components only ever receive a `RecipeResult`. A component test that knows about the cache has re-coupled what this design deliberately separated.
- **No sleeps or timer-waiting for connectivity transitions.** The signal is synchronous by design; tests set it directly rather than dispatching browser events and waiting.

## Alternatives Considered

### Hand-written IndexedDB instead of the Cache API

- **Tempting because** it's queryable — "list every recipe available offline" would be a one-liner, and we'd control exactly what's stored.
- **Lost because** this is an HTTP response cache wearing a different hat. We'd hand-write persistence, versioning and eviction, and it still wouldn't cache the app shell, so the offline cold-start would remain broken.
- **Revisit when** we need to *query* the cache rather than just read it by key — the "what's available offline" list on the not-available screen growing beyond a handful of entries, or offline search stopping being a Non-Goal.

### Blocking the read until the recipe can be verified as current

- **Tempting because** it's the only option with zero chance of a cook following a recipe the server has since corrected.
- **Lost because** it contradicts Goal 1 directly. A stale recipe beats no recipe when someone is standing over a pan. The marker exists so the cook makes that call, not us.
- **Revisit when** recipes carry something where staleness is a safety issue rather than an inconvenience — allergen data, for instance. That would be a per-field decision, not a whole-page block.

### Cache-first instead of network-first

- **Tempting because** it renders instantly, always, and avoids the failed request that offline reads currently pay for.
- **Lost because** it would start serving stale recipes to *connected* cooks in order to serve disconnected ones. "Online behaviour is identical to today" is in the regression surface.
- **Revisit when** the failed-request delay before a cached recipe appears is measurably visible on real devices. The intermediate step is cheaper than full cache-first: consult `OnlineStatus` and skip the request we already know will fail.

### Silently swapping in the fresh recipe on reconnect

- **Tempting because** it needs no new UI and guarantees current content.
- **Lost because** it can change the text under a cook's finger at step 4. Explicit "tap to refresh" costs one tap and never ambushes anyone.
- **Revisit when** we can tell the difference between a cook actively following a recipe and one merely browsing it — then silent refresh is fine for the browsing case.

### A hand-written service worker, or Workbox, instead of ngsw

- **Tempting because** either gives full control over the freshness rules, in code we own and can read.
- **Lost because** ngsw already solves app-shell precaching, asset versioning and the update cycle, and the control we actually wanted turned out to belong in `RecipeGateway` anyway — not in the worker.
- **Revisit when** we need a caching behaviour ngsw's dataGroups genuinely can't express. Note this is a one-way door in practice: migrating an already-installed worker is its own project.

### Testing through a real service worker

- **Tempting because** it's the only thing that proves the actual production stack, ngsw config included.
- **Lost on cost** — slow, flaky around activation timing, painful to debug — for behaviour that is mostly pure logic. Reduced to exactly one E2E case (cold-start offline), with everything else driven through the injectable cache seam.
- **Revisit when** a production incident is caused by ngsw configuration rather than gateway logic. One is bad luck; a second means the config needs automated coverage of its own.

### Offline editing (currently a Non-Goal)

- **Tempting because** users who can read offline will immediately ask to edit offline.
- **Lost because** sync conflict resolution is a project of its own, and there's no demand signal yet.
- **Revisit when** there's an actual demand signal — support requests, or a measurable number of failed write attempts while offline. Worth instrumenting the disabled write controls now so that number exists when the question is asked.
