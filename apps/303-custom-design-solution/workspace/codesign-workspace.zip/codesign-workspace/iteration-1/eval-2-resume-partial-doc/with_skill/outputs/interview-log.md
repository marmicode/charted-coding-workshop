# Interview log — Offline Mode

Resuming `design-docs/offline-mode.md`. Goals and Non-Goals were already written on 2026-09-21, so the interview picks up at **Desired Behavior**.

---

## Desired Behavior — round 1

```json
{
  "questions": [
    {
      "question": "A cook opens a recipe they've already viewed, but the phone has no connection. What do they see?",
      "header": "Stale copy",
      "multiSelect": false,
      "options": [
        {
          "label": "Cached copy + \"offline copy from <date>\" marker",
          "description": "Recipe renders instantly from cache, with a small persistent marker naming when it was saved. The cook is never blocked; they decide whether the age matters. Cost: they may cook from a recipe that changed on the server.",
          "preview": "┌──────────────────────────────┐\n│ Tarte Tatin                  │\n│ ⓘ Offline copy from 21 Sep   │\n│                              │\n│ Ingredients                  │\n│ · 6 apples                   │\n└──────────────────────────────┘"
        },
        {
          "label": "Block until we can verify it's current",
          "description": "Show \"you're offline, we can't confirm this recipe is up to date\" instead of the content. Safest against stale data, but it directly contradicts Goal 1 — reading an already-opened recipe wins over everything else.",
          "preview": "┌──────────────────────────────┐\n│  You're offline              │\n│  We can't confirm this       │\n│  recipe is up to date.       │\n│  [ Retry ]                   │\n└──────────────────────────────┘"
        },
        {
          "label": "Cached copy, no marker at all",
          "description": "Simplest and the least visual noise; the cook can't tell cached from live. Any server-side edit becomes invisibly wrong — wrong oven temp, missing allergen.",
          "preview": "┌──────────────────────────────┐\n│ Tarte Tatin                  │\n│                              │\n│ Ingredients                  │\n│ · 6 apples                   │\n└──────────────────────────────┘"
        },
        {
          "label": "Cached copy + full-width \"may be out of date\" warning",
          "description": "Louder than a marker — a coloured banner above the recipe. Harder to ignore, but it fires on every single offline read and will be tuned out within a week.",
          "preview": "┌──────────────────────────────┐\n│ ⚠ THIS MAY BE OUT OF DATE    │\n├──────────────────────────────┤\n│ Tarte Tatin                  │\n│ Ingredients                  │\n└──────────────────────────────┘"
        }
      ]
    },
    {
      "question": "How does the app tell the cook they're offline at all, beyond the per-recipe marker?",
      "header": "Offline state",
      "multiSelect": false,
      "options": [
        {
          "label": "One app-wide indicator, driven by a single shared signal",
          "description": "One place computes \"are we offline\", every screen reads it. Components never check connectivity themselves, so the state can't disagree between two parts of the screen.",
          "preview": "app shell\n └─ offline bar (reads isOffline())\n     └─ <router-outlet>\n         └─ recipe page (reads isOffline())"
        },
        {
          "label": "Each screen decides for itself",
          "description": "Recipe page, search page and list each render their own notice. More tailored wording per screen, but connectivity logic is duplicated and the screens can drift out of sync with each other."
        },
        {
          "label": "No global indicator — the per-recipe marker is the whole story",
          "description": "Least chrome. But then an empty search result offline is indistinguishable from an empty search result online, which is exactly the blank-screen failure Goal 2 rules out."
        },
        {
          "label": "A toast on each transition",
          "description": "Fires once when the connection drops and once when it returns. Cheap, but a cook who opens the app already offline never sees it — the state isn't readable, only the change is."
        }
      ]
    },
    {
      "question": "Which offline situations should this chapter actually specify? (the ones left out get decided by whoever implements them)",
      "header": "Edge cases",
      "multiSelect": true,
      "options": [
        {
          "label": "Recipe was never opened before, so it isn't cached",
          "description": "The main gap in the promise. Needs its own screen or it falls through to a generic error."
        },
        {
          "label": "App cold-starts with no connection",
          "description": "No network at all for the app shell itself. Determines whether offline mode survives a full app restart or only a live session."
        },
        {
          "label": "Connection comes back while a stale copy is on screen",
          "description": "The moment where we could silently replace what the cook is reading — mid-step. Needs an explicit rule."
        },
        {
          "label": "Cook taps something that writes (favourite, edit) while offline",
          "description": "Non-Goals already rule out offline editing, but the doc doesn't say what the button does when tapped."
        }
      ]
    }
  ]
}
```

**Answer:**
- Stale copy → **Cached copy + "offline copy from <date>" marker**
- Offline state → **One app-wide indicator, driven by a single shared signal**
- Edge cases → **Recipe was never opened before**, **App cold-starts with no connection**, **Connection comes back while a stale copy is on screen**, **Cook taps something that writes while offline** (all four)

---

## Desired Behavior — round 2

```json
{
  "questions": [
    {
      "question": "The cook is reading an \"offline copy from 21 Sep\" and the connection comes back. What happens to what's on screen?",
      "header": "Reconnect",
      "multiSelect": false,
      "options": [
        {
          "label": "Silently refetch and swap in the fresh recipe, drop the marker",
          "description": "Always-current content with zero interaction. But the swap can happen while the cook is on step 4 with wet hands, and the text under their finger changes — which is the 'losing their place' failure Goal 1 exists to prevent."
        },
        {
          "label": "Keep showing the cached copy; swap the marker for \"newer version available — tap to refresh\"",
          "description": "Nothing moves unless the cook asks for it. Costs one tap and means a stale copy can stay on screen indefinitely, but the cook is never ambushed mid-recipe."
        },
        {
          "label": "Reload the page",
          "description": "Simplest to implement, guaranteed fresh. Loses scroll position, any expanded steps, and any checked-off ingredients."
        },
        {
          "label": "Keep the cached copy and the marker until the cook navigates away",
          "description": "No new UI to build. But the recipe stays silently stale for the whole visit even though we know a newer one is available and could tell them."
        }
      ]
    },
    {
      "question": "Offline, the cook taps through to a recipe that was never cached. What do they get?",
      "header": "Not cached",
      "multiSelect": false,
      "options": [
        {
          "label": "A \"not available offline\" screen that links to what IS available",
          "description": "Turns a dead end into a next step — the cook sees the recipes they can still read. Requires knowing what's in the cache in order to list it."
        },
        {
          "label": "Plain \"not available offline\" message with a retry",
          "description": "Honest and cheap to build. The cook is left to guess which other recipes would work."
        },
        {
          "label": "The generic error screen the app already shows for a failed request",
          "description": "Zero new UI. But 'something went wrong' reads as a bug rather than an expected consequence of being offline."
        }
      ]
    }
  ]
}
```

**Answer:**
- Reconnect → **Keep showing the cached copy; swap the marker for "newer version available — tap to refresh"** *(not the recommended silent swap — "never yank the page out from under someone who's cooking")*
- Not cached → **A "not available offline" screen that links to what IS available**

---

## Hand-back menu — after Desired Behavior

```json
{
  "questions": [
    {
      "question": "Desired Behavior is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Design & Implementation Details (Recommended)",
          "description": "Where the cache actually lives (service worker vs. hand-rolled storage), what the seam between app code and cache looks like, how the app-wide offline signal is produced, and where the code sits in the Nx workspace."
        },
        {
          "label": "Revise Desired Behavior",
          "description": "I'll ask what's off and rewrite the chapter before moving on."
        },
        {
          "label": "Pin down what 'offline copy from <date>' actually shows",
          "description": "Absolute date, relative age ('saved 3 days ago'), or a threshold below which we show no marker at all. It's the one piece of user-facing copy the chapter currently hand-waves."
        }
      ]
    }
  ]
}
```

**Answer:** Continue to Design & Implementation Details

---

## Design & Implementation Details — round 1

```json
{
  "questions": [
    {
      "question": "What actually holds the cached recipes?",
      "header": "Storage",
      "multiSelect": false,
      "options": [
        {
          "label": "Service worker + Cache API",
          "description": "The browser's own HTTP-response cache. Handles the app shell and the recipe responses with the same mechanism, survives restarts for free, and needs no schema or migration story. Cost: a service worker in the app's lifecycle, plus an update/activation story."
        },
        {
          "label": "IndexedDB written by hand from app code",
          "description": "Full control over what's stored and its shape; queryable, so 'list what's available offline' is trivial. Cost: we hand-write persistence, versioning and eviction ourselves, and it doesn't cache the app shell — the app still won't cold-start offline."
        },
        {
          "label": "Both — service worker for the shell, IndexedDB for recipe data",
          "description": "Each tool does what it's best at. Cost: two caches, two lifetimes, two ways for them to disagree about what's cached."
        },
        {
          "label": "localStorage",
          "description": "Trivial to write and read. Synchronous, ~5MB, strings only — it will hit its ceiling on recipe images and block the main thread doing it."
        }
      ]
    },
    {
      "question": "Which service worker?",
      "header": "SW flavour",
      "multiSelect": false,
      "options": [
        {
          "label": "@angular/service-worker (ngsw) with an ngsw-config.json data group",
          "description": "First-party, already understands the Angular build, gives the app shell and versioned assets for free, and recipe API responses go in a dataGroup. Cost: caching policy lives in JSON config, not in code we can unit test."
        },
        {
          "label": "A hand-written service worker",
          "description": "Total control over the freshness rules and full visibility in tests. Cost: we own app-shell precaching, asset versioning and update handling — all of which ngsw already solved."
        },
        {
          "label": "Workbox",
          "description": "Rich strategy library and good docs. Cost: a second build pipeline alongside the Angular one, and a dependency that overlaps almost entirely with something already in the Angular package set."
        }
      ]
    },
    {
      "question": "Where's the seam between app code and \"is this fresh or cached\"? (this is what tests will drive)",
      "header": "The seam",
      "multiSelect": false,
      "options": [
        {
          "label": "A RecipeGateway that returns the recipe plus its provenance",
          "description": "Every consumer gets one object that says where it came from and when it was stored. The marker, the refresh prompt and the not-available screen are all plain functions of that value — testable with no service worker in the room.",
          "preview": "type RecipeResult =\n  | { recipe: Recipe; source: 'network' }\n  | { recipe: Recipe; source: 'cache'; cachedAt: Date }\n  | { recipe: null;   source: 'unavailable' };\n\nrecipeGateway.getRecipe(id): Observable<RecipeResult>"
        },
        {
          "label": "An HTTP interceptor that tags responses with a header",
          "description": "Nothing above it changes shape. But provenance rides in a header that every consumer must remember to read and parse, and the 'unavailable' case is still an error to catch.",
          "preview": "// interceptor adds:\n'x-whiskmate-cache': 'hit; ts=1758412800'\n\n// every consumer:\nres.headers.get('x-whiskmate-cache') // …then parse"
        },
        {
          "label": "A separate OfflineCache service the components consult alongside the HTTP call",
          "description": "Cache concerns stay out of the existing recipe service. But each component now orchestrates two calls and decides which wins — the decision gets copy-pasted into every screen.",
          "preview": "const recipe = await recipeService.get(id);\nconst cached = await offlineCache.get(id);\n// …each component decides"
        }
      ]
    }
  ]
}
```

**Answer:**
- Storage → **Service worker + Cache API** *("I'm not hand-rolling IndexedDB for what is fundamentally an HTTP response cache")*
- SW flavour → **@angular/service-worker (ngsw) with a dataGroup**
- The seam → **A RecipeGateway that returns the recipe plus its provenance**

---

## Design & Implementation Details — round 2

```json
{
  "questions": [
    {
      "question": "Where does the single app-wide \"we are offline\" value come from?",
      "header": "Offline signal",
      "multiSelect": false,
      "options": [
        {
          "label": "An injectable wrapping navigator.onLine + the online/offline events, exposed as a signal",
          "description": "One small class, trivially faked in tests, instant to react. Cost: navigator.onLine only knows about the network interface — a captive portal or a dead API server both report 'online'."
        },
        {
          "label": "That, plus: a request served from cache because the network failed also flips it to offline",
          "description": "Catches the captive-portal and dead-server cases that navigator.onLine lies about, because the gateway already knows a fetch failed. Cost: two inputs to one signal, so the rule for going back online needs stating explicitly."
        },
        {
          "label": "Derive it purely from request outcomes, ignore navigator entirely",
          "description": "Only ever reports what actually happened. Cost: on a cold start with no requests in flight yet, the app has no idea, and the indicator can't render until something fails."
        },
        {
          "label": "Poll a health endpoint on an interval",
          "description": "Unambiguous and works everywhere. Cost: a timer running forever in a recipe app, burning battery to answer a question the browser will usually just tell us."
        }
      ]
    },
    {
      "question": "Where does this code live in the workspace?",
      "header": "Code layout",
      "multiSelect": false,
      "options": [
        {
          "label": "A dedicated offline lib, with the recipe gateway staying in the recipe lib",
          "description": "Connectivity and cache-provenance primitives are reusable and have no recipe knowledge; the recipe lib depends on them. Clean dependency direction, one new lib.",
          "preview": "libs/\n  offline/\n    src/lib/\n      online-status.ts        // signal\n      cache-provenance.ts     // types\n      offline-indicator.ts    // app-shell UI\n  recipe/\n    src/lib/\n      recipe-gateway.ts       // returns RecipeResult\n      recipe-page.ts\n      offline-copy-marker.ts"
        },
        {
          "label": "Everything in the existing recipe lib",
          "description": "No new project, no new tags, nothing to wire. But OnlineStatus is app-wide by definition, and putting it behind the recipe lib means every future consumer depends on recipes to know if it's offline.",
          "preview": "libs/\n  recipe/\n    src/lib/\n      online-status.ts\n      recipe-gateway.ts\n      offline-indicator.ts"
        },
        {
          "label": "A single offline lib that owns the gateway too",
          "description": "All offline concerns in one place, easy to find. But the gateway needs the Recipe model and the recipe HTTP client, so the offline lib inherits a dependency on recipes and stops being generic.",
          "preview": "libs/\n  offline/\n    src/lib/\n      online-status.ts\n      recipe-gateway.ts   // needs Recipe…\n      offline-indicator.ts"
        }
      ]
    },
    {
      "question": "What decides that a cached recipe is worth showing rather than refetching?",
      "header": "Freshness",
      "multiSelect": false,
      "options": [
        {
          "label": "Network-first with cache fallback: cache is only read when the network fails",
          "description": "Online cooks always see current data and online behaviour is bit-for-bit unchanged, which the regression surface demands. Cost: offline reads pay a failed request first, so the recipe appears after the fetch gives up."
        },
        {
          "label": "Cache-first, then refresh in the background",
          "description": "Fastest possible render, even online. Cost: online cooks start seeing stale content too, which changes today's behaviour for everyone to serve an offline case."
        },
        {
          "label": "Cache-first while offline, network-first while online, switched by the offline signal",
          "description": "Skips the doomed request when we already know we're offline. Cost: the signal is now load-bearing for correctness, not just for UI — if it's wrong, a connected cook gets stale data."
        }
      ]
    }
  ]
}
```

**Answer:**
- Offline signal → **navigator-based injectable, plus request-outcome input** *(not the recommended navigator-only option — "navigator.onLine lies; the gateway already knows a fetch failed, so let it say so")*
- Code layout → **A dedicated offline lib, with the recipe gateway staying in the recipe lib**
- Freshness → **Network-first with cache fallback**

---

## Hand-back menu — after Design & Implementation Details

```json
{
  "questions": [
    {
      "question": "Design & Implementation Details is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Testing Strategy (Recommended)",
          "description": "Which of the Desired Behavior cases get tests and at what level, what gets faked and at which seam (MSW? a fake OnlineStatus? a fake cache?), whether anything here is worth driving test-first, and what would make these tests brittle."
        },
        {
          "label": "Revise Design & Implementation Details",
          "description": "I'll ask what's off and rewrite the chapter before moving on."
        },
        {
          "label": "Resolve the service worker kill-switch TODO",
          "description": "The chapter ships the SW behind a flag but leaves 'how do we un-register it if it goes bad' open. It's the one decision in here that's hard to make after release rather than before."
        }
      ]
    }
  ]
}
```

**Answer:** Continue to Testing Strategy

---

## Testing Strategy — round 1

```json
{
  "questions": [
    {
      "question": "Which Desired Behavior cases earn a test? (pulled straight from that chapter)",
      "header": "What to test",
      "multiSelect": true,
      "options": [
        {
          "label": "Cached recipe renders with the \"offline copy from <date>\" marker",
          "description": "The headline promise. Component-level with Angular Testing Library: feed the page a cache-sourced RecipeResult, assert the recipe text and the marker are both on screen."
        },
        {
          "label": "Online read shows no marker and no indicator",
          "description": "Guards the regression surface — the thing most likely to break silently as the gateway grows. Same level, network-sourced RecipeResult."
        },
        {
          "label": "Reconnect swaps the marker for \"newer version available\" and changes nothing else",
          "description": "Asserting what did NOT happen (the recipe text is still the old text) is the actual value here."
        },
        {
          "label": "Never-cached recipe offline shows the \"not available offline\" screen, not the error screen",
          "description": "The 'unavailable' branch of RecipeResult. Cheap to test, easy to regress into the generic error handler."
        },
        {
          "label": "Write controls are disabled while offline",
          "description": "Drives OnlineStatus into a component and asserts the disabled state plus the explanation."
        },
        {
          "label": "The gateway falls back to cache when the network fails, and flips OnlineStatus",
          "description": "Gateway-level unit test with MSW erroring the request. This is the one test that covers the network-first policy itself."
        }
      ]
    },
    {
      "question": "What's real in these tests and what's faked?",
      "header": "Fake seams",
      "multiSelect": false,
      "options": [
        {
          "label": "Real gateway + MSW for HTTP + a fake cache behind an injectable; no service worker anywhere",
          "description": "Matches how whiskmate already tests. The gateway's real logic runs, MSW decides whether the network fails, and the cache is a swappable injectable with an in-memory implementation. Cost: nothing here proves ngsw is configured correctly."
        },
        {
          "label": "Real service worker in a real browser via Playwright, offline emulation on",
          "description": "Proves the whole thing end to end, including ngsw-config.json. Cost: slow, flaky around SW activation timing, and painful to debug — for behaviour that is mostly pure logic."
        },
        {
          "label": "Mock RecipeGateway entirely; only test components",
          "description": "Fastest and most stable component tests. Cost: the network-first policy and the cache fallback — the actual risk — are never executed."
        }
      ]
    },
    {
      "question": "Anything here worth driving test-first?",
      "header": "TDD",
      "multiSelect": false,
      "options": [
        {
          "label": "Yes — the gateway's RecipeResult branches, before any service worker exists",
          "description": "The three branches are pure logic with an obvious contract, and writing them first forces the injectable cache seam to exist rather than being retrofitted once the SW is already wired in."
        },
        {
          "label": "Yes — everything, components included",
          "description": "Consistent discipline throughout. Cost: the marker's visual design isn't settled, so component tests written first will churn on wording and structure."
        },
        {
          "label": "No — wire it up, then cover it",
          "description": "Lets the ngsw setup teach us what the gateway actually needs. Cost: the cache seam tends not to appear at all if the SW is wired in first, which is the exact outcome this design is trying to avoid."
        }
      ]
    }
  ]
}
```

**Answer:**
- What to test → **all six**
- Fake seams → **Real gateway + MSW + a fake cache behind an injectable; no service worker anywhere** *("testing service workers directly is miserable — that's the whole reason the cache is behind an injectable")*
- TDD → **Yes — the gateway's RecipeResult branches, before any service worker exists**

---

## Testing Strategy — round 2

```json
{
  "questions": [
    {
      "question": "Is there any test that touches a real service worker, or none at all?",
      "header": "Real SW",
      "multiSelect": false,
      "options": [
        {
          "label": "One manual smoke check on the release checklist, no automated SW test",
          "description": "Someone loads the app, goes offline in devtools, opens a cached recipe. Catches a broken ngsw-config with no CI flakiness. Cost: it's only run when someone remembers."
        },
        {
          "label": "One Playwright test: cold-start offline, open a cached recipe",
          "description": "The single case that genuinely cannot be covered below the browser — the app booting with no network. Cost: one slow, SW-timing-sensitive test to maintain."
        },
        {
          "label": "Nothing — the injectable seam is the contract, ngsw is trusted",
          "description": "Fastest suite. Cost: a typo in ngsw-config.json ships silently and nothing offline works in production."
        }
      ]
    },
    {
      "question": "What would make these tests brittle, and what do we ban up front?",
      "header": "Brittleness",
      "multiSelect": true,
      "options": [
        {
          "label": "Asserting on the literal marker string",
          "description": "\"Offline copy from 21 Sep\" will be reworded. Tests should assert the marker is present and names the cached date, not match the sentence."
        },
        {
          "label": "Real clocks and real dates in cachedAt assertions",
          "description": "A test that formats today's date passes today and fails in a different timezone. Inject the clock, fix the date."
        },
        {
          "label": "Reaching into RecipeGateway internals from component tests",
          "description": "Components should only ever be handed a RecipeResult. A component test that knows about the cache has re-coupled the thing this design decoupled."
        },
        {
          "label": "Waiting on timers or arbitrary sleeps for the online/offline transition",
          "description": "The signal is synchronous by design; tests should set it directly rather than dispatching events and waiting."
        }
      ]
    }
  ]
}
```

**Answer:**
- Real SW → **One Playwright test: cold-start offline, open a cached recipe** *("one, and only one — it's the only thing the injectable can't prove")*
- Brittleness → **all four**

---

## Hand-back menu — after Testing Strategy

```json
{
  "questions": [
    {
      "question": "Testing Strategy is written. Last chapter left.",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Alternatives Considered (Recommended)",
          "description": "Mostly harvesting: every option you turned down in the last three chapters is already an alternative. I'll present them back with why each lost and ask you for the revisit trigger on each one."
        },
        {
          "label": "Revise Testing Strategy",
          "description": "I'll ask what's off and rewrite the chapter before moving on."
        },
        {
          "label": "Decide what the one Playwright test does when it flakes",
          "description": "A single SW-timing-sensitive test with no quarantine policy tends to get deleted on its second red CI run, and then nothing covers ngsw-config at all."
        }
      ]
    }
  ]
}
```

**Answer:** Continue to Alternatives Considered

---

## Alternatives Considered — round 1

```json
{
  "questions": [
    {
      "question": "Here's what you turned down across the last three chapters. Which are real alternatives worth recording, versus never-really-considered?",
      "header": "Harvest",
      "multiSelect": true,
      "options": [
        {
          "label": "IndexedDB written by hand instead of the Cache API",
          "description": "Tempting because it's queryable — 'list what's available offline' would be trivial. Lost because it means hand-writing persistence, versioning and eviction, and it doesn't cache the app shell."
        },
        {
          "label": "Blocking the read until we can verify the recipe is current",
          "description": "Tempting because it's the only option with zero risk of cooking from a stale recipe. Lost because it contradicts Goal 1 outright."
        },
        {
          "label": "Cache-first instead of network-first",
          "description": "Tempting for the instant render, even online. Lost because it changes behaviour for connected cooks to serve disconnected ones."
        },
        {
          "label": "Silently swapping in the fresh recipe on reconnect",
          "description": "Tempting because it needs no new UI and is always current. Lost because it can move the text under a cook's finger mid-recipe."
        },
        {
          "label": "Testing through a real service worker",
          "description": "Tempting because it's the only thing that proves the real stack. Lost on cost — slow, timing-flaky, painful to debug — and reduced to exactly one E2E case."
        },
        {
          "label": "A hand-written service worker, or Workbox, instead of ngsw",
          "description": "Tempting for full control over freshness rules. Lost because ngsw already solves app-shell precaching and asset versioning, and the control we actually wanted now lives in the gateway instead."
        }
      ]
    },
    {
      "question": "Which revisit trigger matters most to write down precisely?",
      "header": "Revisit",
      "multiSelect": true,
      "options": [
        {
          "label": "What would push us from Cache API to IndexedDB",
          "description": "e.g. the moment we need to query the cache — 'show me everything available offline', or offline search."
        },
        {
          "label": "What would push us from network-first to cache-first",
          "description": "e.g. the failed-request delay before a cached recipe renders becoming visible on real devices."
        },
        {
          "label": "What would make offline editing stop being a Non-Goal",
          "description": "The biggest deferred thing in the doc; worth naming the signal that would reopen it."
        },
        {
          "label": "What would make us add more automated service worker tests",
          "description": "e.g. a second production incident caused by ngsw config rather than gateway logic."
        }
      ]
    }
  ]
}
```

**Answer:**
- Harvest → **all six** are real and worth recording
- Revisit → **all four**, with the IndexedDB and offline-editing triggers being the ones that actually matter

---

## Final menu — all six chapters written

```json
{
  "questions": [
    {
      "question": "design-docs/offline-mode.md is complete — all six chapters. What now?",
      "header": "Wrap up",
      "multiSelect": false,
      "options": [
        {
          "label": "Consistency read-through, top to bottom (Recommended)",
          "description": "Check the Goals written on 21 Sep still match the design they produced — in particular whether Goal 2 ('never a spinner that never resolves') survives network-first, which makes offline reads wait on a failed request first."
        },
        {
          "label": "Resolve the one open TODO",
          "description": "The service worker un-register / kill-switch path. It's the only TODO left in the doc and the hardest thing to add after release."
        },
        {
          "label": "Start implementation against the doc",
          "description": "First move would be the gateway's three RecipeResult branches, test-first, before any service worker exists — as the Testing Strategy chapter specifies."
        }
      ]
    }
  ]
}
```

**Answer:** Consistency read-through — *"and yes, check that Goal 2 thing, network-first bugs me slightly."*

**Read-through finding recorded in chat, not silently patched into the doc:** Goal 2 says the app never shows "a spinner that never resolves". Network-first means an offline read waits for the fetch to fail before the cached copy renders — a short spinner that *does* resolve, but a spinner nonetheless. The doc already names the escape hatch (consult `OnlineStatus`, skip the doomed request) in both Design and Alternatives, so the tension is recorded rather than hidden. Left as-is pending a real measurement on-device.
