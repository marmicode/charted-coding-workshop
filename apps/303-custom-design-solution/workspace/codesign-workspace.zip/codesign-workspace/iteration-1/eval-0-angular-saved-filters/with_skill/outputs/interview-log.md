# Interview Log — Saved Filters

Every point where the interview would have called `AskUserQuestion`, in the order it
happened, with the answer Sam gave.

## Round 1 — Goals (before writing the Goals chapter)

```json
{
  "questions": [
    {
      "question": "I've created the skeleton at design-docs/saved-filters.md. Keep that filename?",
      "header": "Doc slug",
      "multiSelect": false,
      "options": [
        {
          "label": "saved-filters.md",
          "description": "Shortest thing you'd actually type into a file search six months from now. Already on disk, so no rename.",
          "preview": "design-docs/\n  saved-filters.md"
        },
        {
          "label": "recipe-search-saved-filters.md",
          "description": "Scopes it to the search feature, which helps if saved filters later show up elsewhere in whiskmate (e.g. saved shopping lists).",
          "preview": "design-docs/\n  recipe-search-saved-filters.md"
        },
        {
          "label": "saved-recipe-filters.md",
          "description": "Middle ground: names the domain without naming the screen.",
          "preview": "design-docs/\n  saved-recipe-filters.md"
        }
      ]
    },
    {
      "question": "Which of these are actually goals for v1? (I'll rank them next.)",
      "header": "Goals",
      "multiSelect": true,
      "options": [
        {
          "label": "Re-apply a frequent filter combo in one click",
          "description": "The core outcome: a combo that takes 3-4 interactions to rebuild becomes one chip click. This is the one that justifies the feature at all.",
          "preview": null
        },
        {
          "label": "Combos survive a reload and a new session",
          "description": "Saved filters are still there tomorrow on the same browser. Buys persistence but commits you to a storage decision and to stale-data handling.",
          "preview": null
        },
        {
          "label": "Sam can demo it at the workshop in 3 weeks",
          "description": "Treats the workshop as a real deadline goal, which legitimises cutting anything that doesn't fit. Makes 'small' a stated goal rather than an excuse later.",
          "preview": null
        },
        {
          "label": "Ships without changing how recipe search works today",
          "description": "Existing filter bar + signal store keep their current behavior; saved filters are additive. Cheap to promise now, expensive to retrofit.",
          "preview": null
        }
      ]
    },
    {
      "question": "What observable signal tells you this worked?",
      "header": "Success signal",
      "multiSelect": false,
      "options": [
        {
          "label": "Sam and the 2 teammates use their own chips daily",
          "description": "Dogfooding as the only metric. No analytics work, no events to add; you just ask the team in a week. Fits a 3-person team.",
          "preview": null
        },
        {
          "label": "A saved-filter click count in analytics",
          "description": "Objective, but means adding tracking you don't have today and waiting for real users. Extra scope before the workshop.",
          "preview": null
        },
        {
          "label": "The workshop demo lands without a live-coding detour",
          "description": "Success = the feature is simple enough to explain on stage in a couple of minutes. Optimises for legibility, not usage.",
          "preview": null
        }
      ]
    },
    {
      "question": "What's forcing this now? This shapes what we're allowed to cut.",
      "header": "Why now",
      "multiSelect": false,
      "options": [
        {
          "label": "Workshop in 3 weeks needs a small, real feature",
          "description": "Deadline is hard and near, scope is the variable. Everything speculative gets deferred by default.",
          "preview": null
        },
        {
          "label": "Users keep rebuilding the same filter combos",
          "description": "User-pain driven, so the bar is 'does it remove the repetition', and the deadline is soft.",
          "preview": null
        },
        {
          "label": "Groundwork for per-user server-side preferences",
          "description": "Treats v1 as step one of a bigger sync story, which pulls the design toward an abstraction you may not want yet.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Doc slug: **saved-filters.md**
- Goals: **Re-apply a frequent filter combo in one click**, **Combos survive a reload and a new session**, **Sam can demo it at the workshop in 3 weeks**, **Ships without changing how recipe search works today**
- Success signal: **Sam and the 2 teammates use their own chips daily**
- Why now: **Workshop in 3 weeks needs a small, real feature** — `Other: both, really. The workshop is the hard date, but I do rebuild "quick vegan dinner" by hand three times a week. What I do NOT want is to treat this as groundwork for the server thing — that's how it gets over-engineered.`

## Round 2 — Goals: the priority order (before writing the Goals chapter)

```json
{
  "questions": [
    {
      "question": "Two weeks in, 'survives a reload' turns out to be fiddlier than expected (stale diet tags, quota, whatever). Which goal gives way?",
      "header": "Conflict order",
      "multiSelect": false,
      "options": [
        {
          "label": "Persistence gives way — ship in-memory chips for the workshop",
          "description": "Deadline wins. Chips work for the session, vanish on reload; persistence lands after. Risk: an in-memory-only version is arguably not the feature.",
          "preview": null
        },
        {
          "label": "The deadline gives way — persistence is the feature",
          "description": "A saved filter that doesn't survive a reload isn't saved. You'd rather demo something smaller-but-real, or demo it late.",
          "preview": null
        },
        {
          "label": "Cut the number of filters a combo can hold instead",
          "description": "Keeps both goals by shrinking what gets saved (e.g. diet tags only). Preserves persistence and the date; costs usefulness.",
          "preview": null
        }
      ]
    },
    {
      "question": "Who is v1 actually for? Determines whether 'per-user' means anything yet.",
      "header": "Audience",
      "multiSelect": false,
      "options": [
        {
          "label": "Whoever is using this browser — no user identity at all",
          "description": "No auth coupling, no user id in the stored payload, no migration when auth arrives. Shared-laptop case is simply out of scope.",
          "preview": null
        },
        {
          "label": "The logged-in user, keyed by user id locally",
          "description": "Stores per-user even though it's local, so the eventual server sync has an obvious key. Costs an auth dependency in the search feature today.",
          "preview": null
        },
        {
          "label": "Your 3-person team specifically, as dogfooders",
          "description": "Design for internal use first, accept rough edges, widen later. Lets you skip empty states and polish.",
          "preview": null
        }
      ]
    },
    {
      "question": "You flagged the stale-diet-tag worry. Is 'a saved filter stays usable when the tags behind it change' a Goal, or just an edge case we handle in Desired Behavior?",
      "header": "Stale tags",
      "multiSelect": false,
      "options": [
        {
          "label": "Edge case, not a goal — handle it in Desired Behavior",
          "description": "Keeps Goals about outcomes and keeps the chapter short. The behavior still gets specified and tested; it just isn't a headline promise.",
          "preview": null
        },
        {
          "label": "Goal: a saved filter never breaks the search page",
          "description": "Elevates robustness to a ranked goal, which means the design has to justify itself against it. Strongest guard against a silent crash, heaviest on scope.",
          "preview": null
        },
        {
          "label": "Neither — just let it throw and fix it if it happens",
          "description": "Cheapest today. Realistically means a broken search page for whoever hits it, possibly on stage.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Conflict order: **Persistence gives way — ship in-memory chips for the workshop** — `Other: order is (1) one-click re-apply, (2) don't regress today's search, (3) persistence, (4) the date. If persistence gets ugly I cut the ugly part of persistence, not the date — but I'm not shipping chips that die on reload either. localStorage is 10 lines; if it's more than that I've done something wrong.`
- Audience: **Whoever is using this browser — no user identity at all**
- Stale tags: **Edge case, not a goal — handle it in Desired Behavior** — `Other: edge case, but I want it written down explicitly, not left implied. It's the thing I'm most likely to get bitten by.`

## Hand-back menu — after the Goals chapter

```json
{
  "questions": [
    {
      "question": "Goals is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Non-Goals (Recommended)",
          "description": "I'll put up candidates for what's out of scope: server sync, sharing, editing a saved combo, a new state library, cross-device. Each with a 'why not' or 'not yet' clause.",
          "preview": null
        },
        {
          "label": "Revise Goals",
          "description": "Tell me what's off and I'll rewrite the chapter before we move on.",
          "preview": null
        },
        {
          "label": "Pin down what 'doesn't regress today's search' actually covers",
          "description": "Goal 2 is the one I wrote thinnest. It could mean 'same URL behavior', 'same store API', or just 'same visible filter bar' — and it's the goal the design will be measured against most.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Continue to Non-Goals** — `Other: goal 2 just means the filter bar and the store keep behaving as they do; I'll hold you to that in Desired Behavior instead of expanding Goals.`

---

## Round 3 — Non-Goals (before writing the Non-Goals chapter)

```json
{
  "questions": [
    {
      "question": "Which of these should the doc explicitly put out of scope for v1?",
      "header": "Out of scope",
      "multiSelect": true,
      "options": [
        {
          "label": "Server-side, per-user saved filters",
          "description": "Deferred, not rejected: you want it eventually. Naming it as 'not yet' stops a reviewer asking for an API-shaped abstraction now.",
          "preview": null
        },
        {
          "label": "Sharing or exporting a saved filter with someone else",
          "description": "A reader will assume this is coming since combos have names. Saying no removes URL-encoding and permissions from the design entirely.",
          "preview": null
        },
        {
          "label": "Any new state management library",
          "description": "The existing signal-based store stays the only state holder. Rejected on principle, not deferred.",
          "preview": null
        },
        {
          "label": "Syncing chips across devices or browsers",
          "description": "Follows from localStorage. Worth stating so 'it's not on my phone' isn't logged as a bug.",
          "preview": null
        }
      ]
    },
    {
      "question": "And which of these editing/management affordances do we leave out?",
      "header": "Management",
      "multiSelect": true,
      "options": [
        {
          "label": "Editing a saved filter's filters in place",
          "description": "Delete + re-save covers it at two clicks. Editing means a form, a dirty state and a second mode in the UI.",
          "preview": null
        },
        {
          "label": "Renaming a saved filter",
          "description": "Same reasoning as editing. Cheap to add later if it actually annoys anyone.",
          "preview": null
        },
        {
          "label": "Reordering / pinning / favouriting chips",
          "description": "Insertion order is good enough at the handful of chips a person will realistically keep.",
          "preview": null
        },
        {
          "label": "Deleting a saved filter",
          "description": "Careful: leaving delete out means a typo'd chip is permanent. I'd keep delete IN scope, but it's your call.",
          "preview": null
        }
      ]
    },
    {
      "question": "Anything about the search itself that people will assume this touches?",
      "header": "Search scope",
      "multiSelect": true,
      "options": [
        {
          "label": "No new filter types (rating, cuisine, author...)",
          "description": "v1 saves exactly today's three filters: ingredient, max cook time, diet tags. Keeps the payload shape closed.",
          "preview": null
        },
        {
          "label": "No search-history or auto-suggested combos",
          "description": "Saving is always explicit and manual. Rules out heuristics, scoring and a background recorder.",
          "preview": null
        },
        {
          "label": "No URL / deep-link representation of a saved filter",
          "description": "Clicking a chip changes the filters, not the address bar contract. Avoids touching routing in the search feature.",
          "preview": null
        },
        {
          "label": "No migration/versioning framework for the stored payload",
          "description": "Risky one: cheap now, but it's exactly the stale-diet-tag scenario. I'd rather handle it with a validate-on-read rule than a framework.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Out of scope: **Server-side, per-user saved filters**, **Sharing or exporting a saved filter with someone else**, **Any new state management library**, **Syncing chips across devices or browsers**
- Management: **Editing a saved filter's filters in place**, **Renaming a saved filter**, **Reordering / pinning / favouriting chips** — (delete stays in scope: `Other: yes, delete is in. A chip I can't remove is worse than no chip.`)
- Search scope: **No new filter types**, **No search-history or auto-suggested combos**, **No URL / deep-link representation of a saved filter**, **No migration/versioning framework for the stored payload** — `Other: agreed on no framework, but I want the validate-on-read rule spelled out as behavior. A version number in the payload is fine, one integer, no migration machinery.`

## Hand-back menu — after the Non-Goals chapter

```json
{
  "questions": [
    {
      "question": "Non-Goals is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Desired Behavior (Recommended)",
          "description": "Observable behavior only: the save flow, what a chip click does to the current filters, delete, and the stale-diet-tag case you flagged — as worked examples.",
          "preview": null
        },
        {
          "label": "Revise Non-Goals",
          "description": "Tell me which line is wrong and I'll rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Add the revisit trigger for the server-side non-goal now",
          "description": "'Not yet' with no trigger tends to mean 'never' or 'next sprint', depending on who reads it. We could name the condition now, or harvest it in Alternatives Considered.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Continue to Desired Behavior** — `Other: keep the revisit triggers for Alternatives Considered, that's where I'd look for them.`

---

## Round 4 — Desired Behavior: happy path (before writing the Desired Behavior chapter)

```json
{
  "questions": [
    {
      "question": "How does a combo get saved? This is the only new input in the feature.",
      "header": "Save flow",
      "multiSelect": false,
      "options": [
        {
          "label": "A 'Save these filters' button in the filter bar reveals an inline name field",
          "description": "Stays on the page, no dialog, no focus trap, no new overlay component. Name field appears next to the button, Enter confirms, Escape cancels.",
          "preview": "Filter bar\n  [ ingredient: tofu ] [ max 30 min ] [ vegan ]        [ Save these filters ]\n\nafter clicking Save:\n  [ Name this combo: ______________ ]  (Enter = save, Esc = cancel)"
        },
        {
          "label": "A modal dialog with a name field and Save/Cancel",
          "description": "Familiar and unambiguous, but it's a dialog: focus management, a11y wiring, and an extra component to test. More ceremony than the action deserves.",
          "preview": "+------------------------------+\n|  Save filter combo           |\n|  Name: [________________]    |\n|            [Cancel] [Save]   |\n+------------------------------+"
        },
        {
          "label": "Auto-name it from the filters, with no prompt at all",
          "description": "One click, zero typing: the chip reads 'tofu · 30 min · vegan'. Cheapest possible flow, but you lose 'quick vegan dinner' — and naming the combo was the point.",
          "preview": "[ tofu · =<30 min · vegan ]  [ chicken · vegan ]"
        }
      ]
    },
    {
      "question": "You click a saved chip while the filter bar already has filters in it. What happens?",
      "header": "Chip click",
      "multiSelect": false,
      "options": [
        {
          "label": "Replace: the saved combo becomes the entire filter state",
          "description": "A chip means 'search like this'. Predictable, trivially explainable, and idempotent — clicking twice does nothing new. Cost: unsaved tweaks are lost silently.",
          "preview": "before: ingredient=chicken, maxCookTime=15\nclick [quick vegan dinner] (tofu, 30min, vegan)\nafter:  ingredient=tofu, maxCookTime=30, dietTags=[vegan]"
        },
        {
          "label": "Merge: the saved filters are applied on top of what's there",
          "description": "Lets you stack a combo onto a current search, but the result depends on invisible prior state, and there's no obvious rule for conflicting scalar values.",
          "preview": "before: ingredient=chicken, maxCookTime=15\nclick [quick vegan dinner] (tofu, 30min, vegan)\nafter:  ingredient=tofu?, maxCookTime=15 or 30?, dietTags=[vegan]"
        },
        {
          "label": "Replace, but the chip stays highlighted as 'active' and clicking it again clears",
          "description": "Toggle semantics give a visible 'you are here' and an escape hatch. Costs an active-state rule: what happens to the highlight when you then hand-edit a filter?",
          "preview": "[quick vegan dinner]* <- active, click again -> all filters cleared"
        }
      ]
    },
    {
      "question": "Which edge cases should the chapter actually specify? (Unpicked ones stay unspecified — I won't invent them.)",
      "header": "Edge cases",
      "multiSelect": true,
      "options": [
        {
          "label": "Saving a name that already exists",
          "description": "Guaranteed to happen with a 3-person team saving 'vegan'. Needs a stated rule: reject, overwrite, or allow duplicates.",
          "preview": null
        },
        {
          "label": "Saving with no filters set at all",
          "description": "An empty combo is a chip that does nothing (or clears everything). One line of specified behavior avoids a confusing no-op chip.",
          "preview": null
        },
        {
          "label": "A saved filter references a diet tag that no longer exists",
          "description": "The one you're worried about. Needs to say what the user sees, not just that it doesn't crash.",
          "preview": null
        },
        {
          "label": "localStorage unavailable or full (private window, quota)",
          "description": "Search must keep working; the question is whether saving fails loudly or the whole chip row disappears.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Save flow: **A 'Save these filters' button in the filter bar reveals an inline name field**
- Chip click: **Replace: the saved combo becomes the entire filter state** — `Other: replace, and no active-highlight. The moment I add 'active' I have to define what un-actives it, and that's a whole state machine for zero benefit.`
- Edge cases: **Saving a name that already exists**, **Saving with no filters set at all**, **A saved filter references a diet tag that no longer exists**, **localStorage unavailable or full**

## Round 5 — Desired Behavior: the edge-case rules (before writing the Desired Behavior chapter)

```json
{
  "questions": [
    {
      "question": "Duplicate name — what's the rule?",
      "header": "Duplicate name",
      "multiSelect": false,
      "options": [
        {
          "label": "Reject with an inline message, keep the name field open",
          "description": "Nothing is silently destroyed, and the user is one edit away from a valid name. Costs an error string in the template.",
          "preview": "[ Name this combo: vegan________ ]\n  ! You already have a combo called \"vegan\""
        },
        {
          "label": "Overwrite the existing combo of that name",
          "description": "Doubles as the missing 'edit' affordance: re-save under the same name to update it. But it destroys data with no confirmation.",
          "preview": null
        },
        {
          "label": "Allow duplicates — names aren't identifiers",
          "description": "Simplest code, zero validation. Leaves you with two identical-looking chips that behave differently, which is the worst outcome for a demo.",
          "preview": null
        }
      ]
    },
    {
      "question": "Saving with no filters set — what's the rule?",
      "header": "Empty combo",
      "multiSelect": false,
      "options": [
        {
          "label": "Save button is disabled while no filter is set",
          "description": "The problem never reaches the storage layer; no error path, no empty chip to define. Disabled-button state is trivially testable.",
          "preview": "Filter bar (no filters)\n  [ Save these filters ]  <- disabled"
        },
        {
          "label": "Allow it; the chip means 'clear all filters'",
          "description": "Arguably useful as a reset shortcut, but it's a second meaning for the same UI element and a non-goal in disguise.",
          "preview": null
        },
        {
          "label": "Allow it and let it be a no-op chip",
          "description": "Least code. Also the most confusing thing on the screen.",
          "preview": null
        }
      ]
    },
    {
      "question": "A saved combo names a diet tag that no longer exists. What does the user see?",
      "header": "Stale tag",
      "multiSelect": false,
      "options": [
        {
          "label": "Drop the unknown tag, apply the rest, tell the user once",
          "description": "The chip still works, which matters most, and the user learns why the results look wider than expected. Requires knowing the current valid tag list at read time.",
          "preview": "click [quick vegan dinner] (tofu, 30min, vegan+paleo)\n  'paleo' no longer exists\n-> applies tofu + 30min + vegan\n-> notice: \"Ignored a filter that no longer exists: paleo\""
        },
        {
          "label": "Drop the unknown tag silently",
          "description": "Cheapest thing that doesn't break. The chip quietly returns different results than its name implies, and nobody finds out.",
          "preview": null
        },
        {
          "label": "Mark the whole chip as broken and refuse to apply it",
          "description": "Most honest, most annoying: one dead tag kills an otherwise fine combo, and now you need a broken-chip visual state.",
          "preview": "[ quick vegan dinner ⚠ ]  <- click does nothing, tooltip explains"
        }
      ]
    },
    {
      "question": "localStorage is unavailable or throws. What's the contract?",
      "header": "Storage failure",
      "multiSelect": false,
      "options": [
        {
          "label": "Search works, chip row is empty, saving shows a one-line failure",
          "description": "Degrades to 'whiskmate without saved filters', which is exactly today's app. The read path swallows, the write path is honest.",
          "preview": null
        },
        {
          "label": "Fall back to in-memory for the session",
          "description": "Chips work until reload, so the feature half-exists. More code and a second storage path to keep in your head.",
          "preview": null
        },
        {
          "label": "Let it throw",
          "description": "A private window becomes a broken search page. Violates goal 2.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Duplicate name: **Reject with an inline message, keep the name field open**
- Empty combo: **Save button is disabled while no filter is set**
- Stale tag: **Drop the unknown tag, apply the rest, tell the user once**
- Storage failure: **Search works, chip row is empty, saving shows a one-line failure**

---

## Round 6 — Desired Behavior: regression surface (same chapter, before writing it)

```json
{
  "questions": [
    {
      "question": "Goal 2 says search doesn't regress. Concretely, what must stay identical?",
      "header": "Must not change",
      "multiSelect": true,
      "options": [
        {
          "label": "Filtering with the bar by hand behaves exactly as today",
          "description": "The baseline promise: same debounce, same request shape, same results, whether or not any combos are saved.",
          "preview": null
        },
        {
          "label": "A user with zero saved filters sees the page as it is today, plus a Save button",
          "description": "No empty-state block, no placeholder row, no layout shift for the majority case.",
          "preview": null
        },
        {
          "label": "Applying a combo produces the same search request as setting those filters by hand",
          "description": "Strong invariant and cheap to test: a chip is nothing more than a shortcut for typing. Rules out a second search code path.",
          "preview": null
        },
        {
          "label": "Deleting a combo never changes the current search results",
          "description": "Delete is bookkeeping, not navigation. Stops a 'why did my results change' surprise.",
          "preview": null
        }
      ]
    },
    {
      "question": "Framing for the chapter?",
      "header": "Framing",
      "multiSelect": false,
      "options": [
        {
          "label": "Given/When/Then per scenario",
          "description": "Hands the Testing Strategy chapter its cases nearly verbatim, since your Vitest + Testing Library tests read that way anyway.",
          "preview": "Given I have filters tofu + 30min + vegan set\nWhen I save them as \"quick vegan dinner\"\nThen a chip labelled \"quick vegan dinner\" appears\nAnd it is still there after a reload"
        },
        {
          "label": "Prose bullets per scenario",
          "description": "Faster to scan, less scaffolding, but the test cases have to be re-derived later.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Must not change: **all four** (`Other: the third one is the important one — a chip must produce the same request as typing. If that's true, everything else follows.`)
- Framing: **Given/When/Then per scenario**

## Hand-back menu — after the Desired Behavior chapter

```json
{
  "questions": [
    {
      "question": "Desired Behavior is written, including the stale-tag scenario. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Design & Implementation Details (Recommended)",
          "description": "Where the code lives in the Nx workspace, the stored payload shape, the persistence seam, and how a chip click gets into the existing signal store. I'll bring the parked localStorage / no-new-state-lib notes back here.",
          "preview": null
        },
        {
          "label": "Revise Desired Behavior",
          "description": "Tell me what's off and I'll rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Nail down where the 'ignored a filter' notice actually appears",
          "description": "I wrote 'a notice once' without saying where it lives or how it's dismissed — it's the vaguest line in the chapter and it will turn into a design decision anyway.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Continue to Design & Implementation Details** — `Other: bring the notice question with you into the design chapter, it's really a "where does this live" question.`

---

## Round 7 — Design & Implementation: placement, payload, persistence seam (before writing the chapter)

```json
{
  "questions": [
    {
      "question": "Where does this code live in the Nx workspace?",
      "header": "Placement",
      "multiSelect": false,
      "options": [
        {
          "label": "Inside the existing recipe-search lib",
          "description": "No new project, no new tags/boundaries, no barrel exports to design. It's three files next to the code they collaborate with, and it moves out easily later if it grows.",
          "preview": "libs/recipe-search/src/lib/\n  recipe-search.ts                  (existing)\n  recipe-filter-bar.ts              (existing, +Save button, +chip row)\n  recipe-search-store.ts            (existing, +applyFilters)\n  saved-filters.ts                  NEW  signal store\n  saved-filter-repository.ts        NEW  localStorage read/write\n  saved-filter.ts                   NEW  types"
        },
        {
          "label": "A new libs/saved-filters lib",
          "description": "Clean boundary and independently testable, but you'd have to decide its public surface and its dependency direction on recipe-search types before writing a line. Premature at three files.",
          "preview": "libs/\n  recipe-search/        (depends on ->)\n  saved-filters/\n    src/index.ts        public API\n    src/lib/..."
        },
        {
          "label": "New lib, split feature/ + data-access/",
          "description": "The 'proper' Nx layering. Two projects, two test setups, two sets of boundaries for a feature that stores a list of objects.",
          "preview": "libs/\n  saved-filters/feature/\n  saved-filters/data-access/"
        }
      ]
    },
    {
      "question": "Stored payload shape?",
      "header": "Payload",
      "multiSelect": false,
      "options": [
        {
          "label": "Versioned envelope wrapping a list, filters reusing the existing filter type",
          "description": "One integer version (no migration machinery, per the non-goal) and the combo holds the exact object the store already takes, so apply is a straight assignment.",
          "preview": "// localStorage key: whiskmate.saved-filters\ntype StoredSavedFilters = {\n  version: 1;\n  items: SavedFilter[];\n};\n\ntype SavedFilter = {\n  id: string;              // crypto.randomUUID()\n  name: string;\n  filters: RecipeFilters;  // existing type: { ingredient?, maxCookTime?, dietTags? }\n};"
        },
        {
          "label": "A bare array, no envelope",
          "description": "Simplest possible JSON, but nowhere to put a version, so the first shape change has to be detected by sniffing the data.",
          "preview": "// localStorage key: whiskmate.saved-filters\ntype Stored = SavedFilter[];"
        },
        {
          "label": "Flatten the filters onto the combo",
          "description": "Fewer levels of nesting to read, but apply becomes a field-by-field mapping that has to be updated every time a filter is added.",
          "preview": "type SavedFilter = {\n  id: string;\n  name: string;\n  ingredient?: string;\n  maxCookTime?: number;\n  dietTags?: string[];\n};"
        }
      ]
    },
    {
      "question": "How abstract is the persistence seam? You want a server version eventually, and you don't want premature abstraction — this is where those two pull against each other.",
      "header": "Storage seam",
      "multiSelect": false,
      "options": [
        {
          "label": "One concrete injectable class, localStorage inside it, no interface",
          "description": "The only file that knows localStorage exists. Swapping in HTTP later means changing this class's body (and making its methods async), which is a contained edit — no interface or token needed today.",
          "preview": "@Injectable({ providedIn: 'root' })\nexport class SavedFilterRepository {\n  getAll(): SavedFilter[] { ... }\n  save(filter: SavedFilter): void { ... }\n  delete(id: string): void { ... }\n}"
        },
        {
          "label": "Interface + InjectionToken + LocalStorage implementation",
          "description": "Ready for a second implementation and trivially fakeable in tests, at the cost of an indirection with exactly one implementor for the foreseeable future.",
          "preview": "export interface SavedFilterRepository { ... }\nexport const SAVED_FILTER_REPOSITORY =\n  new InjectionToken<SavedFilterRepository>('...');\n\nexport class LocalStorageSavedFilterRepository\n  implements SavedFilterRepository { ... }"
        },
        {
          "label": "No repository — localStorage calls inline in the signal store",
          "description": "Fewest files. But storage and state get tangled, and the eventual server move touches the store instead of one leaf file.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Placement: **Inside the existing recipe-search lib**
- Payload: **Versioned envelope wrapping a list, filters reusing the existing filter type**
- Storage seam: **One concrete injectable class, localStorage inside it, no interface** — `Other: yes. And when the server version comes, the methods go async and I'll deal with it then — that's a 20-minute change, not a reason to build a port today.`

## Round 8 — Design & Implementation: state ownership, sanitising, the notice (same chapter, before writing it)

```json
{
  "questions": [
    {
      "question": "Who owns the list of saved combos in memory, given no new state library?",
      "header": "State owner",
      "multiSelect": false,
      "options": [
        {
          "label": "A small SavedFilters signal service, separate from the search store",
          "description": "The search store keeps its current shape (goal 2), and the two talk through one call: the chip click hands filters to the search store's existing setter. Cost: one more injectable.",
          "preview": "@Injectable({ providedIn: 'root' })\nexport class SavedFilters {\n  #repository = inject(SavedFilterRepository);\n  #items = signal<SavedFilter[]>(this.#repository.getAll());\n  items = this.#items.asReadonly();\n\n  save(name: string, filters: RecipeFilters): void\n  delete(id: string): void\n}\n\n// chip click, in the component:\n// searchStore.setFilters(sanitized)"
        },
        {
          "label": "Add saved-filter state to the existing recipe search store",
          "description": "One place for all search state and no cross-service call. But it grows the store you promised not to disturb, and mixes 'what am I searching' with 'what did I bookmark'.",
          "preview": null
        },
        {
          "label": "No service — component signal, repository is the source of truth",
          "description": "Fewest moving parts, and fine while exactly one component shows chips. Re-reads storage on every mount and has nowhere to put the save/delete rules.",
          "preview": null
        }
      ]
    },
    {
      "question": "Where does the stale-value sanitising happen? Desired Behavior says storage keeps the dropped value for next time.",
      "header": "Sanitising",
      "multiSelect": false,
      "options": [
        {
          "label": "On apply, against the diet tags the filter bar already knows",
          "description": "Storage is never rewritten, so a tag that comes back later just starts working again. The rule lives on the path that actually needs it, and is observable through the component.",
          "preview": "// on chip click\nconst { filters, droppedDietTags } =\n  sanitizeFilters(savedFilter.filters, knownDietTags());\nsearchStore.setFilters(filters);\nif (droppedDietTags.length) notice.set(droppedDietTags);"
        },
        {
          "label": "On read in the repository, rewriting storage",
          "description": "Storage self-heals and every consumer gets clean data, but the dropped tag is gone forever and the repository now needs to know the valid tag list.",
          "preview": null
        },
        {
          "label": "On write only",
          "description": "Cheapest, and wrong: the tag list changes after the combo was saved, which is the whole scenario.",
          "preview": null
        }
      ]
    },
    {
      "question": "Where does the 'Ignored a filter that no longer exists: paleo' notice live? (Carried over from the last chapter.)",
      "header": "Notice",
      "multiSelect": false,
      "options": [
        {
          "label": "An inline message in the filter bar, cleared on the next filter change",
          "description": "No toast/snackbar dependency, no timers, and it's queryable by text in a Testing Library test. Lives and dies with the filter bar it's talking about.",
          "preview": "Filter bar\n  [ tofu ] [ 30 min ] [ vegan ]\n  i Ignored a filter that no longer exists: paleo"
        },
        {
          "label": "A toast / snackbar",
          "description": "More visible and conventional, but pulls in a notification service and timing into your tests for one rare message.",
          "preview": null
        },
        {
          "label": "Console warning only",
          "description": "Free, and invisible to the person whose results just silently widened.",
          "preview": null
        }
      ]
    },
    {
      "question": "Anything new getting added to package.json?",
      "header": "Dependencies",
      "multiSelect": false,
      "options": [
        {
          "label": "Nothing new — crypto.randomUUID + JSON + localStorage",
          "description": "Zero dependency delta. ids come from crypto.randomUUID(), which is available in every browser you support and in jsdom under Vitest.",
          "preview": null
        },
        {
          "label": "A tiny schema validator (zod/valibot) for the stored payload",
          "description": "Turns validate-on-read into a declarative schema, at the cost of a runtime dependency and a bundle bump for one parse call.",
          "preview": null
        },
        {
          "label": "An Angular signals-persistence helper from npm",
          "description": "Less code to write, but it's a dependency owning your storage format, and it's the kind of magic that's awkward to explain on stage.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- State owner: **A small SavedFilters signal service, separate from the search store**
- Sanitising: **On apply, against the diet tags the filter bar already knows**
- Notice: **An inline message in the filter bar, cleared on the next filter change**
- Dependencies: **Nothing new — crypto.randomUUID + JSON + localStorage**

## Hand-back menu — after the Design & Implementation Details chapter

```json
{
  "questions": [
    {
      "question": "Design & Implementation Details is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Testing Strategy (Recommended)",
          "description": "I'll put the Desired Behavior scenarios up as candidate tests and we decide the level for each, what's real vs faked, and where the seams sit. Your parked 'through the component, real store, faked HTTP' note lands here.",
          "preview": null
        },
        {
          "label": "Revise Design & Implementation Details",
          "description": "Tell me which decision is wrong and I'll rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Work out how knownDietTags() reaches sanitizeFilters",
          "description": "I wrote it as if the filter bar already has the diet tag list to hand. If that list comes from HTTP, the sanitise path has an async dependency and the chapter is quietly incomplete.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Work out how knownDietTags() reaches sanitizeFilters** — `Other: good catch, the filter bar does fetch the diet tags, they're not a static union. Sort that out and then go to Testing Strategy.`

---

## Round 9 — Design follow-up: the diet tag source (revising the Design chapter)

```json
{
  "questions": [
    {
      "question": "The diet tag list is fetched. What does a chip click do if the tags haven't arrived yet?",
      "header": "Tags not loaded",
      "multiSelect": false,
      "options": [
        {
          "label": "Apply the combo unsanitised when the tag list isn't loaded yet",
          "description": "The chip always works and never waits. An unknown tag then reaches the search request and simply matches nothing — same as today if you typed it. No loading state, no disabled chips.",
          "preview": "knownDietTags() === undefined  (not loaded)\n-> apply savedFilter.filters as-is, no notice\n\nknownDietTags() === ['vegan','keto']  (loaded)\n-> sanitize, drop unknown, show notice"
        },
        {
          "label": "Disable the chips until the tag list has loaded",
          "description": "Guarantees sanitising always runs, at the cost of a disabled state on the fastest interaction in the feature — and a race that's annoying to test.",
          "preview": null
        },
        {
          "label": "Await the tag list on click, then apply",
          "description": "Correct in every case and introduces async into the click handler plus a pending state. Most machinery for the rarest scenario.",
          "preview": null
        }
      ]
    },
    {
      "question": "Does the search request break if an unknown tag does slip through?",
      "header": "Unknown tag at the API",
      "multiSelect": false,
      "options": [
        {
          "label": "No — it's just a tag that matches no recipes; results come back empty",
          "description": "Then 'apply unsanitised when tags aren't loaded' is safe and we can say so explicitly in the doc.",
          "preview": null
        },
        {
          "label": "Unsure — needs checking against the API before we rely on it",
          "description": "I'd write it into the doc as an open item rather than assume it, since the whole stale-tag design leans on it.",
          "preview": null
        },
        {
          "label": "Yes, it 400s",
          "description": "Then sanitising can't be best-effort and we need one of the stricter options above.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Tags not loaded: **Apply the combo unsanitised when the tag list isn't loaded yet**
- Unknown tag at the API: **No — it's just a tag that matches no recipes; results come back empty** — `Other: I'm fairly sure it's a plain filter param and unknown values just narrow to nothing, but mark it as needing a check. If it 400s the whole approach changes.`

## Hand-back menu — after revising Design & Implementation Details

```json
{
  "questions": [
    {
      "question": "Added the best-effort sanitising rule plus a TODO to confirm the API's behavior on an unknown tag. Next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Testing Strategy (Recommended)",
          "description": "Candidate tests from the Desired Behavior scenarios, the level for each, and which seams are real vs faked.",
          "preview": null
        },
        {
          "label": "Revise Design & Implementation Details again",
          "description": "If the best-effort rule as written still isn't right.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Continue to Testing Strategy**

---

## Round 10 — Testing Strategy (before writing the Testing Strategy chapter)

```json
{
  "questions": [
    {
      "question": "Which of the Desired Behavior scenarios get a test, and at which level? (Pick everything that should be covered through the filter bar component.)",
      "header": "Component tests",
      "multiSelect": true,
      "options": [
        {
          "label": "Save a combo -> chip appears; it's still there after a reload",
          "description": "The headline scenario, and the only one that proves the persistence goal. Needs a way to simulate a reload (next question).",
          "preview": null
        },
        {
          "label": "Click a chip -> the search request matches what typing those filters produces",
          "description": "Directly asserts the load-bearing invariant: same request, not a second path. With MSW you can compare the intercepted request from both routes.",
          "preview": null
        },
        {
          "label": "Duplicate name -> nothing saved, message shown, field stays open",
          "description": "Cheap, and it's the one a user hits weekly.",
          "preview": null
        },
        {
          "label": "Stale diet tag -> remaining filters applied + notice shown, storage untouched",
          "description": "The scenario you're most worried about, and the only one with non-obvious logic behind it.",
          "preview": null
        }
      ]
    },
    {
      "question": "What does a component test talk to for real, and what gets faked?",
      "header": "Seams",
      "multiSelect": false,
      "options": [
        {
          "label": "Real store, real service, real repository, real jsdom localStorage; only HTTP faked with MSW",
          "description": "Matches how you already test: the only fake is at the network edge. Every layer you'd actually ship is exercised, and the stored JSON is real. Needs localStorage cleared between tests.",
          "preview": "beforeEach: localStorage.clear()\nMSW: GET /recipes, GET /diet-tags\nEverything else: the real thing"
        },
        {
          "label": "Fake the repository through DI, keep the rest real",
          "description": "No global state to reset and slightly faster, but then nothing verifies that the thing you ship actually persists — the one behavior the repository exists for.",
          "preview": null
        },
        {
          "label": "Stub the global localStorage object with an in-memory shim",
          "description": "Control over throw/quota cases, at the price of testing against a shim whose behavior you wrote.",
          "preview": null
        }
      ]
    },
    {
      "question": "How do we simulate 'after a reload'? Note SavedFilters is providedIn: 'root' and seeds its signal once, so re-rendering inside the same TestBed would NOT exercise the read path.",
      "header": "Reload",
      "multiSelect": false,
      "options": [
        {
          "label": "A fresh TestBed/render in a second test, with localStorage left populated",
          "description": "Closest honest analogue of a reload: new injector, service re-seeds from storage. Requires the two tests to share storage deliberately, or an explicit arrange step that writes storage first.",
          "preview": "it('shows combos saved in a previous session', async () => {\n  // arrange: storage populated as a previous session left it\n  localStorage.setItem('whiskmate.saved-filters', JSON.stringify({ version: 1, items: [...] }));\n  await render(RecipeSearch, ...);   // fresh injector\n  expect(screen.getByRole('button', { name: 'quick vegan dinner' }))...\n});"
        },
        {
          "label": "Re-render the component in the same TestBed",
          "description": "Reads naturally as 'reload' but proves nothing here, because the root-scoped signal already holds the items. A test that passes for the wrong reason.",
          "preview": null
        },
        {
          "label": "Skip it; unit-test the repository round-trip instead",
          "description": "Covers the read/write pair directly, but the test you'd point at to prove the goal is now about a class rather than about the feature.",
          "preview": null
        }
      ]
    },
    {
      "question": "Anything worth driving test-first, and anything that gets a test below the component level?",
      "header": "Test-first",
      "multiSelect": true,
      "options": [
        {
          "label": "sanitizeFilters: test-first, as a pure-function test",
          "description": "It's pure, it has the branchiest logic in the feature (unknown tag, all tags unknown, tags not loaded), and the cases are exactly the ones you can't easily enumerate through the UI.",
          "preview": null
        },
        {
          "label": "Repository: a couple of direct tests for corrupt/unknown-version/throwing storage",
          "description": "Reaching those states through the component means hand-writing broken JSON into storage anyway, so the direct test is honest here rather than a shortcut.",
          "preview": null
        },
        {
          "label": "Drive the whole save-and-reapply flow test-first through the component",
          "description": "Test-first at the behavior level for the headline scenario, which also forces the component API early.",
          "preview": null
        },
        {
          "label": "No unit tests on SavedFilters (the signal service) in isolation",
          "description": "It's a thin wrapper over the repository; its behavior is already covered through the component. Testing it separately mostly locks in its shape.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Component tests: **all four**
- Seams: **Real store, real service, real repository, real jsdom localStorage; only HTTP faked with MSW**
- Reload: **A fresh TestBed/render in a second test, with localStorage left populated** — `Other: with an explicit arrange step, not implicit test-order coupling. Tests that depend on the previous test having run are the worst thing in a suite.`
- Test-first: **sanitizeFilters test-first**, **Repository: direct tests for corrupt/unknown-version/throwing storage**, **Drive the whole save-and-reapply flow test-first through the component**, **No unit tests on SavedFilters in isolation**

## Round 11 — Testing Strategy: brittleness rules (same chapter, before writing it)

```json
{
  "questions": [
    {
      "question": "What would make these tests brittle? Pick the rules worth writing into the doc.",
      "header": "Brittleness",
      "multiSelect": true,
      "options": [
        {
          "label": "Don't assert on the stored JSON shape from component tests",
          "description": "Persistence is asserted by 'the chip is there after a reload', not by reading the key. Otherwise the payload shape becomes untouchable.",
          "preview": null
        },
        {
          "label": "Query chips by accessible role and name, never by test id or CSS class",
          "description": "A chip is a button labelled with the combo name; that's the contract. Lets the markup change freely.",
          "preview": null
        },
        {
          "label": "Assert the search request, not the store's internal state",
          "description": "MSW already sees the request. Asserting store fields couples the tests to a store you promised not to reshape.",
          "preview": null
        },
        {
          "label": "One place builds the fake recipe/diet-tag data",
          "description": "Shared builders so adding a filter type doesn't touch every test file.",
          "preview": null
        }
      ]
    },
    {
      "question": "Storage-failure case (private window / quota) — test it or not?",
      "header": "Storage failure",
      "multiSelect": false,
      "options": [
        {
          "label": "One repository-level test per direction (read throws, write throws)",
          "description": "Cheap and targeted: make the storage call throw, assert [] on read and a thrown-and-handled path on write. The component-level message gets covered by the write test plus one filter-bar test.",
          "preview": null
        },
        {
          "label": "One component test with localStorage made to throw",
          "description": "Tests the user-visible promise ('search still works, chip row empty') at the level that matters, but needs a global stub in a suite that otherwise uses real storage.",
          "preview": null
        },
        {
          "label": "Don't test it; it's specified but rare",
          "description": "Honest about the deadline. Risk: the private-window case is the demo failure mode nobody rehearses.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Brittleness: **all four**
- Storage failure: **One repository-level test per direction (read throws, write throws)** — `Other: plus one component test for the empty chip row, since that's the promise I actually care about. Skip the component test for the write-failure message if we're short on time before the workshop.`

## Hand-back menu — after the Testing Strategy chapter

```json
{
  "questions": [
    {
      "question": "Testing Strategy is written. Where next?",
      "header": "Next step",
      "multiSelect": false,
      "options": [
        {
          "label": "Continue to Alternatives Considered (Recommended)",
          "description": "I'll hand back every option you didn't pick over the last five chapters as candidates, and we add the revisit trigger for each one that survives.",
          "preview": null
        },
        {
          "label": "Revise Testing Strategy",
          "description": "Tell me what's off and I'll rewrite the chapter.",
          "preview": null
        },
        {
          "label": "Decide whether the 'same request as typing' test is one test or two",
          "description": "Comparing two intercepted requests in a single test is neat but a bit clever; two tests asserting the same expected request is duller and more readable. Small, but it's the test you'll point at most.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Continue to Alternatives Considered** — `Other: two tests asserting the same expected request object, I'll note that when I write it. Not worth a chapter revision.`

---

## Round 12 — Alternatives Considered (before writing the Alternatives chapter)

```json
{
  "questions": [
    {
      "question": "These are the forks you decided against along the way. Which are worth recording as real alternatives? (The rest I'll leave out rather than pad the chapter.)",
      "header": "Alternatives",
      "multiSelect": true,
      "options": [
        {
          "label": "Server-side, per-user saved filters in v1",
          "description": "The big one: it's the eventual destination, so the doc should say why not now and what flips it.",
          "preview": null
        },
        {
          "label": "A dedicated libs/saved-filters Nx lib (or feature/data-access split)",
          "description": "The 'proper' structural choice you turned down. Worth recording so the next reader doesn't reopen it from scratch.",
          "preview": null
        },
        {
          "label": "Interface + InjectionToken for the repository",
          "description": "The premature-abstraction fork, and the one most likely to come up in review.",
          "preview": null
        },
        {
          "label": "Merge-on-click and/or toggleable active chips",
          "description": "The main behavioral fork. 'Replace' is a decision people will question the first time they use it.",
          "preview": null
        }
      ]
    },
    {
      "question": "And these smaller ones?",
      "header": "More alternatives",
      "multiSelect": true,
      "options": [
        {
          "label": "Auto-naming chips from the filters, with no prompt",
          "description": "Cheapest possible save flow, rejected because naming the combo was the point.",
          "preview": null
        },
        {
          "label": "Overwrite on duplicate name (re-save as the edit affordance)",
          "description": "Rejected, but it's also the cheapest future answer to 'I want to edit a combo'. Worth recording with that link.",
          "preview": null
        },
        {
          "label": "zod/valibot for validating the stored payload",
          "description": "Rejected as a dependency for one parse, but it's the obvious answer if the payload grows.",
          "preview": null
        },
        {
          "label": "Faking the repository in component tests",
          "description": "Rejected because then nothing proves persistence. Worth a line so nobody 'simplifies' the suite that way later.",
          "preview": null
        }
      ]
    },
    {
      "question": "What flips the server-side decision? This is the line that makes the doc still useful in a year.",
      "header": "Server trigger",
      "multiSelect": false,
      "options": [
        {
          "label": "The first real request to see the same combos on a second device",
          "description": "User-demand driven and unambiguous: one person asking for it on their phone is the signal. Nothing about code quality triggers it.",
          "preview": null
        },
        {
          "label": "When whiskmate gets real user accounts",
          "description": "Ties it to an infrastructure milestone rather than demand — you'd build it because you can, which is the trap you named in Goals.",
          "preview": null
        },
        {
          "label": "When saved filters are used daily by the team for a month",
          "description": "Proof-of-value driven, but usage on one device says nothing about needing a second one.",
          "preview": null
        }
      ]
    },
    {
      "question": "And what would make you revisit the structural choices (own lib / repository interface)?",
      "header": "Structure trigger",
      "multiSelect": false,
      "options": [
        {
          "label": "A second consumer of saved filters outside recipe search",
          "description": "The honest trigger for both: a second caller is what an extracted lib and an interface are actually for. Until then they'd have one user each.",
          "preview": null
        },
        {
          "label": "When the files in recipe-search pass some count",
          "description": "A tidiness trigger. Easy to measure, and a bad reason to move code.",
          "preview": null
        },
        {
          "label": "When the repository gains a second implementation (i.e. the server one)",
          "description": "Narrower: covers the interface but says nothing about the lib. Also, going async is a change of shape, not a second impl sitting alongside.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:**
- Alternatives: **all four**
- More alternatives: **all four**
- Server trigger: **The first real request to see the same combos on a second device**
- Structure trigger: **A second consumer of saved filters outside recipe search** — `Other: and honestly if the server version arrives at the same time as a second consumer, that's the moment to do both properly. Not before.`

## Final menu — after the Alternatives Considered chapter (doc complete)

```json
{
  "questions": [
    {
      "question": "All six chapters are written: design-docs/saved-filters.md. What now?",
      "header": "Wrap-up",
      "multiSelect": false,
      "options": [
        {
          "label": "Consistency read-through, top to bottom (Recommended)",
          "description": "I read the whole thing as one document and flag where chapters contradict each other — usually Goals that no longer match the design they produced. Cheap now, expensive after you've written code against it.",
          "preview": null
        },
        {
          "label": "Start implementing against the doc",
          "description": "I'd begin with sanitizeFilters test-first, then the save-and-reapply flow through the filter bar, per the Testing Strategy chapter.",
          "preview": null
        },
        {
          "label": "Leave it here",
          "description": "The doc is on disk; you review it yourself before the team sees it.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Consistency read-through, top to bottom** — `Other: read it through, but don't start coding — I want to put this in front of the other two devs first.`

## Consistency read-through — findings, then the close-out menu

Three inconsistencies found and fixed in place (no new decisions invented):

1. **Non-Goals** said stale data is handled by a "validate-on-read rule" — but the Design chapter
   later decided sanitising happens **on apply**, and that storage is never rewritten. Reworded to
   "drop-the-bad-value-when-applying".
2. **Desired Behavior** said the combo "keeps its remaining filters for next time", which understates
   the actual decision: the combo keeps *all* its filters including the dropped tag, so it recovers
   if the tag comes back. Corrected, and "doesn't validate on read" → "isn't valid at the moment it's
   applied".
3. The **best-effort rule** (tag list not loaded → apply as saved, no notice) was decided in round 9
   but lived only in the Design chapter, even though it's observable behavior. Added to Desired
   Behavior.

Still open, deliberately: the `TODO` confirming the search API treats an unknown diet tag as a plain
filter value rather than a 400.

```json
{
  "questions": [
    {
      "question": "Read-through done, three inconsistencies fixed, one TODO left standing. Anything else before you take it to the other two devs?",
      "header": "Close out",
      "multiSelect": false,
      "options": [
        {
          "label": "Nothing — the doc is ready to share (Recommended)",
          "description": "design-docs/saved-filters.md, six chapters, one open TODO clearly marked. Status stays Draft until the team has read it.",
          "preview": null
        },
        {
          "label": "Check the API's unknown-diet-tag behavior now and close the TODO",
          "description": "It's the one assumption the stale-tag design rests on. I'd need to look at the recipe search endpoint and its MSW handlers.",
          "preview": null
        },
        {
          "label": "Start implementing against the doc",
          "description": "sanitizeFilters test-first, then the save-and-reapply flow through the filter bar.",
          "preview": null
        }
      ]
    }
  ]
}
```

**Answer:** **Nothing — the doc is ready to share** — `Other: I'll check the API thing myself when I open the code, and I'm not starting implementation until the other two have read this.`
