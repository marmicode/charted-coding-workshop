# Parked (raised early, belongs in a later chapter)

- **localStorage as the store** — raised during Goals. Parked for *Design & Implementation Details*.
- **"no new state management library"** — raised during Goals. Parked; lands as a Non-Goal and again
  as a design constraint.
- **Stale diet tag on a saved filter** — raised during Goals; agreed it's an edge case, not a goal.
  Parked for *Desired Behavior*, must be written explicitly.
- **"testing through the component, not the store in isolation"** — parked for *Testing Strategy*.
