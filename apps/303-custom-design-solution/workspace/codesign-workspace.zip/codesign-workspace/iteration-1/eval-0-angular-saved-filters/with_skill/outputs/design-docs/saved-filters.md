# Saved Filters

> Status: Draft · 2026-09-24

## Goals

Ranked. When two of these collide, the higher one wins.

1. **You re-apply a frequent filter combo in one click.** A combo that takes three or four
   interactions to rebuild (ingredient + max cook time + a diet tag) becomes one chip click.
2. **Recipe search keeps working exactly as it does today.** Saved filters are additive: the
   filter bar and the signal-based store keep their current behavior, and nothing about
   unsaved filtering changes.
3. **A saved combo survives a reload and a new session.** Same browser, next day, the chip is
   still there. Chips that die on reload are not "saved filters" and don't count as shipping this.
4. **It's demoable at the workshop in 3 weeks.** A real, small, explainable feature.

**When they conflict:** if persistence turns out ugly, cut the ugly *part* of persistence —
not the deadline, and not persistence itself. (Sam: "localStorage is 10 lines; if it's more
than that I've done something wrong.")

**Who it's for:** whoever is using this browser. No user identity in v1 — no auth dependency,
no user id in the stored payload.

**Success signal:** Sam and the two other devs are clicking their own chips daily a week after
it ships. No analytics, no events; we just ask.

**What's forcing it now:** the workshop is the hard date, and the "quick vegan dinner" combo
genuinely gets rebuilt by hand several times a week. Explicitly *not* forced by the future
server-side sync — that framing is how this gets over-engineered.

## Non-Goals

**Deferred — we want these, just not now**

- **Server-side, per-user saved filters.** Not yet. localStorage is plenty for v1; the server
  version waits until saved filters have proven they get used, and until there's a real reason
  to need them on a second device.
- **Syncing chips across devices or browsers.** Not yet — falls straight out of localStorage.
  "It's not on my phone" is expected behavior in v1, not a bug.

**Out of scope — a reader would assume these are in, and they aren't**

- **Sharing or exporting a saved filter with someone else.** Combos have names, so people will
  ask. Saying no keeps URL encoding and permissions out of the design entirely.
- **No URL or deep-link representation.** Clicking a chip changes the filters, not the address
  bar contract. Routing in the search feature stays untouched.
- **No new filter types.** v1 saves exactly today's three: ingredient, max cook time, diet tags.
- **No editing a saved filter's filters in place, and no renaming.** Delete + save again covers
  it in two clicks; editing means a form, a dirty state and a second UI mode.
- **No reordering, pinning or favouriting chips.** Insertion order is fine at the handful of
  chips a person realistically keeps.

**Rejected on principle**

- **Any new state management library.** The existing signal-based search store stays the only
  state holder. This is a "no", not a "later".
- **No search-history or auto-suggested combos.** Saving is always explicit and manual — no
  heuristics, no scoring, no background recorder.
- **No migration or versioning framework for the stored payload.** One integer version field in
  the stored JSON is fine; migration machinery is not. Bad or outdated stored data gets handled
  by a drop-the-bad-value-when-applying rule, specified as behavior in the next chapter.

**Still in scope, to be clear:** deleting a saved filter. A chip you can't remove is worse than
no chip.

## Desired Behavior

Observable from the outside. Filters in play are today's three: ingredient, max cook time,
diet tags.

### Saving a combo (happy path)

```
Given the filter bar has ingredient "tofu", max cook time 30 min and diet tag "vegan"
When I click "Save these filters"
Then an inline name field appears in the filter bar
When I type "quick vegan dinner" and press Enter
Then a chip labelled "quick vegan dinner" appears in the chip row
And the field closes
And the chip is still there after a reload
```

- Escape (or clicking away) cancels the name field and saves nothing.
- The chip row sits in the filter bar area, chips in the order they were saved.

### Applying a combo

```
Given the filter bar has ingredient "chicken" and max cook time 15 min
And I have a saved combo "quick vegan dinner" (tofu, 30 min, vegan)
When I click the "quick vegan dinner" chip
Then the filters become exactly tofu + 30 min + vegan
And the results update to that search
```

- **Replace, not merge.** A chip means "search like this"; the combo becomes the entire filter
  state. Clicking it twice does nothing the second time.
- **No active/selected chip state.** Chips are buttons, not a toggle group — defining what
  "un-selects" a chip after a hand edit is a state machine we don't need.

### Deleting a combo

```
Given I have a saved combo "quick vegan dinner"
When I delete it from its chip
Then the chip disappears
And it is still gone after a reload
And the current search results do not change
```

### Edge cases

**Duplicate name** — reject it.

```
Given I already have a combo called "vegan"
When I try to save a new combo named "vegan"
Then nothing is saved
And the name field stays open with: You already have a combo called "vegan"
```

**Nothing to save** — the "Save these filters" button is disabled while no filter is set. No
empty combo can be created, so there is no empty-chip behavior to define.

**A combo references a diet tag that no longer exists** — the chip still works.

```
Given a saved combo "quick vegan dinner" holding diet tags "vegan" and "paleo"
And "paleo" is no longer a diet tag in whiskmate
When I click the chip
Then the search applies tofu + 30 min + vegan
And I see a notice once: Ignored a filter that no longer exists: paleo
And the saved combo is unchanged - "paleo" is still in it, so it works again if the tag comes back
```

The same rule covers any stored filter value that isn't valid at the moment it's applied: drop the
offending value, apply the rest, say so once. Never throw, never discard the whole combo, never
rewrite what was saved.

This check is best-effort: whiskmate fetches the diet tag list, and if it hasn't arrived when a
chip is clicked, the combo is applied exactly as saved with no notice. A chip never waits and is
never disabled.

**Storage unavailable or full** (private window, quota) — whiskmate degrades to exactly today's
app.

- Reading fails → the chip row is simply empty. Search is unaffected.
- Saving fails → a one-line failure message where the name field was. Nothing else breaks.

### Must not change

- Filtering by hand behaves exactly as today — same debounce, same request, same results,
  whether or not any combos are saved.
- With zero saved combos the page looks like it does today, plus the "Save these filters"
  button. No empty-state block, no placeholder row, no layout shift.
- **Applying a combo produces the same search request as setting those filters by hand.** This
  is the load-bearing invariant: a chip is a shortcut for typing, never a second search path.
- Deleting a combo never changes the current results.

## Design & Implementation Details

### Where the code lives

Inside the existing `recipe-search` lib. No new Nx project: three new files next to the code
they collaborate with, no new tags, boundaries or public API to design. It moves out to its own
lib later if it ever grows enough to deserve one.

```
libs/recipe-search/src/lib/
  recipe-search.ts                  (existing)
  recipe-filter-bar.ts              (existing — + Save button, + chip row, + notice)
  recipe-search-store.ts            (existing — unchanged shape, existing filter setter reused)
  saved-filters.ts                  NEW — signal service holding the list
  saved-filter-repository.ts        NEW — the only file that knows about localStorage
  saved-filter.ts                   NEW — types + sanitizeFilters()
```

### Data model

```ts
// localStorage key: whiskmate.saved-filters
type StoredSavedFilters = {
  version: 1;
  items: SavedFilter[];
};

type SavedFilter = {
  id: string;              // crypto.randomUUID()
  name: string;
  filters: RecipeFilters;  // the existing type: { ingredient?, maxCookTime?, dietTags? }
};
```

- **A combo holds the existing `RecipeFilters` object, not flattened fields.** Applying a combo
  is then a straight hand-off to the store's existing setter, and adding a filter type later
  doesn't touch a mapping function.
- **One integer `version`, no migration machinery** (per the non-goal). On read, a payload whose
  `version` isn't `1` is treated as no saved filters at all. We'd rather lose three local chips
  than own a migration path.
- `id` exists so delete and duplicate-name checks don't depend on the name being unique forever.

### The pieces and what they're responsible for

**`SavedFilterRepository`** — one concrete `@Injectable({ providedIn: 'root' })` class. No
interface, no `InjectionToken`: there is exactly one implementation.

```ts
getAll(): SavedFilter[]      // parse, validate envelope, [] on anything unexpected
save(filter: SavedFilter): void
delete(id: string): void
```

- It is the **only** file that references `localStorage`. When the server version arrives, this
  class's body changes and its methods go async — a contained edit, which is the reason not to
  build a port for it today.
- Every read and write is wrapped: a throw or missing key from `getAll()` yields `[]`; a throw
  from `save()` surfaces as the failure message specified in Desired Behavior.

**`SavedFilters`** — a small signal service, deliberately *separate* from the recipe search
store, so the search store keeps its current shape (goal 2) and doesn't mix "what am I
searching" with "what did I bookmark".

```ts
#items = signal<SavedFilter[]>(this.#repository.getAll());
items = this.#items.asReadonly();

save(name: string, filters: RecipeFilters): void   // rejects a duplicate name
delete(id: string): void
```

- No new state management library. Signals + this service are the whole state story.

**`recipe-filter-bar`** — grows three things: the "Save these filters" button (disabled while no
filter is set), the inline name field, and the chip row. It is also where a chip click is
turned into a search:

```ts
// chip click
const { filters, droppedDietTags } = sanitizeFilters(savedFilter.filters, knownDietTags());
searchStore.setFilters(filters);          // the existing setter — no second search path
notice.set(droppedDietTags);              // inline message, empty = hidden
```

### Decisions and why

- **Apply goes through the search store's existing filter setter.** This is what makes "a chip
  produces the same request as typing" true by construction rather than by testing two paths.
- **Sanitising happens on apply, not on read or write.** Storage is never rewritten, so a diet
  tag that comes back later simply starts working again — and the rule sits on the one path that
  needs it, where a component test can see it.
- **`sanitizeFilters` is a pure function** taking the saved filters plus the currently known diet
  tags, returning the usable filters and whatever it dropped. No injection, no store access.
- **Sanitising is best-effort, because the diet tag list is fetched.** The filter bar already
  loads the tags; if they haven't arrived when a chip is clicked, the combo is applied as-is with
  no notice. A chip never waits, is never disabled, and never has a pending state. An unknown tag
  that slips through reaches the search request and narrows the results to nothing — exactly what
  typing that tag by hand would do.
  - `TODO: confirm the recipe search API treats an unknown diet tag as a plain filter value
    (empty results) and not a 400. The best-effort approach above depends on it; if it 400s,
    chips have to wait for the tag list instead.`
- **The notice is an inline message in the filter bar**, cleared on the next filter change. No
  toast service, no timers, and it's findable by text in a Testing Library test.
- **Nothing new in `package.json`.** `crypto.randomUUID()`, `JSON`, `localStorage`.

### Rollout

Nothing has shipped, so there is no migration. No feature flag: the chip row is invisible until
someone saves their first combo, which is its own rollout.

## Testing Strategy

Vitest + Angular Testing Library, as everywhere else in whiskmate. The default level is **the
filter bar component, driven through the UI, with the real store, the real `SavedFilters`
service, the real repository and real jsdom `localStorage`**. The only fake is HTTP, via MSW.
`localStorage.clear()` in `beforeEach`.

Rationale: the fake sits at the network edge, so every layer that ships is exercised, and the
stored JSON in the test is the stored JSON in production.

### Through the component

1. **Save a combo → the chip appears.** Set filters, click Save, type a name, press Enter,
   assert a chip with that name.
2. **A combo saved in a previous session shows up.** Arrange `localStorage` explicitly with a
   `version: 1` payload, then render with a **fresh TestBed**. This is the only honest analogue of
   a reload: `SavedFilters` is `providedIn: 'root'` and seeds its signal once, so re-rendering in
   the same TestBed would pass without exercising the read path at all. The arrange step is
   explicit — no reliance on a previous test having run.
3. **Clicking a chip produces the same search request as setting those filters by hand.** MSW
   sees both requests; compare them. This is the invariant the whole design leans on.
4. **Duplicate name** → nothing saved, the message is shown, the name field stays open.
5. **Stale diet tag** → remaining filters applied, the notice names the dropped tag, and the
   stored payload still contains it.
6. **Storage unreadable** → the chip row is empty and search still works.

### Below the component

- **`sanitizeFilters`, test-first, as a pure-function test.** It has the branchiest logic in the
  feature — unknown tag, every tag unknown, tag list not loaded yet — and those cases are painful
  to enumerate through the UI.
- **`SavedFilterRepository`, direct tests** for corrupt JSON, an unknown `version`, and a storage
  call that throws in each direction (read → `[]`, write → handled). Reaching those states through
  the component would mean hand-writing broken JSON into storage anyway, so the direct test is the
  honest one here.
- **No isolated tests for `SavedFilters`.** It's a thin wrapper over the repository, already
  covered through the component; testing it separately would mostly lock in its shape.

### Driven test-first

- `sanitizeFilters`.
- The save-and-reapply flow through the component, which also forces the component API early.

### Keeping the tests non-brittle

- **Query chips by accessible role and name** (`getByRole('button', { name: 'quick vegan dinner' })`),
  never by test id or CSS class. A chip being a button labelled with the combo name *is* the
  contract; the markup around it isn't.
- **Don't assert the stored JSON shape from component tests.** Persistence is asserted by "the
  chip is there after a reload". The one exception is scenario 5, which asserts the dropped tag
  is *still* in storage — that's the behavior, not the shape.
- **Assert the search request, not the store's internals.** MSW already sees the request, and
  asserting store fields would couple the suite to a store we promised not to reshape.
- **One place builds the fake recipes and diet tags**, so adding a filter type later doesn't
  touch every test file.

### If time runs out before the workshop

Drop the component test for the *write*-failure message. Keep the empty-chip-row test — degrading
to today's app is the promise that actually matters.

## Alternatives Considered

### Server-side, per-user saved filters in v1

- **Tempting because** it's where this ends up eventually, and doing it now would avoid a second
  pass over the same feature.
- **Lost because** localStorage is plenty for v1, and treating this as groundwork for sync is
  exactly how it grows an API contract, an auth dependency and a loading state it doesn't need
  three weeks before the workshop.
- **Revisit when** someone actually asks to see their combos on a second device. One real request
  is the trigger — not the arrival of user accounts, and not usage numbers.

### A dedicated `libs/saved-filters` lib (or a feature/data-access split)

- **Tempting because** it's the structurally "correct" Nx answer and keeps the recipe-search lib
  from accreting.
- **Lost because** it forces a public API and a dependency direction to be decided before any code
  exists, for three files with one consumer.
- **Revisit when** something outside recipe search wants saved filters.

### Interface + `InjectionToken` for the repository

- **Tempting because** it's the textbook seam, and it makes the eventual server implementation a
  drop-in.
- **Lost because** it's an indirection with one implementor. The concrete class already localises
  every `localStorage` reference; swapping bodies (and going async) is a contained edit.
- **Revisit when** there's a second consumer, or when the server version and a second consumer show
  up together — that's the moment to do both properly, not before.

### Merge-on-click, and toggleable "active" chips

- **Tempting because** merging lets you stack a combo onto the current search, and an active
  highlight gives a useful "you are here".
- **Lost because** merge has no sane rule for conflicting scalar values (whose max cook time wins?)
  and depends on invisible prior state; "active" requires defining what *un*-actives a chip after a
  hand edit, which is a state machine for no benefit.
- **Revisit when** someone complains that clicking a chip threw away filters they'd just tweaked.

### Auto-naming chips from the filters, no prompt

- **Tempting because** it's one click and zero typing.
- **Lost because** "quick vegan dinner" is the point; `tofu · 30 min · vegan` is just the filter bar
  restated.

### Overwrite on duplicate name

- **Tempting because** re-saving under the same name would double as the edit affordance we left
  out of scope.
- **Lost because** it destroys data with no confirmation.
- **Revisit when** "I want to change a saved combo" comes up for real — this is the cheapest answer
  to it, and cheaper than building an edit mode.

### zod / valibot for the stored payload

- **Tempting because** validate-on-read becomes a declarative schema instead of hand-written checks.
- **Lost because** it's a runtime dependency for one parse call in a feature whose payload is a
  version number and three fields per combo.
- **Revisit when** the payload grows past what a hand-written check reads well, or when a second
  version of it has to be supported.

### Faking the repository in component tests

- **Tempting because** there'd be no global `localStorage` to reset and tests would be marginally
  faster.
- **Lost because** then nothing in the suite proves the feature actually persists, which is the only
  reason the repository exists. Recorded here so it doesn't get "simplified" into the suite later.

### Cutting persistence for the workshop (in-memory chips)

- **Tempting because** it's the fastest path to something demoable.
- **Lost because** chips that die on reload aren't saved filters. If persistence gets ugly we cut the
  ugly part of it, not persistence itself.
