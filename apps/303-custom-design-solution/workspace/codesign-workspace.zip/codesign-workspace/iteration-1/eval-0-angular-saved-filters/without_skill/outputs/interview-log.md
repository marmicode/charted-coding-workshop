# Interview log — saved filters design doc

Questions I would have asked via `AskUserQuestion`, in the order I would have asked them,
with the persona's answers recorded underneath.

---

## Round 1 — before writing the design doc

```json
{
  "questions": [
    {
      "question": "Where should saved filters live for v1?",
      "header": "Storage",
      "multiSelect": false,
      "options": [
        {
          "label": "localStorage only",
          "description": "Per-browser, no backend work. Fastest to ship; filters don't follow the user across devices.",
          "preview": "localStorage['whiskmate.saved-filters'] =\n  '[{\"id\":\"...\",\"name\":\"Quick vegan\",\"criteria\":{...}}]'"
        },
        {
          "label": "Server-side per user",
          "description": "New API endpoints + auth-scoped persistence. Syncs across devices but needs backend work.",
          "preview": "GET    /api/saved-filters\nPOST   /api/saved-filters\nDELETE /api/saved-filters/:id"
        },
        {
          "label": "URL only (shareable, not saved)",
          "description": "Encode the filter combo in query params. No persistence layer at all, but no chips list either.",
          "preview": "/recipes?ingredient=tofu&maxTime=20&diet=vegan"
        },
        {
          "label": "localStorage now, server-shaped API",
          "description": "Ship localStorage but hide it behind a repository interface so a server impl can drop in later.",
          "preview": "interface SavedFilterRepository {\n  findAll(): SavedFilter[];\n  save(f: SavedFilter): void;\n  remove(id: string): void;\n}"
        }
      ]
    },
    {
      "question": "What's in scope for v1?",
      "header": "Scope",
      "multiSelect": true,
      "options": [
        { "label": "Save current filters with a name", "description": "The core loop: set filters → name → save." },
        { "label": "Apply a saved filter by clicking its chip", "description": "Clicking a chip replaces the current filter state." },
        { "label": "Delete a saved filter", "description": "An × on the chip, or a small menu." },
        { "label": "Rename / edit / reorder", "description": "Editing an existing saved filter in place, drag-to-reorder." }
      ]
    },
    {
      "question": "How should the saved-filter state be wired in?",
      "header": "State",
      "multiSelect": false,
      "options": [
        {
          "label": "Extend the existing signal store",
          "description": "Add saved-filter signals + methods to the store that already holds filter state. No new concepts.",
          "preview": "recipeSearchStore\n  .savedFilters()        // Signal<SavedFilter[]>\n  .saveCurrentFilters(name)\n  .applySavedFilter(id)"
        },
        {
          "label": "Separate SavedFiltersStore",
          "description": "A second signal store, injected alongside. Cleaner separation, one more moving part.",
          "preview": "class SavedFiltersStore { ... }\nclass RecipeSearchStore { ... }"
        },
        {
          "label": "Add a state management library",
          "description": "NgRx / NgRx SignalStore / Elf to formalise this and future state.",
          "preview": "signalStore(\n  withEntities<SavedFilter>(),\n  withMethods(...)\n)"
        }
      ]
    },
    {
      "question": "How do you want this tested?",
      "header": "Testing",
      "multiSelect": false,
      "options": [
        {
          "label": "Through the component, real store, faked HTTP",
          "description": "Angular Testing Library renders the search page; the real store runs; MSW fakes the API. Tests read like user stories.",
          "preview": "await render(RecipeSearchComponent);\nawait user.click(screen.getByRole('button', {name: 'Save filters'}));\n…\nexpect(screen.getByRole('button', {name: 'Quick vegan'}))"
        },
        {
          "label": "Unit-test the store in isolation",
          "description": "Direct tests on store methods with a mocked repository, plus thin component tests.",
          "preview": "const store = new RecipeSearchStore(repoMock);\nstore.saveCurrentFilters('Quick vegan');\nexpect(store.savedFilters()).toHaveLength(1);"
        },
        {
          "label": "E2E only",
          "description": "Cover it in Playwright against the running app."
        }
      ]
    }
  ]
}
```

**Answer:**
1. Storage → **Other: "localStorage now, but don't build me a repository abstraction with one implementation. Just a small, honest `SavedFilterStorage` thing that reads/writes localStorage. Server per-user is the eventual goal — write it down as future work, don't design for it today."**
2. Scope → **Save current filters with a name**, **Apply a saved filter by clicking its chip**, **Delete a saved filter** (rename/edit/reorder explicitly out — there's a workshop in 3 weeks, scope stays small)
3. State → **Extend the existing signal store** (*"and no new state management library, ever, for this."*)
4. Testing → **Through the component, real store, faked HTTP**

---

## Round 2 — before writing the edge-cases section

```json
{
  "questions": [
    {
      "question": "A saved filter references a diet tag that no longer exists. What should happen when the user clicks that chip?",
      "header": "Stale tags",
      "multiSelect": false,
      "options": [
        {
          "label": "Drop unknown tags silently",
          "description": "Apply the parts that still resolve; ignore the rest. Results look right, user isn't told anything changed.",
          "preview": "saved:  { diets: ['vegan', 'paleo'] }\ntags:   ['vegan', 'keto']\napplied:{ diets: ['vegan'] }"
        },
        {
          "label": "Drop unknown tags + tell the user",
          "description": "Same behaviour, plus a small inline message: \"'paleo' is no longer available.\"",
          "preview": "applied: { diets: ['vegan'] }\n⚠ 'paleo' is no longer available and was removed."
        },
        {
          "label": "Keep the chip, refuse to apply",
          "description": "Mark the chip as broken and make the user fix or delete it."
        },
        {
          "label": "Ignore it for v1",
          "description": "Send whatever was saved to the API and let the backend return whatever it returns."
        }
      ]
    },
    {
      "question": "What should happen if the user saves a filter with a name that already exists?",
      "header": "Duplicates",
      "multiSelect": false,
      "options": [
        { "label": "Overwrite the existing one", "description": "Last write wins, no prompt." },
        { "label": "Reject with an inline error", "description": "\"You already have a filter called 'Quick vegan'.\" Keeps the dialog open." },
        { "label": "Allow duplicates", "description": "Names are just labels; ids are unique anyway." }
      ]
    }
  ]
}
```

**Answer:**
1. Stale tags → **Drop unknown tags + tell the user** (*"this is the one thing that actually worries me — I don't want a chip to silently return the wrong recipes. But a one-line message is enough, don't build a reconciliation UI."*)
2. Duplicates → **Reject with an inline error**

---

No further questions. Everything else (chip placement, id generation, storage key, test file layout) I picked defaults for and wrote them down in the doc so they're easy to argue with.
