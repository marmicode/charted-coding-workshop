# Design doc — Saved filters for recipe search

**Status:** draft · **Author:** Sam · **Date:** 2026-09-24 · **Target:** v1, before the workshop (3 weeks)

---

## 1. Problem

Recipe search has a filter bar (ingredient, max cook time, diet tags) that writes into a
signal-based store. People re-type the same combinations constantly — "tofu, under 20 min,
vegan" — and there is no way to keep one around.

We want: pick a few filters → name the combo → it shows up as a chip you can click later to
re-apply it.

## 2. Goals

- Save the currently-applied filters under a user-provided name.
- Show saved filters as chips near the filter bar.
- Clicking a chip applies that filter combination to the search.
- Deleting a saved filter.
- Survives a page reload, on the same browser.

## 3. Non-goals (v1)

These are deliberately out. Each one is a thing we could add later without redesigning anything.

| Out of scope | Why |
| --- | --- |
| Server-side / cross-device sync | Needs API + auth work. localStorage is plenty for v1; see §10. |
| Renaming or editing a saved filter | Delete + re-save covers it. Workshop is in 3 weeks. |
| Reordering / pinning / favourites | No evidence anyone needs it yet. |
| Sharing a saved filter with another user | Depends on server-side storage. |
| A new state management library | We keep the existing signal store. Not negotiable. |
| Migrating old stored payloads between schema versions | v1 is the first schema. See §8.3 for the forward-compat escape hatch. |

## 4. User-facing behaviour

### 4.1 Saving

1. User sets filters in the filter bar as they do today.
2. A **Save filters** button sits at the end of the filter bar. It is **disabled when no filter is
   applied** — saving "everything" is not a useful chip.
3. Clicking it reveals a small inline name field (not a modal — a modal is more component, more
   focus management, and more test setup than this earns) with a **Save** button.
4. On save, the combo is stored and a new chip appears in the chip row.

### 4.2 Applying

- Chips render in a row directly above the result list, labelled with the saved name.
- Clicking a chip **replaces** the entire current filter state with the saved one. It does not
  merge. Merging would make "click two chips" ambiguous, and replace is what a user expects from
  something that looks like a preset.
- The active chip gets an `aria-pressed`/selected state while the current filters match it
  exactly. When the user then tweaks any filter, the chip deselects — it reflects reality, it is
  not a mode.

### 4.3 Deleting

- Each chip has an `×` (its own `<button>`, with an accessible name like
  `Delete saved filter "Quick vegan"`).
- Deletion is immediate, no confirm dialog. Re-saving costs four seconds.

### 4.4 Empty and error states

- No saved filters → the chip row renders nothing at all (no empty-state copy, no reserved space).
- Duplicate name → inline error next to the name field: *You already have a filter called
  "Quick vegan".* The field stays open with the text intact.
- Empty/whitespace-only name → Save stays disabled.

## 5. Data model

```ts
/** The filter criteria the search store already works with. */
export interface RecipeFilterCriteria {
  ingredient?: string;
  maxCookTime?: number;
  dietTags?: string[];
}

export interface SavedFilter {
  id: string;          // crypto.randomUUID()
  name: string;        // trimmed, unique among saved filters (case-insensitive)
  criteria: RecipeFilterCriteria;
  createdAt: string;   // ISO, only used for stable ordering
}
```

Notes:

- `criteria` is stored **by value**, as a snapshot. A saved filter is a copy of what the filters
  were, not a live reference to anything.
- Chips are ordered by `createdAt` ascending — newest last, so the row doesn't reshuffle under the
  user's cursor.
- `RecipeFilterCriteria` should be the type the store already uses for its filter state, not a new
  parallel one. If the store currently holds three separate signals rather than one criteria
  object, the small refactor to group them is worth doing first (§9, step 0) — otherwise every
  save/apply path has to know the field list by hand.

## 6. Persistence

localStorage, one key, whole-array read/write.

```
key:   whiskmate.saved-filters.v1
value: JSON.stringify(SavedFilter[])
```

A single small class owns it:

```ts
@Injectable({ providedIn: 'root' })
export class SavedFilterStorage {
  load(): SavedFilter[];       // returns [] on missing / unparsable / wrong-shape data
  save(filters: SavedFilter[]): void;  // swallows QuotaExceededError, logs it
}
```

Deliberately **not** an interface with one implementation, and not a repository abstraction with a
pluggable backend. It is a named seam — when we move to the server we change this class's body and
its return types to async, and the blast radius is the store. That's the whole point of it being
one class in one file.

Failure handling:

- `load()` never throws. Corrupt JSON, a non-array, or objects missing `id`/`name`/`criteria` →
  return `[]` and `console.warn`. Losing saved filters is annoying; a white screen is worse.
- `save()` catches `QuotaExceededError` (Safari private browsing throws on write). The in-memory
  state still updates so the current session behaves; it just won't survive reload.
- Writes are whole-array. There is no scenario in v1 where the list is big enough for that to
  matter.

## 7. Architecture

Everything lives next to the existing recipe search feature — same Nx library as the search
component and its store. No new library, no shared/ui promotion. If a second feature ever needs
saved filters, that's when we move it.

```
<recipe-search lib>/
  src/lib/
    recipe-search.component.ts        (existing — renders the new pieces)
    recipe-search.store.ts            (existing — extended, see §7.1)
    saved-filter.ts                   (new — SavedFilter type + name-comparison helper)
    saved-filter-storage.ts           (new — §6)
    saved-filter-chips.component.ts   (new — presentational: inputs chips, outputs apply/delete)
    save-filter-button.component.ts   (new — the button + inline name field)
```

> Path assumption: this mirrors wherever `recipe-search.component.ts` lives today. Adjust to the
> real lib path; nothing in the design depends on it.

Both new components are dumb: `input()` for data, `output()` for intent. They inject nothing. The
store is injected once, by the search component, and passed down. That keeps them trivially
renderable in isolation if we ever want to, without making that the primary way we test (§9).

### 7.1 Store changes

Added to the existing `RecipeSearchStore` — no second store, no library.

```ts
// state
readonly #savedFilters = signal<SavedFilter[]>(this.#storage.load());
readonly savedFilters = this.#savedFilters.asReadonly();

// derived: which chip (if any) matches the live filter state
readonly activeSavedFilterId = computed(() => ...);

// commands
saveCurrentFilters(name: string): SaveResult;   // { ok: true } | { ok: false, reason: 'duplicate-name' }
applySavedFilter(id: string): void;             // replaces criteria; drops unknown diet tags (§8.1)
deleteSavedFilter(id: string): void;
```

- Initial load is **synchronous, in the field initialiser**. No `ngOnInit`, no effect, no
  loading state — localStorage is synchronous and the chips are there on first render.
- Every mutation writes through to `SavedFilterStorage` immediately. No debounce, no "dirty" flag.
- `saveCurrentFilters` returns a result rather than throwing, because the duplicate-name case is a
  normal UI outcome, not an exception.

### 7.2 Why not a separate store

A second store would need a reference to the search store anyway (to read the current criteria
when saving, and write them when applying). That coupling is the feature. Splitting it buys a
boundary we'd immediately punch a hole through.

## 8. Edge cases

### 8.1 A saved filter references a diet tag that no longer exists

This is the one that can silently hand back wrong results, so it gets explicit handling.

On **apply**, the store intersects the saved `dietTags` with the diet tags currently available:

- Known tags are applied.
- Unknown tags are dropped from what gets applied.
- The search component shows a single dismissible inline message:
  *"paleo" is no longer available and was not applied.*
  (Comma-joined if several.)
- The **saved filter itself is not modified**. We don't rewrite the user's data because a tag
  happened to be missing on one page load — the tag list could be temporarily empty because the
  request that provides it failed.
- Corollary: if the *entire* saved tag set is unknown, we still apply the rest of the criteria
  (ingredient, cook time) and show the message. We don't refuse to apply.

No reconciliation UI, no "broken filter" chip state. One line of text.

> Depends on: the component/store having access to the current list of valid diet tags. If diet
> tags today come only from the server as part of the search response and are not separately
> available, this check has to happen after a response comes back, or we accept a stale list.
> **Worth confirming before implementation** — it's the only part of this design with an unknown
> in it.

### 8.2 Other cases

| Case | Behaviour |
| --- | --- |
| Duplicate name (case-insensitive, trimmed) | Rejected inline (§4.4). Ids stay unique regardless. |
| Name with only whitespace | Save disabled. |
| Very long name | Trimmed to 60 chars on save; chip label CSS-truncates with a `title`. |
| localStorage unavailable / throws on read | Start empty, feature still works for the session. |
| localStorage full on write | In-memory state updates, warning logged, no user-facing error. |
| Two tabs open, both save | Last write wins. No `storage` event listener in v1 — accepted. |
| Saved criteria has a field we no longer support | Unknown keys are ignored when applying. |
| Clicking the already-active chip | Re-applies (harmless, idempotent). No toggle-off. |

## 9. Testing

Tests go through the component with the real store and faked HTTP — Angular Testing Library +
Vitest + MSW, same as the rest of the search tests. The store is not unit-tested in isolation; its
behaviour is observable through the UI, and testing it separately would pin down internals we
might want to move.

`localStorage` is real in the jsdom environment — it gets cleared in `beforeEach` rather than
mocked, so the persistence path is actually exercised.

Test list (each one is a user-visible behaviour):

1. **Save** — apply filters, click Save filters, type a name, save → a chip with that name appears.
2. **Save is disabled with no filters applied.**
3. **Apply** — with a saved filter present, click its chip → the filter bar reflects the saved
   criteria and the result list shows the matching recipes (MSW asserts the request).
4. **Apply replaces** — with different filters currently set, clicking a chip clears the ones not
   in the saved combo.
5. **Delete** — click the chip's `×` → the chip is gone.
6. **Persistence** — save, re-render the component fresh → the chip is still there.
7. **Duplicate name** — saving a second filter with the same name shows the inline error and does
   not add a chip.
8. **Stale diet tag** — seed storage with a filter referencing a tag MSW no longer returns, apply
   it → the message is shown, the request goes out without the unknown tag, and the saved filter
   is unchanged.
9. **Corrupt storage** — seed the key with `"{{{"` → the page renders with no chips and does not
   throw.

Cases 8 and 9 are the ones worth writing first; 1–5 are the happy path and will fall out of the
implementation.

## 10. Future work

- **Server-side per-user storage.** The eventual goal. `SavedFilterStorage` becomes async
  (`load(): Promise<SavedFilter[]>`), the store gains a loading state for the chip row, and the
  criteria snapshot probably gets a schema version. Nothing above needs to be re-thought to get
  there — but nothing above is built *for* it either.
- Rename / edit in place.
- Share a saved filter via URL.
- `storage` event sync across tabs.

## 11. Decisions taken without asking (argue with these)

- Inline name field rather than a modal.
- Chips above the results, not inside the filter bar.
- Apply **replaces** rather than merges.
- Delete has no confirmation.
- Order is creation order, oldest first.
- Storage key is versioned (`.v1`) so a future schema change can be a new key rather than a
  migration.

## 12. Open question

- §8.1: is the current set of valid diet tags available to the client independently of a search
  response? The stale-tag handling depends on it. If not, the fallback is to validate against the
  tags from the most recent response and accept that a first-load apply might not filter them.
